import { execFile } from 'child_process';
import express, { Request, Response } from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { promisify } from 'util';

const execFileAsync = promisify(execFile);

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PYTHON_PROJECT_DIR = path.resolve(__dirname, 'wellness-survey-visualizer');
const PYTHON_MAIN = path.resolve(PYTHON_PROJECT_DIR, 'main.py');
const CHARTS_DIR = path.resolve(PYTHON_PROJECT_DIR, 'reports', 'charts');
const REPORTS_DIR = path.resolve(PYTHON_PROJECT_DIR, 'reports');

const ALLOWED_API_ACTIONS = new Set([
  'state',
  'add',
  'delete',
  'search',
  'filter',
  'load-sample',
  'import-csv',
  'clear',
  'generate-charts',
  'export-reports',
]);

const ALLOWED_CHART_FILES = new Set([
  '01_sleep_duration_distribution.png',
  '02_stress_level_distribution.png',
  '03_mood_distribution.png',
  '04_physical_activity_distribution.png',
  '05_overall_wellness_distribution.png',
  '06_wellness_trends_over_time.png',
]);

const ALLOWED_REPORT_FILES = new Set([
  'executive_wellness_report.md',
  'executive_wellness_report.txt',
  'executive_wellness_report_summary.csv',
]);

async function runPythonApi(action: string, payload: unknown = {}): Promise<Record<string, unknown>> {
  if (!ALLOWED_API_ACTIONS.has(action)) {
    throw new Error(`Unsupported API action: ${action}`);
  }
  const serialized = JSON.stringify(payload ?? {});
  const { stdout } = await execFileAsync(
    'python3',
    [PYTHON_MAIN, '--api', action, '--payload', serialized],
    {
      cwd: PYTHON_PROJECT_DIR,
      timeout: 15000,
      maxBuffer: 4 * 1024 * 1024,
    }
  );
  return JSON.parse(stdout) as Record<string, unknown>;
}

async function startServer(): Promise<void> {
  const app = express();
  app.use(express.json({ limit: '2mb' }));

  app.get('/api/state', async (_req: Request, res: Response) => {
    try {
      const data = await runPythonApi('state');
      res.json(data);
    } catch (err) {
      res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Python backend error' });
    }
  });

  app.post('/api/responses', async (req: Request, res: Response) => {
    try {
      const data = await runPythonApi('add', req.body ?? {});
      res.json(data);
    } catch (err) {
      res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Failed to save response' });
    }
  });

  app.delete('/api/responses/:recordId', async (req: Request, res: Response) => {
    try {
      const recordId = String(req.params.recordId ?? '').trim();
      if (!/^[A-Za-z0-9_-]{4,24}$/.test(recordId)) {
        res.status(400).json({ ok: false, error: 'Invalid record ID format.' });
        return;
      }
      const data = await runPythonApi('delete', { record_id: recordId });
      res.json(data);
    } catch (err) {
      res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Delete failed' });
    }
  });

  app.post('/api/search', async (req: Request, res: Response) => {
    try {
      const data = await runPythonApi('search', req.body ?? {});
      res.json(data);
    } catch (err) {
      res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Search failed' });
    }
  });

  app.post('/api/filter', async (req: Request, res: Response) => {
    try {
      const data = await runPythonApi('filter', req.body ?? {});
      res.json(data);
    } catch (err) {
      res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Filter failed' });
    }
  });

  app.post('/api/sample-data', async (_req: Request, res: Response) => {
    try {
      const data = await runPythonApi('load-sample');
      res.json(data);
    } catch (err) {
      res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Sample load failed' });
    }
  });

  app.post('/api/import-csv', async (req: Request, res: Response) => {
    try {
      const csvContent = typeof req.body?.csv_content === 'string' ? req.body.csv_content : '';
      if (!csvContent.trim()) {
        res.status(400).json({ ok: false, error: 'CSV content cannot be empty.' });
        return;
      }
      const data = await runPythonApi('import-csv', { csv_content: csvContent });
      res.json(data);
    } catch (err) {
      res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'CSV import failed' });
    }
  });

  app.post('/api/clear', async (_req: Request, res: Response) => {
    try {
      const data = await runPythonApi('clear');
      res.json(data);
    } catch (err) {
      res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Clear failed' });
    }
  });

  app.post('/api/charts/generate', async (_req: Request, res: Response) => {
    try {
      const data = await runPythonApi('generate-charts');
      res.json(data);
    } catch (err) {
      res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Chart generation failed' });
    }
  });

  app.get('/api/charts/:filename', (req: Request, res: Response) => {
    const filename = path.basename(String(req.params.filename ?? ''));
    if (!ALLOWED_CHART_FILES.has(filename)) {
      res.status(404).json({ ok: false, error: 'Chart not found.' });
      return;
    }
    const resolved = path.resolve(CHARTS_DIR, filename);
    if (!resolved.startsWith(CHARTS_DIR + path.sep) || !fs.existsSync(resolved)) {
      res.status(404).json({ ok: false, error: 'Chart file does not exist yet.' });
      return;
    }
    res.setHeader('Cache-Control', 'no-store');
    res.sendFile(resolved);
  });

  app.post('/api/reports/export', async (req: Request, res: Response) => {
    try {
      const data = await runPythonApi('export-reports', req.body ?? {});
      res.json(data);
    } catch (err) {
      res.status(500).json({ ok: false, error: err instanceof Error ? err.message : 'Report export failed' });
    }
  });

  app.get('/api/reports/download/:filename', (req: Request, res: Response) => {
    const filename = path.basename(String(req.params.filename ?? ''));
    if (!ALLOWED_REPORT_FILES.has(filename)) {
      res.status(404).json({ ok: false, error: 'Report file not found.' });
      return;
    }
    const resolved = path.resolve(REPORTS_DIR, filename);
    if (!resolved.startsWith(REPORTS_DIR + path.sep) || !fs.existsSync(resolved)) {
      res.status(404).json({ ok: false, error: 'Report file has not been generated yet.' });
      return;
    }
    res.download(resolved, filename);
  });

  app.post('/api/tests/run', async (_req: Request, res: Response) => {
    try {
      const { stdout, stderr } = await execFileAsync(
        'python3',
        ['-m', 'unittest', 'discover', '-s', 'tests', '-v'],
        {
          cwd: PYTHON_PROJECT_DIR,
          timeout: 20000,
          maxBuffer: 2 * 1024 * 1024,
        }
      );
      res.json({ ok: true, output: `${stdout}\n${stderr}`.trim() });
    } catch (err: unknown) {
      const execErr = err as { stdout?: string; stderr?: string; message?: string };
      res.status(500).json({
        ok: false,
        output: `${execErr.stdout ?? ''}\n${execErr.stderr ?? ''}\n${execErr.message ?? ''}`.trim(),
      });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distDir, 'index.html'));
    });
  }

  const port = Number(process.env.PORT ?? 3000);
  app.listen(port, '0.0.0.0', () => {
    console.log(`Wellness Survey Visualizer workbench listening on http://localhost:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
