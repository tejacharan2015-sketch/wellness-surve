import React, { useCallback, useEffect, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  BarChart3,
  CheckCircle2,
  Download,
  FileText,
  Filter,
  FlaskConical,
  LayoutDashboard,
  PlusCircle,
  RefreshCw,
  Search,
  ShieldCheck,
  Trash2,
  Upload,
} from 'lucide-react';

type TabKey = 'overview' | 'submit' | 'records' | 'charts' | 'reports';

interface MetricSummary {
  average: number;
  median_value: number;
  minimum: number;
  maximum: number;
}

interface CategoryBreakdown {
  counts: Record<string, number>;
  percentages: Record<string, number>;
}

interface TrendPoint {
  survey_date: string;
  count: number;
  avg_sleep: number;
  avg_activity: number;
  avg_stress: number;
  avg_mood: number;
  avg_wellness: number;
}

interface AnalyticsReport {
  total_responses: number;
  is_empty: boolean;
  date_range: [string, string];
  sleep_stats: MetricSummary | null;
  activity_stats: MetricSummary | null;
  stress_stats: MetricSummary | null;
  mood_stats: MetricSummary | null;
  wellness_stats: MetricSummary | null;
  wellness_distribution: CategoryBreakdown | null;
  stress_distribution: CategoryBreakdown | null;
  sleep_distribution: CategoryBreakdown | null;
  activity_distribution: CategoryBreakdown | null;
  age_distribution: CategoryBreakdown | null;
  highest_avg_metric: [string, number] | null;
  lowest_avg_metric: [string, number] | null;
  highest_wellness_day: [string, number] | null;
  lowest_wellness_day: [string, number] | null;
  trends: TrendPoint[];
  wellness_trend_delta: number;
  stress_trend_delta: number;
  threshold_warnings: string[];
  observations: string[];
  disclaimer: string;
}

interface SurveyRecord {
  record_id: string;
  survey_date: string;
  age_group: string;
  sleep_duration: number;
  physical_activity: number;
  stress_level: number;
  mood_rating: number;
  general_wellness: number;
  data_origin: string;
}

interface ImportSummary {
  source_file: string;
  total_rows: number;
  imported_count: number;
  duplicate_count: number;
  invalid_count: number;
  missing_columns: string[];
  errors: string[];
  log_path: string;
}

interface AppState {
  report: AnalyticsReport;
  records: SurveyRecord[];
  charts: string[];
  startup_warnings: string[];
}

const CHART_TITLES: Record<string, string> = {
  '01_sleep_duration_distribution.png': '01. Sleep Duration Distribution',
  '02_stress_level_distribution.png': '02. Stress Level Distribution',
  '03_mood_distribution.png': '03. Mood Rating Distribution',
  '04_physical_activity_distribution.png': '04. Physical Activity Distribution',
  '05_overall_wellness_distribution.png': '05. Overall Wellness Distribution',
  '06_wellness_trends_over_time.png': '06. Wellness Trends Over Time',
};

const AGE_GROUPS = [
  'Prefer not to say',
  '18-24',
  '25-34',
  '35-44',
  '45-54',
  '55+',
];

function wellnessTierLabel(score: number): string {
  if (score <= 4) return 'Low';
  if (score <= 7) return 'Moderate';
  return 'High';
}

function stressTierLabel(score: number): string {
  if (score <= 3) return 'Low';
  if (score <= 6) return 'Moderate';
  return 'High';
}

export default function App() {
  const [activeTab, setActiveTab] = useState<TabKey>('overview');
  const [state, setState] = useState<AppState | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [busyAction, setBusyAction] = useState<string>('');
  const [feedback, setFeedback] = useState<{ kind: 'success' | 'error'; text: string } | null>(null);

  // Submit form state
  const [formState, setFormState] = useState({
    record_id: '',
    survey_date: new Date().toISOString().slice(0, 10),
    age_group: 'Prefer not to say',
    sleep_duration: '7.5',
    physical_activity: '45',
    stress_level: '4',
    mood_rating: '8',
    general_wellness: '8',
  });
  const [formErrors, setFormErrors] = useState<string[]>([]);
  const [formWarnings, setFormWarnings] = useState<string[]>([]);

  // Search & Filter state
  const [searchId, setSearchId] = useState('');
  const [filterCriteria, setFilterCriteria] = useState({
    survey_date: '',
    wellness_category: '',
    stress_category: '',
    activity_category: '',
    min_sleep: '',
    max_sleep: '',
  });
  const [displayedRecords, setDisplayedRecords] = useState<SurveyRecord[] | null>(null);

  // Charts cache buster
  const [chartTimestamp, setChartTimestamp] = useState<number>(Date.now());
  const [chartNote, setChartNote] = useState<string>('');

  // Reports, CSV Import, & Tests state
  const [csvText, setCsvText] = useState<string>('');
  const [importSummary, setImportSummary] = useState<ImportSummary | null>(null);
  const [executiveText, setExecutiveText] = useState<string>('');
  const [testOutput, setTestOutput] = useState<string>('');
  const [confirmClear, setConfirmClear] = useState<boolean>(false);

  const fetchState = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/state');
      const data = await res.json();
      if (data.report) {
        setState(data);
        setDisplayedRecords(null);
      }
    } catch {
      setFeedback({ kind: 'error', text: 'Failed to load survey state from Python backend.' });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchState();
  }, [fetchState]);

  const handleSubmitEntry = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormErrors([]);
    setFormWarnings([]);
    setBusyAction('submit');
    try {
      const res = await fetch('/api/responses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formState),
      });
      const data = await res.json();
      if (!data.ok) {
        setFormErrors(data.errors || [data.error || 'Validation failed.']);
        return;
      }
      setState({
        report: data.report,
        records: data.records,
        charts: data.charts,
        startup_warnings: data.startup_warnings,
      });
      setDisplayedRecords(null);
      setFormWarnings(data.warnings || []);
      setFeedback({
        kind: 'success',
        text: `Saved anonymous record ${data.record.record_id} to CSV and JSON storage.`,
      });
      setFormState((prev) => ({ ...prev, record_id: '' }));
    } catch {
      setFormErrors(['Unable to submit record to backend validation engine.']);
    } finally {
      setBusyAction('');
    }
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusyAction('search');
    try {
      const res = await fetch('/api/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: searchId }),
      });
      const data = await res.json();
      if (data.ok) {
        setDisplayedRecords(data.records);
      }
    } finally {
      setBusyAction('');
    }
  };

  const handleFilter = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusyAction('filter');
    try {
      const res = await fetch('/api/filter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(filterCriteria),
      });
      const data = await res.json();
      if (data.ok) {
        setDisplayedRecords(data.records);
      }
    } finally {
      setBusyAction('');
    }
  };

  const handleResetFilters = () => {
    setSearchId('');
    setFilterCriteria({
      survey_date: '',
      wellness_category: '',
      stress_category: '',
      activity_category: '',
      min_sleep: '',
      max_sleep: '',
    });
    setDisplayedRecords(null);
  };

  const handleDeleteRecord = async (recordId: string) => {
    setBusyAction(`delete-${recordId}`);
    try {
      const res = await fetch(`/api/responses/${encodeURIComponent(recordId)}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (data.ok) {
        setState({
          report: data.report,
          records: data.records,
          charts: data.charts,
          startup_warnings: data.startup_warnings,
        });
        setDisplayedRecords((prev) =>
          prev ? prev.filter((item) => item.record_id !== recordId) : null
        );
        setFeedback({ kind: 'success', text: `Deleted anonymous record ${recordId}.` });
      }
    } finally {
      setBusyAction('');
    }
  };

  const handleGenerateCharts = async () => {
    setBusyAction('charts');
    setChartNote('');
    try {
      const res = await fetch('/api/charts/generate', { method: 'POST' });
      const data = await res.json();
      if (data.report) {
        setState({
          report: data.report,
          records: data.records,
          charts: data.charts,
          startup_warnings: data.startup_warnings,
        });
      }
      setChartTimestamp(Date.now());
      if (data.ok) {
        setChartNote(
          data.warning
            ? `Generated ${data.files.length} PNG charts (${data.renderer}). ${data.warning}`
            : `Generated ${data.files.length} PNG charts using ${data.renderer}.`
        );
      } else {
        setChartNote(data.warning || 'Could not generate charts.');
      }
    } finally {
      setBusyAction('');
    }
  };

  const handleLoadSample = async () => {
    setBusyAction('sample');
    try {
      const res = await fetch('/api/sample-data', { method: 'POST' });
      const data = await res.json();
      if (data.ok) {
        setState({
          report: data.report,
          records: data.records,
          charts: data.charts,
          startup_warnings: data.startup_warnings,
        });
        setImportSummary(data.summary);
        setDisplayedRecords(null);
        setFeedback({
          kind: 'success',
          text: `Sample dataset processed: ${data.summary.imported_count} added, ${data.summary.duplicate_count} duplicates skipped.`,
        });
      }
    } finally {
      setBusyAction('');
    }
  };

  const handleBulkCsvImport = async () => {
    if (!csvText.trim()) return;
    setBusyAction('import-csv');
    try {
      const res = await fetch('/api/import-csv', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ csv_content: csvText }),
      });
      const data = await res.json();
      if (data.ok) {
        setState({
          report: data.report,
          records: data.records,
          charts: data.charts,
          startup_warnings: data.startup_warnings,
        });
        setImportSummary(data.summary);
        setDisplayedRecords(null);
        setFeedback({
          kind: 'success',
          text: `CSV import finished: ${data.summary.imported_count} imported, ${data.summary.invalid_count} invalid, ${data.summary.duplicate_count} duplicates.`,
        });
      } else {
        setFeedback({ kind: 'error', text: data.error || 'CSV import failed.' });
      }
    } finally {
      setBusyAction('');
    }
  };

  const handleCsvFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setCsvText(reader.result);
      }
    };
    reader.readAsText(file);
  };

  const handleExportReports = async () => {
    setBusyAction('export');
    try {
      const res = await fetch('/api/reports/export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ formats: ['md', 'txt', 'csv'] }),
      });
      const data = await res.json();
      if (data.ok) {
        setExecutiveText(data.summary_txt || data.summary_md || '');
        setFeedback({
          kind: 'success',
          text: 'Exported Markdown, Plain Text, and CSV executive reports to reports/.',
        });
      }
    } finally {
      setBusyAction('');
    }
  };

  const handleClearData = async () => {
    setBusyAction('clear');
    try {
      const res = await fetch('/api/clear', { method: 'POST' });
      const data = await res.json();
      if (data.ok) {
        setState({
          report: data.report,
          records: data.records,
          charts: data.charts,
          startup_warnings: data.startup_warnings,
        });
        setDisplayedRecords(null);
        setConfirmClear(false);
        setFeedback({ kind: 'success', text: `Cleared ${data.removed} record(s) from storage.` });
      }
    } finally {
      setBusyAction('');
    }
  };

  const handleRunTests = async () => {
    setBusyAction('tests');
    try {
      const res = await fetch('/api/tests/run', { method: 'POST' });
      const data = await res.json();
      setTestOutput(data.output || 'No test output.');
    } finally {
      setBusyAction('');
    }
  };

  const report = state?.report;
  const visibleRecords = displayedRecords ?? state?.records ?? [];

  const navItems: { key: TabKey; label: string; icon: React.ReactNode }[] = [
    { key: 'overview', label: 'Analytics Dashboard', icon: <LayoutDashboard className="h-4 w-4" /> },
    { key: 'submit', label: 'Add Survey Response', icon: <PlusCircle className="h-4 w-4" /> },
    { key: 'records', label: 'Records & Search', icon: <Search className="h-4 w-4" /> },
    { key: 'charts', label: 'Charts & Visuals', icon: <BarChart3 className="h-4 w-4" /> },
    { key: 'reports', label: 'Reports, Import & Tests', icon: <FileText className="h-4 w-4" /> },
  ];

  const activeTitle = navItems.find((item) => item.key === activeTab)?.label ?? 'Analytics Dashboard';

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col lg:flex-row">
      {/* Sidebar Navigation */}
      <aside className="w-full lg:w-64 bg-slate-900 text-slate-100 shrink-0 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-slate-800">
        <div>
          <div className="px-6 py-6 border-b border-slate-800">
            <div className="font-display text-base font-bold tracking-tight text-white">
              Wellness Survey Visualizer
            </div>
            <p className="mt-1.5 text-xs text-slate-400 leading-relaxed">
              Project #40 · Health &amp; Wellbeing · LocalImpact Challenge
            </p>
          </div>

          <nav className="p-3 space-y-1" aria-label="Primary Navigation">
            {navItems.map((item) => {
              const active = activeTab === item.key;
              return (
                <button
                  key={item.key}
                  type="button"
                  onClick={() => setActiveTab(item.key)}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
                    active
                      ? 'bg-teal-600 text-white'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-5 border-t border-slate-800 space-y-2 text-xs text-slate-400">
          <div className="flex items-center gap-2 text-slate-200 font-medium">
            <ShieldCheck className="h-4 w-4 text-teal-400 shrink-0" />
            <span>Strictly Anonymous &amp; Offline</span>
          </div>
          <p className="leading-relaxed">
            No names, emails, or phone numbers collected. Non-diagnostic statistical summary only.
          </p>
        </div>
      </aside>

      {/* Main Content Workspace */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar Contract: 3 zones separated by gap-8 */}
        <header className="bg-white border-b border-slate-200 px-6 lg:px-8 py-4 flex items-center justify-between gap-8">
          <div className="text-sm font-medium text-slate-600 whitespace-nowrap truncate">
            <span className="text-slate-900 font-semibold">{activeTitle}</span>
            <span className="mx-2 text-slate-300" aria-hidden="true">/</span>
            <span className="font-mono tabular-nums text-slate-500">
              {report ? `${report.total_responses} responses` : 'Loading...'}
            </span>
          </div>

          <nav className="hidden xl:flex items-center gap-6 text-sm font-medium text-slate-600">
            <button
              type="button"
              onClick={() => setActiveTab('overview')}
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Overview
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('records')}
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Search
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('charts')}
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Charts
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('reports')}
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Exports
            </button>
          </nav>

          <div className="shrink-0">
            <button
              type="button"
              onClick={() => setActiveTab('submit')}
              className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
            >
              Add Survey Entry
            </button>
          </div>
        </header>

        <main className="flex-1 p-6 lg:p-8 max-w-7xl w-full mx-auto space-y-6">
          {/* Feedback Banner */}
          {feedback && (
            <div
              role="status"
              className={`flex items-center justify-between gap-4 px-4 py-3 rounded-lg border text-sm ${
                feedback.kind === 'success'
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : 'bg-red-50 border-red-200 text-red-900'
              }`}
            >
              <div className="flex items-center gap-2.5">
                {feedback.kind === 'success' ? (
                  <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
                ) : (
                  <AlertTriangle className="h-4 w-4 text-red-600 shrink-0" />
                )}
                <span>{feedback.text}</span>
              </div>
              <button
                type="button"
                onClick={() => setFeedback(null)}
                className="text-xs font-medium underline hover:no-underline shrink-0"
              >
                Dismiss
              </button>
            </div>
          )}

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="h-24 bg-white border border-slate-200 rounded-lg animate-pulse" />
              ))}
            </div>
          ) : null}

          {/* TAB 1: ANALYTICS DASHBOARD */}
          {!loading && activeTab === 'overview' && report && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
                <div>
                  <h1 className="font-display text-2xl font-bold tracking-tight text-slate-900">
                    Understand Wellness. Discover Trends. Make Better Decisions.
                  </h1>
                  <p className="mt-1 text-sm text-slate-600">
                    Survey Window: <span className="font-mono tabular-nums">{report.date_range[0]}</span> to{' '}
                    <span className="font-mono tabular-nums">{report.date_range[1]}</span>
                    <span className="mx-2 text-slate-300" aria-hidden="true">·</span>
                    <span>Python CSV/JSON Persistence</span>
                  </p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={fetchState}
                    className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap"
                  >
                    <RefreshCw className="h-3.5 w-3.5" />
                    <span>Refresh</span>
                  </button>
                  {report.is_empty && (
                    <button
                      type="button"
                      onClick={handleLoadSample}
                      disabled={busyAction === 'sample'}
                      className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-teal-600 rounded-lg hover:bg-teal-700 transition-colors whitespace-nowrap"
                    >
                      <span>Load 40 Sample Records</span>
                    </button>
                  )}
                </div>
              </div>

              {report.is_empty ? (
                <div className="bg-white border border-slate-200 rounded-lg p-10 text-center space-y-4">
                  <Activity className="h-8 w-8 text-slate-400 mx-auto" />
                  <h2 className="font-display text-lg font-semibold text-slate-900">
                    No Survey Responses Stored Yet
                  </h2>
                  <p className="text-sm text-slate-600 max-w-md mx-auto">
                    Add an anonymous wellness check-in or load the 40 synthetic demonstration records to compute statistics, trend lines, and charts.
                  </p>
                  <div className="flex items-center justify-center gap-3 pt-2">
                    <button
                      type="button"
                      onClick={() => setActiveTab('submit')}
                      className="px-4 py-2 text-sm font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800"
                    >
                      Log First Entry
                    </button>
                    <button
                      type="button"
                      onClick={handleLoadSample}
                      className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
                    >
                      Load 40 Sample Records
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  {/* 5-Column KPI Strip */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-4">
                    <div className="bg-white border border-slate-200 rounded-lg p-5">
                      <div className="text-xs font-medium text-slate-500">Total Responses</div>
                      <div className="mt-2 font-mono tabular-nums text-2xl font-semibold text-slate-900">
                        {report.total_responses}
                      </div>
                      <div className="mt-1 text-xs text-slate-500">Anonymous records</div>
                    </div>

                    <div className="bg-white border border-slate-200 rounded-lg p-5">
                      <div className="text-xs font-medium text-slate-500">Avg Wellness</div>
                      <div className="mt-2 font-mono tabular-nums text-2xl font-semibold text-teal-700">
                        {report.wellness_stats?.average}/10
                      </div>
                      <div className="mt-1 text-xs text-slate-500 font-mono tabular-nums">
                        Med {report.wellness_stats?.median_value} · Delta {report.wellness_trend_delta >= 0 ? '+' : ''}
                        {report.wellness_trend_delta}
                      </div>
                    </div>

                    <div className="bg-white border border-slate-200 rounded-lg p-5">
                      <div className="text-xs font-medium text-slate-500">Avg Sleep Duration</div>
                      <div className="mt-2 font-mono tabular-nums text-2xl font-semibold text-slate-900">
                        {report.sleep_stats?.average}h
                      </div>
                      <div className="mt-1 text-xs text-slate-500 font-mono tabular-nums">
                        Range {report.sleep_stats?.minimum}–{report.sleep_stats?.maximum}h
                      </div>
                    </div>

                    <div className="bg-white border border-slate-200 rounded-lg p-5">
                      <div className="text-xs font-medium text-slate-500">Avg Stress Level</div>
                      <div className="mt-2 font-mono tabular-nums text-2xl font-semibold text-amber-700">
                        {report.stress_stats?.average}/10
                      </div>
                      <div className="mt-1 text-xs text-slate-500 font-mono tabular-nums">
                        Med {report.stress_stats?.median_value} · Delta {report.stress_trend_delta >= 0 ? '+' : ''}
                        {report.stress_trend_delta}
                      </div>
                    </div>

                    <div className="bg-white border border-slate-200 rounded-lg p-5">
                      <div className="text-xs font-medium text-slate-500">Avg Daily Activity</div>
                      <div className="mt-2 font-mono tabular-nums text-2xl font-semibold text-slate-900">
                        {report.activity_stats?.average}m
                      </div>
                      <div className="mt-1 text-xs text-slate-500 font-mono tabular-nums">
                        Mood avg {report.mood_stats?.average}/10
                      </div>
                    </div>
                  </div>

                  {/* Distributions Grid */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {[
                      { title: 'Wellness Category Distribution', data: report.wellness_distribution, bar: 'bg-teal-600' },
                      { title: 'Stress Level Distribution', data: report.stress_distribution, bar: 'bg-amber-600' },
                      { title: 'Sleep Duration Distribution', data: report.sleep_distribution, bar: 'bg-blue-600' },
                      { title: 'Physical Activity Distribution', data: report.activity_distribution, bar: 'bg-emerald-600' },
                    ].map((section) => (
                      <section key={section.title} className="bg-white border border-slate-200 rounded-lg p-6 space-y-4">
                        <h2 className="font-display text-base font-semibold text-slate-900">
                          {section.title}
                        </h2>
                        <div className="space-y-3">
                          {section.data &&
                            Object.entries(section.data.counts).map(([label, count]) => {
                              const pct = section.data?.percentages[label] ?? 0;
                              return (
                                <div key={label} className="space-y-1">
                                  <div className="flex items-center justify-between text-xs">
                                    <span className="font-medium text-slate-700">{label}</span>
                                    <span className="font-mono tabular-nums text-slate-600">
                                      {count} ({pct}%)
                                    </span>
                                  </div>
                                  <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                                    <div
                                      className={`h-full ${section.bar} rounded-full`}
                                      style={{ width: `${Math.min(100, pct)}%` }}
                                    />
                                  </div>
                                </div>
                              );
                            })}
                        </div>
                      </section>
                    ))}
                  </div>

                  {/* Observations & Threshold Warnings */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <section className="bg-white border border-slate-200 rounded-lg p-6 space-y-3">
                      <h2 className="font-display text-base font-semibold text-slate-900">
                        Analytical Observations
                      </h2>
                      <ul className="space-y-2.5 text-sm text-slate-700">
                        {report.observations.map((obs, idx) => (
                          <li key={idx} className="leading-relaxed border-b border-slate-100 pb-2 last:border-b-0 last:pb-0">
                            {obs}
                          </li>
                        ))}
                      </ul>
                    </section>

                    <section className="bg-white border border-slate-200 rounded-lg p-6 space-y-3">
                      <div className="flex items-center justify-between gap-2">
                        <h2 className="font-display text-base font-semibold text-slate-900">
                          Threshold Warning Indicators
                        </h2>
                        <span className="text-xs font-mono tabular-nums text-amber-700">
                          {report.threshold_warnings.length} flag(s)
                        </span>
                      </div>
                      <p className="text-xs text-slate-500">{report.disclaimer}</p>
                      <div className="max-h-56 overflow-y-auto divide-y divide-slate-100">
                        {report.threshold_warnings.length === 0 ? (
                          <p className="text-sm text-slate-600 py-2">No statistical threshold flags triggered.</p>
                        ) : (
                          report.threshold_warnings.map((warn, idx) => (
                            <div key={idx} className="py-2 text-xs text-slate-700 flex items-start gap-2">
                              <AlertTriangle className="h-3.5 w-3.5 text-amber-600 shrink-0 mt-0.5" />
                              <span>{warn}</span>
                            </div>
                          ))
                        )}
                      </div>
                    </section>
                  </div>

                  {/* Chronological Trends Table */}
                  <section className="bg-white border border-slate-200 rounded-lg overflow-hidden">
                    <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
                      <h2 className="font-display text-base font-semibold text-slate-900">
                        Chronological Survey Trends
                      </h2>
                      <span className="text-xs text-slate-500 font-mono tabular-nums">
                        {report.trends.length} survey date(s)
                      </span>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm text-left">
                        <thead className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                          <tr>
                            <th className="px-4 py-3">Date</th>
                            <th className="px-4 py-3 text-right">Responses</th>
                            <th className="px-4 py-3 text-right">Avg Sleep (h)</th>
                            <th className="px-4 py-3 text-right">Avg Activity (m)</th>
                            <th className="px-4 py-3 text-right">Avg Stress</th>
                            <th className="px-4 py-3 text-right">Avg Mood</th>
                            <th className="px-4 py-3 text-right">Avg Wellness</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 font-mono tabular-nums text-xs">
                          {report.trends.slice(-14).map((pt) => (
                            <tr key={pt.survey_date} className="hover:bg-slate-50">
                              <td className="px-4 py-2.5 text-slate-900 font-medium">{pt.survey_date}</td>
                              <td className="px-4 py-2.5 text-right text-slate-600">{pt.count}</td>
                              <td className="px-4 py-2.5 text-right text-slate-700">{pt.avg_sleep.toFixed(2)}</td>
                              <td className="px-4 py-2.5 text-right text-slate-700">{pt.avg_activity.toFixed(1)}</td>
                              <td className="px-4 py-2.5 text-right text-amber-700">{pt.avg_stress.toFixed(2)}</td>
                              <td className="px-4 py-2.5 text-right text-blue-700">{pt.avg_mood.toFixed(2)}</td>
                              <td className="px-4 py-2.5 text-right text-teal-700 font-semibold">{pt.avg_wellness.toFixed(2)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </section>
                </>
              )}
            </div>
          )}

          {/* TAB 2: ADD SURVEY RESPONSE */}
          {!loading && activeTab === 'submit' && (
            <div className="max-w-2xl space-y-6">
              <div>
                <h1 className="font-display text-2xl font-bold tracking-tight text-slate-900">
                  Add Anonymous Survey Response
                </h1>
                <p className="mt-1 text-sm text-slate-600">
                  Validated directly by Python <code className="font-mono text-xs">core/validation.py</code> and saved immediately to local CSV and JSON.
                </p>
              </div>

              {formErrors.length > 0 && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4 space-y-1.5">
                  <div className="text-sm font-semibold text-red-900">Validation Errors</div>
                  <ul className="list-disc list-inside text-xs text-red-800 space-y-1">
                    {formErrors.map((err, i) => (
                      <li key={i}>{err}</li>
                    ))}
                  </ul>
                </div>
              )}

              {formWarnings.length > 0 && (
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 space-y-1.5">
                  <div className="text-sm font-semibold text-amber-900">
                    Statistical Threshold Flags (Non-Diagnostic)
                  </div>
                  <ul className="list-disc list-inside text-xs text-amber-800 space-y-1">
                    {formWarnings.map((warn, i) => (
                      <li key={i}>{warn}</li>
                    ))}
                  </ul>
                </div>
              )}

              <form onSubmit={handleSubmitEntry} className="bg-white border border-slate-200 rounded-lg p-6 space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Record ID (Optional — auto-generated if blank)
                    </label>
                    <input
                      type="text"
                      value={formState.record_id}
                      onChange={(e) => setFormState({ ...formState, record_id: e.target.value })}
                      placeholder="e.g. WSV-1042"
                      className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Survey Date (YYYY-MM-DD)
                    </label>
                    <input
                      type="text"
                      value={formState.survey_date}
                      onChange={(e) => setFormState({ ...formState, survey_date: e.target.value })}
                      placeholder="2026-11-24"
                      className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Age Group (Optional)
                    </label>
                    <select
                      value={formState.age_group}
                      onChange={(e) => setFormState({ ...formState, age_group: e.target.value })}
                      className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-teal-600"
                    >
                      {AGE_GROUPS.map((g) => (
                        <option key={g} value={g}>
                          {g}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Sleep Duration (0.0 – 24.0 hours)
                    </label>
                    <input
                      type="text"
                      value={formState.sleep_duration}
                      onChange={(e) => setFormState({ ...formState, sleep_duration: e.target.value })}
                      className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Physical Activity (0 – 600 min/day)
                    </label>
                    <input
                      type="text"
                      value={formState.physical_activity}
                      onChange={(e) => setFormState({ ...formState, physical_activity: e.target.value })}
                      className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Stress Level (1 – 10)
                    </label>
                    <input
                      type="text"
                      value={formState.stress_level}
                      onChange={(e) => setFormState({ ...formState, stress_level: e.target.value })}
                      className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Mood Rating (1 – 10)
                    </label>
                    <input
                      type="text"
                      value={formState.mood_rating}
                      onChange={(e) => setFormState({ ...formState, mood_rating: e.target.value })}
                      className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      General Wellness Rating (1 – 10)
                    </label>
                    <input
                      type="text"
                      value={formState.general_wellness}
                      onChange={(e) => setFormState({ ...formState, general_wellness: e.target.value })}
                      className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
                    />
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between gap-4 border-t border-slate-100">
                  <span className="text-xs text-slate-500">
                    Try entering an invalid value (e.g. -3 sleep) to test defensive validation.
                  </span>
                  <button
                    type="submit"
                    disabled={busyAction === 'submit'}
                    className="px-5 py-2.5 text-sm font-semibold text-white bg-teal-600 rounded-lg hover:bg-teal-700 transition-colors whitespace-nowrap shrink-0"
                  >
                    {busyAction === 'submit' ? 'Validating...' : 'Save Response'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* TAB 3: RECORDS, SEARCH & FILTER */}
          {!loading && activeTab === 'records' && (
            <div className="space-y-6">
              <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
                <div>
                  <h1 className="font-display text-2xl font-bold tracking-tight text-slate-900">
                    Survey Records, Search &amp; Filtering
                  </h1>
                  <p className="mt-1 text-sm text-slate-600">
                    Showing <span className="font-mono tabular-nums font-semibold">{visibleRecords.length}</span> anonymous record(s)
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleResetFilters}
                  className="px-3.5 py-2 text-xs font-medium bg-white border border-slate-200 rounded-lg hover:bg-slate-50 self-start"
                >
                  Reset Search &amp; Filters
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Search by Record ID */}
                <form onSubmit={handleSearch} className="bg-white border border-slate-200 rounded-lg p-5 space-y-3">
                  <h2 className="font-display text-sm font-semibold text-slate-900">Search by Record ID</h2>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={searchId}
                      onChange={(e) => setSearchId(e.target.value)}
                      placeholder="e.g. SYN-0001 or DEMO"
                      className="flex-1 min-w-0 px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 whitespace-nowrap"
                    >
                      Search
                    </button>
                  </div>
                </form>

                {/* Multi-Criteria Filter */}
                <form onSubmit={handleFilter} className="lg:col-span-2 bg-white border border-slate-200 rounded-lg p-5 space-y-3">
                  <div className="flex items-center justify-between">
                    <h2 className="font-display text-sm font-semibold text-slate-900 flex items-center gap-2">
                      <Filter className="h-4 w-4 text-slate-500" />
                      <span>Filter Records</span>
                    </h2>
                    <button
                      type="submit"
                      className="px-4 py-1.5 text-xs font-semibold text-white bg-teal-600 rounded-lg hover:bg-teal-700 whitespace-nowrap"
                    >
                      Apply Filters
                    </button>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    <input
                      type="text"
                      value={filterCriteria.survey_date}
                      onChange={(e) => setFilterCriteria({ ...filterCriteria, survey_date: e.target.value })}
                      placeholder="Date YYYY-MM-DD"
                      className="px-3 py-1.5 text-xs font-mono border border-slate-300 rounded-lg"
                    />
                    <select
                      value={filterCriteria.wellness_category}
                      onChange={(e) => setFilterCriteria({ ...filterCriteria, wellness_category: e.target.value })}
                      className="px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                    >
                      <option value="">All Wellness Tiers</option>
                      <option value="Low">Low Wellness (1-4)</option>
                      <option value="Moderate">Moderate Wellness (5-7)</option>
                      <option value="High">High Wellness (8-10)</option>
                    </select>
                    <select
                      value={filterCriteria.stress_category}
                      onChange={(e) => setFilterCriteria({ ...filterCriteria, stress_category: e.target.value })}
                      className="px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                    >
                      <option value="">All Stress Tiers</option>
                      <option value="Low">Low Stress (1-3)</option>
                      <option value="Moderate">Moderate Stress (4-6)</option>
                      <option value="High">High Stress (7-10)</option>
                    </select>
                    <select
                      value={filterCriteria.activity_category}
                      onChange={(e) => setFilterCriteria({ ...filterCriteria, activity_category: e.target.value })}
                      className="px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                    >
                      <option value="">All Activity Levels</option>
                      <option value="Sedentary">Sedentary (&lt;30m)</option>
                      <option value="Moderate">Moderate (30-59m)</option>
                      <option value="Active">Active (60m+)</option>
                    </select>
                    <input
                      type="text"
                      value={filterCriteria.min_sleep}
                      onChange={(e) => setFilterCriteria({ ...filterCriteria, min_sleep: e.target.value })}
                      placeholder="Min Sleep (hrs)"
                      className="px-3 py-1.5 text-xs font-mono border border-slate-300 rounded-lg"
                    />
                    <input
                      type="text"
                      value={filterCriteria.max_sleep}
                      onChange={(e) => setFilterCriteria({ ...filterCriteria, max_sleep: e.target.value })}
                      placeholder="Max Sleep (hrs)"
                      className="px-3 py-1.5 text-xs font-mono border border-slate-300 rounded-lg"
                    />
                  </div>
                </form>
              </div>

              {/* Records Table */}
              <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 border-b border-slate-200 font-semibold text-slate-600">
                      <tr>
                        <th className="px-4 py-3">Record ID</th>
                        <th className="px-4 py-3">Date</th>
                        <th className="px-4 py-3">Age Group</th>
                        <th className="px-4 py-3 text-right">Sleep</th>
                        <th className="px-4 py-3 text-right">Activity</th>
                        <th className="px-4 py-3 text-right">Stress</th>
                        <th className="px-4 py-3 text-right">Mood</th>
                        <th className="px-4 py-3 text-right">Wellness</th>
                        <th className="px-4 py-3">Origin</th>
                        <th className="px-4 py-3 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-mono tabular-nums">
                      {visibleRecords.length === 0 ? (
                        <tr>
                          <td colSpan={10} className="px-4 py-8 text-center font-sans text-sm text-slate-500">
                            No matching anonymous survey records found.
                          </td>
                        </tr>
                      ) : (
                        visibleRecords.map((rec) => (
                          <tr key={rec.record_id} className="hover:bg-slate-50">
                            <td className="px-4 py-2.5 font-semibold text-slate-900">{rec.record_id}</td>
                            <td className="px-4 py-2.5 text-slate-700">{rec.survey_date}</td>
                            <td className="px-4 py-2.5 font-sans text-slate-600">{rec.age_group}</td>
                            <td className="px-4 py-2.5 text-right text-slate-700">{rec.sleep_duration.toFixed(1)}h</td>
                            <td className="px-4 py-2.5 text-right text-slate-700">{rec.physical_activity}m</td>
                            <td className="px-4 py-2.5 text-right">
                              <span className={rec.stress_level >= 7 ? 'text-red-700 font-semibold' : 'text-slate-700'}>
                                {rec.stress_level} ({stressTierLabel(rec.stress_level)})
                              </span>
                            </td>
                            <td className="px-4 py-2.5 text-right text-slate-700">{rec.mood_rating}</td>
                            <td className="px-4 py-2.5 text-right">
                              <span className={rec.general_wellness >= 8 ? 'text-teal-700 font-semibold' : 'text-slate-700'}>
                                {rec.general_wellness} ({wellnessTierLabel(rec.general_wellness)})
                              </span>
                            </td>
                            <td className="px-4 py-2.5 font-sans text-slate-500">{rec.data_origin}</td>
                            <td className="px-4 py-2.5 text-right">
                              <button
                                type="button"
                                onClick={() => handleDeleteRecord(rec.record_id)}
                                disabled={busyAction === `delete-${rec.record_id}`}
                                className="inline-flex items-center gap-1 text-red-700 hover:text-red-900 font-sans font-medium"
                                aria-label={`Delete ${rec.record_id}`}
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                                <span>Delete</span>
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: CHARTS & VISUALIZATIONS */}
          {!loading && activeTab === 'charts' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
                <div>
                  <h1 className="font-display text-2xl font-bold tracking-tight text-slate-900">
                    Generated PNG Visualizations
                  </h1>
                  <p className="mt-1 text-sm text-slate-600">
                    All 6 distribution and time-series figures saved to <code className="font-mono text-xs">reports/charts/</code>.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleGenerateCharts}
                  disabled={busyAction === 'charts'}
                  className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-teal-600 rounded-lg hover:bg-teal-700 transition-colors whitespace-nowrap shrink-0"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                  <span>{busyAction === 'charts' ? 'Generating...' : 'Regenerate All 6 Charts'}</span>
                </button>
              </div>

              {chartNote && (
                <div className="bg-white border border-slate-200 rounded-lg px-4 py-3 text-xs text-slate-700">
                  {chartNote}
                </div>
              )}

              {!state?.charts || state.charts.length === 0 ? (
                <div className="bg-white border border-slate-200 rounded-lg p-10 text-center space-y-3">
                  <BarChart3 className="h-8 w-8 text-slate-400 mx-auto" />
                  <p className="text-sm text-slate-600">
                    Click &ldquo;Regenerate All 6 Charts&rdquo; to generate PNG chart files from current survey responses.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {state.charts.map((filename) => (
                    <figure key={filename} className="bg-white border border-slate-200 rounded-lg overflow-hidden">
                      <figcaption className="px-5 py-3 border-b border-slate-100 flex items-center justify-between text-sm font-semibold text-slate-900">
                        <span>{CHART_TITLES[filename] ?? filename}</span>
                        <span className="text-xs font-mono font-normal text-slate-500">{filename}</span>
                      </figcaption>
                      <div className="p-4 bg-white">
                        <img
                          src={`/api/charts/${encodeURIComponent(filename)}?t=${chartTimestamp}`}
                          alt={CHART_TITLES[filename] ?? filename}
                          className="w-full h-auto rounded border border-slate-100"
                        />
                      </div>
                    </figure>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 5: REPORTS, BULK IMPORT & AUTOMATED TESTS */}
          {!loading && activeTab === 'reports' && (
            <div className="space-y-6">
              <div>
                <h1 className="font-display text-2xl font-bold tracking-tight text-slate-900">
                  Executive Reports, Bulk CSV Import &amp; Verification
                </h1>
                <p className="mt-1 text-sm text-slate-600">
                  Export Markdown/TXT/CSV reports, bulk import validated CSV datasets, manage synthetic sample data, or run the live Python unit test suite.
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Executive Report Export */}
                <section className="bg-white border border-slate-200 rounded-lg p-6 space-y-4">
                  <h2 className="font-display text-base font-semibold text-slate-900">
                    Executive Summary &amp; Exports
                  </h2>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Generates structured reports containing total responses, metric averages, category distributions, chronological trends, statistical threshold warnings, and chart references.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={handleExportReports}
                      disabled={busyAction === 'export'}
                      className="px-4 py-2 text-xs font-semibold text-white bg-teal-600 rounded-lg hover:bg-teal-700 whitespace-nowrap"
                    >
                      {busyAction === 'export' ? 'Exporting...' : 'Generate & Export All (MD + TXT + CSV)'}
                    </button>
                    <a
                      href="/api/reports/download/executive_wellness_report.md"
                      className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
                    >
                      <Download className="h-3.5 w-3.5" />
                      <span>.MD</span>
                    </a>
                    <a
                      href="/api/reports/download/executive_wellness_report.txt"
                      className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
                    >
                      <Download className="h-3.5 w-3.5" />
                      <span>.TXT</span>
                    </a>
                    <a
                      href="/api/reports/download/executive_wellness_report_summary.csv"
                      className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
                    >
                      <Download className="h-3.5 w-3.5" />
                      <span>.CSV</span>
                    </a>
                  </div>

                  {executiveText && (
                    <pre className="p-4 bg-slate-900 text-slate-100 rounded-lg text-xs font-mono overflow-x-auto max-h-72 leading-relaxed">
                      {executiveText}
                    </pre>
                  )}
                </section>

                {/* Bulk CSV Import & Sample Data */}
                <section className="bg-white border border-slate-200 rounded-lg p-6 space-y-4">
                  <div className="flex items-center justify-between gap-2">
                    <h2 className="font-display text-base font-semibold text-slate-900">
                      Bulk CSV Import &amp; Data Management
                    </h2>
                    <button
                      type="button"
                      onClick={handleLoadSample}
                      disabled={busyAction === 'sample'}
                      className="px-3 py-1.5 text-xs font-medium bg-slate-900 text-white rounded-lg hover:bg-slate-800 whitespace-nowrap"
                    >
                      Load 40 Sample Records
                    </button>
                  </div>

                  <div className="space-y-2">
                    <label className="inline-flex items-center gap-2 px-3 py-1.5 text-xs font-medium bg-slate-100 border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-200">
                      <Upload className="h-3.5 w-3.5" />
                      <span>Choose CSV File</span>
                      <input type="file" accept=".csv,text/csv" onChange={handleCsvFileUpload} className="sr-only" />
                    </label>
                    <textarea
                      rows={5}
                      value={csvText}
                      onChange={(e) => setCsvText(e.target.value)}
                      placeholder="survey_date,age_group,sleep_duration,physical_activity,stress_level,mood_rating,general_wellness&#10;2026-11-21,25-34,7.5,45,4,8,8"
                      className="w-full p-3 text-xs font-mono border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
                    />
                  </div>

                  <div className="flex items-center justify-between gap-3">
                    <button
                      type="button"
                      onClick={handleBulkCsvImport}
                      disabled={!csvText.trim() || busyAction === 'import-csv'}
                      className="px-4 py-2 text-xs font-semibold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:opacity-50"
                    >
                      Validate &amp; Import CSV Rows
                    </button>

                    {!confirmClear ? (
                      <button
                        type="button"
                        onClick={() => setConfirmClear(true)}
                        className="px-3 py-2 text-xs font-medium text-red-700 border border-red-200 rounded-lg hover:bg-red-50"
                      >
                        Clear Stored Data
                      </button>
                    ) : (
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={handleClearData}
                          className="px-3 py-1.5 text-xs font-semibold text-white bg-red-600 rounded-lg hover:bg-red-700"
                        >
                          Confirm Clear All
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmClear(false)}
                          className="px-2.5 py-1.5 text-xs text-slate-600 hover:text-slate-900"
                        >
                          Cancel
                        </button>
                      </div>
                    )}
                  </div>

                  {importSummary && (
                    <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs space-y-1 font-mono tabular-nums">
                      <div>
                        Scanned: {importSummary.total_rows} · Imported: {importSummary.imported_count} ·
                        Duplicates: {importSummary.duplicate_count} · Invalid: {importSummary.invalid_count}
                      </div>
                      {importSummary.errors.length > 0 && (
                        <div className="text-amber-800 pt-1">
                          {importSummary.errors.slice(0, 4).join(' | ')}
                        </div>
                      )}
                    </div>
                  )}
                </section>
              </div>

              {/* Automated Python Test Suite Runner */}
              <section className="bg-white border border-slate-200 rounded-lg p-6 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h2 className="font-display text-base font-semibold text-slate-900 flex items-center gap-2">
                      <FlaskConical className="h-4 w-4 text-teal-600" />
                      <span>Python Automated Test Suite (unittest)</span>
                    </h2>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Executes <code className="font-mono">python3 -m unittest discover -s tests -v</code> live on the backend.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleRunTests}
                    disabled={busyAction === 'tests'}
                    className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 whitespace-nowrap self-start sm:self-auto"
                  >
                    {busyAction === 'tests' ? 'Running Tests...' : 'Run Unit Tests'}
                  </button>
                </div>

                {testOutput && (
                  <pre className="p-4 bg-slate-900 text-emerald-300 rounded-lg text-xs font-mono overflow-x-auto max-h-72 leading-relaxed">
                    {testOutput}
                  </pre>
                )}
              </section>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
