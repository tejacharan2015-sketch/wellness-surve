"""User interface package (Terminal UI and optional Tkinter GUI)."""
