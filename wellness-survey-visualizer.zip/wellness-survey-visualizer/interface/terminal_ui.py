"""Interactive 12-option menu-driven terminal interface for Wellness Survey Visualizer."""

from __future__ import annotations

from datetime import date
from pathlib import Path
import sys
from typing import Callable, List, Optional, TypeVar

from config import (
    ACTIVITY_MAX_MINUTES,
    ACTIVITY_MIN_MINUTES,
    APP_NAME,
    APP_TAGLINE,
    APP_VERSION,
    CHALLENGE_NAME,
    MEDICAL_DISCLAIMER,
    PRIVACY_NOTICE,
    PROJECT_DOMAIN,
    PROJECT_NUMBER,
    SAMPLE_CSV_PATH,
    SCALE_MAX,
    SCALE_MIN,
    SLEEP_MAX_HOURS,
    SLEEP_MIN_HOURS,
    VALID_AGE_GROUPS,
)
from core.models import SurveyRecord, generate_record_id
from core.search import FilterCriteria
from core.survey_manager import SurveyManager
from core.validation import (
    ValidationError,
    validate_age_group,
    validate_physical_activity,
    validate_record_id,
    validate_scale_rating,
    validate_sleep_duration,
    validate_survey_date,
)
from visualization.dashboard import render_dashboard_text

T = TypeVar("T")


class TerminalUI:
    """Menu-driven offline terminal application for anonymous wellness survey analysis."""

    def __init__(self, manager: Optional[SurveyManager] = None) -> None:
        self.manager = manager or SurveyManager()

    def print_welcome_screen(self) -> None:
        """Render the official welcome banner with version, tagline, and status."""
        border = "=" * 74
        total = len(self.manager.records)
        status = (
            f"READY | {total} anonymous record(s) loaded from local storage"
            if total > 0
            else "READY | Empty dataset (0 records) — add entries or load sample data"
        )
        print(border)
        print(f"  {APP_NAME}  (v{APP_VERSION})")
        print(f"  {APP_TAGLINE}")
        print("-" * 74)
        print(f"  Project      : {PROJECT_NUMBER} | {PROJECT_DOMAIN} | {CHALLENGE_NAME}")
        print("  Description  : Offline anonymous wellness survey collector, analyzer,")
        print("                 trend visualizer, and executive report generator.")
        print(f"  Status       : {status}")
        print(f"  Privacy      : {PRIVACY_NOTICE}")
        print(border)
        if self.manager.startup_warnings:
            print("  [Storage Notices]")
            for warn in self.manager.startup_warnings:
                print(f"   - {warn}")
            print(border)

    def print_main_menu(self) -> None:
        """Display the 12 mandatory navigation options."""
        print("\nMAIN NAVIGATION")
        print("-" * 40)
        print("  1. Add New Survey Response")
        print("  2. View All Responses")
        print("  3. Search Responses")
        print("  4. Filter Responses")
        print("  5. View Analytics Dashboard")
        print("  6. Generate Executive Summary")
        print("  7. View Charts")
        print("  8. Import CSV Dataset")
        print("  9. Export Reports")
        print(" 10. Manage Data")
        print(" 11. Help and Documentation")
        print(" 12. Exit Application")
        print("-" * 40)

    def _prompt_validated(
        self,
        prompt_text: str,
        validator: Callable[[str], T],
        allow_cancel: bool = True,
    ) -> Optional[T]:
        """Loop until the user enters valid input or types 'cancel'."""
        while True:
            try:
                raw = input(prompt_text)
            except (EOFError, KeyboardInterrupt):
                print("\nInput cancelled.")
                return None

            if allow_cancel and raw.strip().lower() in {"cancel", "back", "q"}:
                print("Operation cancelled.")
                return None

            try:
                return validator(raw)
            except ValidationError as exc:
                print(f"  [Validation Error] {exc}")
                print("  Please try again (or type 'cancel' to return).")

    def _print_records_table(self, records: List[SurveyRecord], title: str = "Survey Responses") -> None:
        """Print a readable tabular view of anonymous survey records."""
        print(f"\n{title} ({len(records)} record(s))")
        if not records:
            print("  No matching records found.")
            return

        header = (
            f"  {'Record ID':<11} | {'Date':<10} | {'Age Group':<17} | "
            f"{'Sleep':>5} | {'Act(m)':>6} | {'Stress':>6} | {'Mood':>4} | {'Wellness':>8} | {'Tier':<8}"
        )
        print("-" * len(header))
        print(header)
        print("-" * len(header))
        for rec in records:
            print(
                f"  {rec.record_id:<11} | {rec.survey_date:<10} | {rec.age_group:<17} | "
                f"{rec.sleep_duration:>4.1f}h | {rec.physical_activity:>6} | "
                f"{rec.stress_level:>6} | {rec.mood_rating:>4} | {rec.general_wellness:>8} | "
                f"{rec.wellness_category:<8}"
            )
        print("-" * len(header))

    # ------------------------------------------------------------------
    # Menu Handlers (1 - 12)
    # ------------------------------------------------------------------

    def handle_add_response(self) -> None:
        """1. Add New Survey Response with defensive field-by-field validation."""
        print("\n--- Add New Anonymous Survey Response ---")
        print("Type 'cancel' at any prompt to abort. No personal identifiers are collected.")

        suggested_id = generate_record_id()
        record_id = self._prompt_validated(
            f"Record ID [Press Enter for auto '{suggested_id}']: ",
            lambda raw: validate_record_id(raw or suggested_id, allow_auto=True),
        )
        if record_id is None:
            return

        today_str = date.today().isoformat()
        survey_date = self._prompt_validated(
            f"Survey Date (YYYY-MM-DD) [Press Enter for {today_str}]: ",
            lambda raw: validate_survey_date(raw or today_str, allow_today_default=True),
        )
        if survey_date is None:
            return

        print(f"Optional Age Groups: {', '.join(VALID_AGE_GROUPS)}")
        age_group = self._prompt_validated(
            "Age Group [Press Enter for 'Prefer not to say']: ",
            validate_age_group,
        )
        if age_group is None:
            return

        sleep_duration = self._prompt_validated(
            f"Sleep Duration in hours ({SLEEP_MIN_HOURS}-{SLEEP_MAX_HOURS}, e.g. 7.5): ",
            validate_sleep_duration,
        )
        if sleep_duration is None:
            return

        physical_activity = self._prompt_validated(
            f"Physical Activity in minutes ({ACTIVITY_MIN_MINUTES}-{ACTIVITY_MAX_MINUTES}, e.g. 45): ",
            validate_physical_activity,
        )
        if physical_activity is None:
            return

        stress_level = self._prompt_validated(
            f"Stress Level ({SCALE_MIN}=Very Low to {SCALE_MAX}=Very High): ",
            lambda raw: validate_scale_rating(raw, "Stress Level"),
        )
        if stress_level is None:
            return

        mood_rating = self._prompt_validated(
            f"Mood Rating ({SCALE_MIN}=Very Low to {SCALE_MAX}=Very High): ",
            lambda raw: validate_scale_rating(raw, "Mood Rating"),
        )
        if mood_rating is None:
            return

        general_wellness = self._prompt_validated(
            f"General Wellness Rating ({SCALE_MIN}=Poor to {SCALE_MAX}=Excellent): ",
            lambda raw: validate_scale_rating(raw, "General Wellness Rating"),
        )
        if general_wellness is None:
            return

        record, errors, warnings = self.manager.add_response(
            {
                "record_id": record_id,
                "survey_date": survey_date,
                "age_group": age_group,
                "sleep_duration": sleep_duration,
                "physical_activity": physical_activity,
                "stress_level": stress_level,
                "mood_rating": mood_rating,
                "general_wellness": general_wellness,
                "data_origin": "user_entry",
            }
        )
        if errors or record is None:
            print("  [Error] Could not save response:")
            for err in errors:
                print(f"   - {err}")
            return

        print(f"\n  [Success] Anonymous response '{record.record_id}' saved to CSV and JSON.")
        if warnings:
            print("  [Statistical Threshold Notices — Non-Diagnostic]")
            for warn in warnings:
                print(f"   - {warn}")

    def handle_view_all(self) -> None:
        """2. View All Responses."""
        records = self.manager.get_all_records(newest_first=True)
        self._print_records_table(records, title="All Stored Anonymous Survey Responses")

    def handle_search(self) -> None:
        """3. Search Responses by Record ID."""
        print("\n--- Search Responses by Record ID ---")
        query = input("Enter Record ID (full or partial, e.g. WSV-): ").strip()
        if not query:
            print("  [Notice] Empty search query.")
            return
        matches = self.manager.search_records(query)
        self._print_records_table(matches, title=f"Search Results for '{query}'")

    def handle_filter(self) -> None:
        """4. Filter Responses by date, category, sleep range, or activity level."""
        print("\n--- Filter Survey Responses ---")
        print("Leave any filter blank to skip that criterion.")

        raw_date = input("Exact Survey Date (YYYY-MM-DD): ").strip()
        survey_date: Optional[str] = None
        if raw_date:
            try:
                survey_date = validate_survey_date(raw_date)
            except ValidationError as exc:
                print(f"  [Validation Error] {exc}")
                return

        wellness_cat = input("Wellness Category (Low / Moderate / High): ").strip() or None
        if wellness_cat and wellness_cat.lower() not in {"low", "moderate", "high"}:
            print("  [Validation Error] Wellness category must be Low, Moderate, or High.")
            return

        stress_cat = input("Stress Category (Low / Moderate / High): ").strip() or None
        if stress_cat and stress_cat.lower() not in {"low", "moderate", "high"}:
            print("  [Validation Error] Stress category must be Low, Moderate, or High.")
            return

        raw_min_sleep = input("Minimum Sleep Hours (0-24): ").strip()
        raw_max_sleep = input("Maximum Sleep Hours (0-24): ").strip()
        min_sleep: Optional[float] = None
        max_sleep: Optional[float] = None
        try:
            if raw_min_sleep:
                min_sleep = validate_sleep_duration(raw_min_sleep)
            if raw_max_sleep:
                max_sleep = validate_sleep_duration(raw_max_sleep)
            if min_sleep is not None and max_sleep is not None and min_sleep > max_sleep:
                print("  [Validation Error] Minimum sleep cannot exceed maximum sleep.")
                return
        except ValidationError as exc:
            print(f"  [Validation Error] {exc}")
            return

        activity_cat = input("Activity Level (Sedentary / Moderate / Active): ").strip() or None
        if activity_cat and activity_cat.lower() not in {"sedentary", "moderate", "active"}:
            print("  [Validation Error] Activity level must be Sedentary, Moderate, or Active.")
            return

        criteria = FilterCriteria(
            survey_date=survey_date,
            wellness_category=wellness_cat,
            stress_category=stress_cat,
            min_sleep=min_sleep,
            max_sleep=max_sleep,
            activity_category=activity_cat,
        )
        filtered = self.manager.filter_records(criteria)
        self._print_records_table(filtered, title="Filtered Survey Responses")

    def handle_view_dashboard(self) -> None:
        """5. View Analytics Dashboard."""
        report = self.manager.get_analytics()
        print("\n" + render_dashboard_text(report))

    def handle_executive_summary(self) -> None:
        """6. Generate Executive Summary."""
        print("\n" + self.manager.get_executive_summary(markdown=False))

    def handle_view_charts(self) -> None:
        """7. View Charts (generates 6 PNG visualizations and lists paths)."""
        print("\n--- Generating Survey Visualizations ---")
        result = self.manager.generate_charts()
        if result.warning:
            print(f"  [Notice] {result.warning}")
        if not result.generated_files:
            print("  No charts generated because the dataset is empty.")
            return
        print(f"  [Success] Generated {len(result.generated_files)} chart(s) via '{result.renderer}':")
        for path in result.generated_files:
            print(f"   - {path}")

    def handle_import_csv(self) -> None:
        """8. Import CSV Dataset with validation & error logging."""
        print("\n--- Bulk CSV Dataset Import ---")
        print(f"Press Enter to import synthetic sample dataset ({SAMPLE_CSV_PATH.name}),")
        raw_path = input("or enter path to a CSV file: ").strip()
        csv_path = Path(raw_path) if raw_path else SAMPLE_CSV_PATH

        summary = self.manager.import_csv(csv_path)
        print("\n  Import Summary")
        print("  " + "-" * 48)
        print(f"  Source File       : {summary.source_file}")
        print(f"  Rows Scanned      : {summary.total_rows}")
        print(f"  Imported          : {summary.imported_count}")
        print(f"  Duplicates Skipped: {summary.duplicate_count}")
        print(f"  Invalid Skipped   : {summary.invalid_count}")
        if summary.log_path:
            print(f"  Audit Log         : {summary.log_path}")
        if summary.errors:
            print("  Issues Logged:")
            for err in summary.errors[:10]:
                print(f"   - {err}")
            if len(summary.errors) > 10:
                print(f"   - ... ({len(summary.errors) - 10} more in audit log)")

    def handle_export_reports(self) -> None:
        """9. Export Reports in Markdown, TXT, and CSV."""
        print("\n--- Export Executive Reports ---")
        print("  1. Export All Formats (Markdown, TXT, CSV)")
        print("  2. Markdown (.md) only")
        print("  3. Plain Text (.txt) only")
        print("  4. CSV Summary (.csv) only")
        choice = input("Select export option [1-4]: ").strip() or "1"

        mapping = {
            "1": ["md", "txt", "csv"],
            "2": ["md"],
            "3": ["txt"],
            "4": ["csv"],
        }
        formats = mapping.get(choice)
        if not formats:
            print("  [Validation Error] Please choose 1, 2, 3, or 4.")
            return

        exported = self.manager.export_executive_reports(formats=formats)
        print("  [Success] Exported report file(s):")
        for fmt, path in exported.items():
            print(f"   - {fmt.upper()}: {path}")

    def handle_manage_data(self) -> None:
        """10. Manage Data (Load sample data, delete record, clear dataset, reload)."""
        print("\n--- Manage Survey Data ---")
        print("  1. Load 40 Synthetic Sample Records")
        print("  2. Delete a Record by ID")
        print("  3. Clear All Stored Records")
        print("  4. Reload Storage Files")
        print("  5. Back to Main Menu")
        choice = input("Select action [1-5]: ").strip()

        if choice == "1":
            summary = self.manager.load_sample_dataset()
            print(
                f"  [Success] Sample load complete: {summary.imported_count} added, "
                f"{summary.duplicate_count} already present."
            )
        elif choice == "2":
            rec_id = input("Enter Record ID to delete (e.g. WSV-A1B2C3): ").strip()
            if not rec_id:
                print("  [Notice] No Record ID entered.")
                return
            if self.manager.delete_record(rec_id):
                print(f"  [Success] Deleted record '{rec_id.upper()}'.")
            else:
                print(f"  [Not Found] No record with ID '{rec_id.upper()}'.")
        elif choice == "3":
            confirm = input("Type 'CLEAR' to permanently delete all stored records: ").strip()
            if confirm == "CLEAR":
                removed = self.manager.clear_all_records()
                print(f"  [Success] Cleared {removed} record(s) from storage.")
            else:
                print("  Clear cancelled.")
        elif choice == "4":
            self.manager.reload()
            print(f"  [Success] Reloaded {len(self.manager.records)} record(s) from disk.")
        elif choice == "5":
            return
        else:
            print("  [Validation Error] Invalid option. Choose 1-5.")

    def handle_help(self) -> None:
        """11. Help and Documentation."""
        print("\n--- Help & Documentation ---")
        print(f"  {APP_NAME} (v{APP_VERSION}) — {PROJECT_NUMBER} {CHALLENGE_NAME}")
        print("\n  Field Validation Ranges:")
        print(f"   * Survey Date      : YYYY-MM-DD (year >= 2020, not in the future)")
        print(f"   * Age Group        : {', '.join(VALID_AGE_GROUPS)}")
        print(f"   * Sleep Duration   : {SLEEP_MIN_HOURS} to {SLEEP_MAX_HOURS} hours")
        print(f"   * Physical Activity: {ACTIVITY_MIN_MINUTES} to {ACTIVITY_MAX_MINUTES} minutes/day")
        print(f"   * Stress / Mood / Wellness: Integer scale {SCALE_MIN} to {SCALE_MAX}")
        print("\n  Privacy & Ethics:")
        print(f"   * {PRIVACY_NOTICE}")
        print(f"   * {MEDICAL_DISCLAIMER}")

    def run(self) -> int:
        """Start the interactive terminal menu loop."""
        self.print_welcome_screen()
        actions = {
            "1": self.handle_add_response,
            "2": self.handle_view_all,
            "3": self.handle_search,
            "4": self.handle_filter,
            "5": self.handle_view_dashboard,
            "6": self.handle_executive_summary,
            "7": self.handle_view_charts,
            "8": self.handle_import_csv,
            "9": self.handle_export_reports,
            "10": self.handle_manage_data,
            "11": self.handle_help,
        }

        while True:
            self.print_main_menu()
            try:
                choice = input("Select an option [1-12]: ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nExiting Wellness Survey Visualizer. Goodbye.")
                return 0

            if choice == "12":
                print("\nExiting Wellness Survey Visualizer. All records are saved locally.")
                return 0

            handler = actions.get(choice)
            if handler is None:
                print("  [Validation Error] Invalid menu choice. Please enter a number from 1 to 12.")
                continue

            try:
                handler()
            except Exception as exc:  # Defensive top-level loop guard
                print(f"  [Recovered Error] An unexpected error occurred: {exc}")
                print("  Application state remains intact.", file=sys.stderr)
