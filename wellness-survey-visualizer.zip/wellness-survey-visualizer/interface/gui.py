"""Optional Tkinter Desktop GUI for Wellness Survey Visualizer.

Keeps the terminal interface fully independent and degrades gracefully when
running in headless environments without Tk installed.
"""

from __future__ import annotations

from datetime import date
from pathlib import Path
from typing import Optional

from config import (
    APP_NAME,
    APP_TAGLINE,
    APP_VERSION,
    MEDICAL_DISCLAIMER,
    PRIVACY_NOTICE,
    VALID_AGE_GROUPS,
)
from core.models import generate_record_id
from core.search import FilterCriteria
from core.survey_manager import SurveyManager

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    HAS_TKINTER = True
except ImportError:
    tk = None  # type: ignore[assignment]
    ttk = None  # type: ignore[assignment]
    filedialog = None  # type: ignore[assignment]
    messagebox = None  # type: ignore[assignment]
    HAS_TKINTER = False


def launch_gui(manager: Optional[SurveyManager] = None) -> int:
    """Launch the Tkinter graphical interface if Tkinter is available."""
    if not HAS_TKINTER or tk is None or ttk is None:
        print(
            "Tkinter GUI is unavailable in this Python environment "
            "(missing python3-tk or display server). Launching Terminal UI instead."
        )
        return 1

    app_manager = manager or SurveyManager()
    root = tk.Tk()
    root.title(f"{APP_NAME} v{APP_VERSION}")
    root.geometry("1120x740")
    root.minsize(960, 640)
    root.configure(bg="#F8FAFC")

    # Layout: Left sidebar + right content area
    sidebar = tk.Frame(root, bg="#0F172A", width=230)
    sidebar.pack(side=tk.LEFT, fill=tk.Y)
    sidebar.pack_propagate(False)

    content = tk.Frame(root, bg="#F8FAFC", padx=24, pady=20)
    content.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

    tk.Label(
        sidebar,
        text="WELLNESS SURVEY\nVISUALIZER",
        bg="#0F172A",
        fg="#F8FAFC",
        font=("Helvetica", 13, "bold"),
        justify=tk.LEFT,
        padx=16,
        pady=18,
    ).pack(anchor="w")

    tk.Label(
        sidebar,
        text=f"v{APP_VERSION} · Offline & Anonymous",
        bg="#0F172A",
        fg="#94A3B8",
        font=("Helvetica", 9),
        padx=16,
    ).pack(anchor="w", pady=(0, 16))

    frames = {}
    status_var = tk.StringVar(value=f"{len(app_manager.records)} anonymous records stored locally.")

    def show_section(name: str) -> None:
        for key, frame in frames.items():
            frame.pack_forget()
        frames[name].pack(fill=tk.BOTH, expand=True)
        if name == "dashboard":
            refresh_dashboard()
        elif name == "records":
            refresh_records_table()
        elif name == "analytics":
            refresh_analytics_view()

    nav_items = [
        ("Dashboard", "dashboard"),
        ("Add Survey Entry", "entry"),
        ("Records & Search", "records"),
        ("Analytics & Trends", "analytics"),
        ("Charts", "charts"),
        ("Export & Import", "export"),
    ]
    for label, key in nav_items:
        btn = tk.Button(
            sidebar,
            text=label,
            command=lambda k=key: show_section(k),
            bg="#1E293B",
            fg="#E2E8F0",
            activebackground="#0D9488",
            activeforeground="#FFFFFF",
            relief=tk.FLAT,
            anchor="w",
            padx=16,
            pady=10,
            font=("Helvetica", 10),
        )
        btn.pack(fill=tk.X, padx=12, pady=4)

    tk.Label(
        sidebar,
        textvariable=status_var,
        bg="#0F172A",
        fg="#CBD5E1",
        wraplength=195,
        justify=tk.LEFT,
        font=("Helvetica", 9),
        padx=16,
        pady=16,
    ).pack(side=tk.BOTTOM, anchor="w")

    # 1. Dashboard Section
    dash_frame = tk.Frame(content, bg="#F8FAFC")
    frames["dashboard"] = dash_frame
    tk.Label(dash_frame, text="Overview Dashboard", bg="#F8FAFC", fg="#0F172A", font=("Helvetica", 18, "bold")).pack(anchor="w")
    tk.Label(dash_frame, text=APP_TAGLINE, bg="#F8FAFC", fg="#475569", font=("Helvetica", 10)).pack(anchor="w", pady=(2, 14))
    kpi_text = tk.Text(dash_frame, height=24, bg="#FFFFFF", fg="#0F172A", font=("Courier", 10), relief=tk.SOLID, borderwidth=1)
    kpi_text.pack(fill=tk.BOTH, expand=True)

    def refresh_dashboard() -> None:
        report = app_manager.get_analytics()
        status_var.set(f"{report.total_responses} anonymous records stored locally.")
        kpi_text.configure(state=tk.NORMAL)
        kpi_text.delete("1.0", tk.END)
        if report.is_empty:
            kpi_text.insert(tk.END, "No survey records yet. Use 'Add Survey Entry' or 'Export & Import' to load sample data.")
        else:
            kpi_text.insert(
                tk.END,
                f"Total Responses   : {report.total_responses}\n"
                f"Date Range        : {report.date_range[0]} to {report.date_range[1]}\n"
                f"Average Wellness  : {report.wellness_stats.average}/10\n"
                f"Average Sleep     : {report.sleep_stats.average} hrs\n"
                f"Average Stress    : {report.stress_stats.average}/10\n"
                f"Average Mood      : {report.mood_stats.average}/10\n"
                f"Average Activity  : {report.activity_stats.average} min/day\n\n"
                f"Observations:\n" + "\n".join(f" - {o}" for o in report.observations) + "\n\n"
                f"{MEDICAL_DISCLAIMER}\n",
            )
        kpi_text.configure(state=tk.DISABLED)

    # 2. Data Entry Section
    entry_frame = tk.Frame(content, bg="#F8FAFC")
    frames["entry"] = entry_frame
    tk.Label(entry_frame, text="Add Anonymous Survey Response", bg="#F8FAFC", fg="#0F172A", font=("Helvetica", 18, "bold")).pack(anchor="w")
    tk.Label(entry_frame, text=PRIVACY_NOTICE, bg="#F8FAFC", fg="#475569", font=("Helvetica", 9)).pack(anchor="w", pady=(2, 14))

    form_vars = {
        "survey_date": tk.StringVar(value=date.today().isoformat()),
        "age_group": tk.StringVar(value=VALID_AGE_GROUPS[0]),
        "sleep_duration": tk.StringVar(value="7.5"),
        "physical_activity": tk.StringVar(value="40"),
        "stress_level": tk.StringVar(value="4"),
        "mood_rating": tk.StringVar(value="7"),
        "general_wellness": tk.StringVar(value="8"),
    }
    for field_name, label_text in [
        ("survey_date", "Survey Date (YYYY-MM-DD)"),
        ("age_group", f"Age Group ({', '.join(VALID_AGE_GROUPS)})"),
        ("sleep_duration", "Sleep Duration (hours 0-24)"),
        ("physical_activity", "Physical Activity (minutes 0-600)"),
        ("stress_level", "Stress Level (1-10)"),
        ("mood_rating", "Mood Rating (1-10)"),
        ("general_wellness", "General Wellness Rating (1-10)"),
    ]:
        row = tk.Frame(entry_frame, bg="#F8FAFC")
        row.pack(fill=tk.X, pady=5)
        tk.Label(row, text=label_text, width=34, anchor="w", bg="#F8FAFC", fg="#1E293B").pack(side=tk.LEFT)
        tk.Entry(row, textvariable=form_vars[field_name], width=32).pack(side=tk.LEFT)

    def submit_entry() -> None:
        payload = {k: v.get() for k, v in form_vars.items()}
        payload["record_id"] = generate_record_id()
        rec, errs, warns = app_manager.add_response(payload)
        if errs or rec is None:
            messagebox.showerror("Validation Error", "\n".join(errs))
            return
        status_var.set(f"{len(app_manager.records)} anonymous records stored locally.")
        msg = f"Saved anonymous record {rec.record_id}."
        if warns:
            msg += "\n\nStatistical Notices:\n" + "\n".join(warns)
        messagebox.showinfo("Saved", msg)

    tk.Button(entry_frame, text="Save Response", command=submit_entry, bg="#0D9488", fg="#FFFFFF", padx=16, pady=8).pack(anchor="w", pady=14)

    # 3. Records & Search Section
    rec_frame = tk.Frame(content, bg="#F8FAFC")
    frames["records"] = rec_frame
    tk.Label(rec_frame, text="Survey Records & Search", bg="#F8FAFC", fg="#0F172A", font=("Helvetica", 18, "bold")).pack(anchor="w")
    search_bar = tk.Frame(rec_frame, bg="#F8FAFC")
    search_bar.pack(fill=tk.X, pady=8)
    search_var = tk.StringVar()
    tk.Entry(search_bar, textvariable=search_var, width=28).pack(side=tk.LEFT, padx=(0, 8))

    cols = ("record_id", "survey_date", "age_group", "sleep", "activity", "stress", "mood", "wellness")
    tree = ttk.Treeview(rec_frame, columns=cols, show="headings", height=18)
    for col in cols:
        tree.heading(col, text=col.replace("_", " ").title())
        tree.column(col, width=105)
    tree.pack(fill=tk.BOTH, expand=True)

    def refresh_records_table(query: str = "") -> None:
        for item in tree.get_children():
            tree.delete(item)
        rows = app_manager.search_records(query) if query else app_manager.get_all_records()
        for r in rows:
            tree.insert("", tk.END, values=(r.record_id, r.survey_date, r.age_group, r.sleep_duration, r.physical_activity, r.stress_level, r.mood_rating, r.general_wellness))

    tk.Button(search_bar, text="Search ID", command=lambda: refresh_records_table(search_var.get()), bg="#0F172A", fg="#FFFFFF", padx=10).pack(side=tk.LEFT, padx=4)
    tk.Button(search_bar, text="Show All", command=lambda: refresh_records_table(""), bg="#E2E8F0", fg="#0F172A", padx=10).pack(side=tk.LEFT, padx=4)

    # 4. Analytics Section
    analytics_frame = tk.Frame(content, bg="#F8FAFC")
    frames["analytics"] = analytics_frame
    tk.Label(analytics_frame, text="Executive Analytics & Trends", bg="#F8FAFC", fg="#0F172A", font=("Helvetica", 18, "bold")).pack(anchor="w")
    summary_box = tk.Text(analytics_frame, bg="#FFFFFF", fg="#0F172A", font=("Courier", 9), relief=tk.SOLID, borderwidth=1)
    summary_box.pack(fill=tk.BOTH, expand=True, pady=10)

    def refresh_analytics_view() -> None:
        summary_box.configure(state=tk.NORMAL)
        summary_box.delete("1.0", tk.END)
        summary_box.insert(tk.END, app_manager.get_executive_summary(markdown=False))
        summary_box.configure(state=tk.DISABLED)

    # 5. Charts Section
    charts_frame = tk.Frame(content, bg="#F8FAFC")
    frames["charts"] = charts_frame
    tk.Label(charts_frame, text="Visualizations", bg="#F8FAFC", fg="#0F172A", font=("Helvetica", 18, "bold")).pack(anchor="w")
    chart_label = tk.Label(charts_frame, bg="#FFFFFF", text="Click 'Generate All 6 Charts' to render visualizations.")
    chart_label.pack(fill=tk.BOTH, expand=True, pady=10)
    chart_refs = []

    def generate_and_preview() -> None:
        res = app_manager.generate_charts()
        if not res.generated_files:
            messagebox.showwarning("Empty Dataset", res.warning or "No data to chart.")
            return
        img = tk.PhotoImage(file=str(res.generated_files[-1]))
        chart_refs.clear()
        chart_refs.append(img)
        chart_label.configure(image=img, text="")
        messagebox.showinfo("Charts Generated", f"Generated {len(res.generated_files)} PNG charts in reports/charts/.")

    tk.Button(charts_frame, text="Generate All 6 Charts", command=generate_and_preview, bg="#0D9488", fg="#FFFFFF", padx=14, pady=8).pack(anchor="w")

    # 6. Export & Import Section
    export_frame = tk.Frame(content, bg="#F8FAFC")
    frames["export"] = export_frame
    tk.Label(export_frame, text="Import & Export Controls", bg="#F8FAFC", fg="#0F172A", font=("Helvetica", 18, "bold")).pack(anchor="w", pady=(0, 12))

    def load_sample_gui() -> None:
        summary = app_manager.load_sample_dataset()
        status_var.set(f"{len(app_manager.records)} anonymous records stored locally.")
        messagebox.showinfo("Sample Data Loaded", f"Imported {summary.imported_count} synthetic records.")

    def import_csv_gui() -> None:
        chosen = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv")])
        if not chosen:
            return
        summary = app_manager.import_csv(Path(chosen))
        status_var.set(f"{len(app_manager.records)} anonymous records stored locally.")
        messagebox.showinfo("CSV Import", f"Imported: {summary.imported_count}, Duplicates: {summary.duplicate_count}, Invalid: {summary.invalid_count}")

    def export_all_gui() -> None:
        exported = app_manager.export_executive_reports(["md", "txt", "csv"])
        messagebox.showinfo("Export Complete", "\n".join(f"{k.upper()}: {v}" for k, v in exported.items()))

    tk.Button(export_frame, text="Load 40 Synthetic Sample Records", command=load_sample_gui, bg="#0F172A", fg="#FFFFFF", padx=14, pady=8).pack(anchor="w", pady=6)
    tk.Button(export_frame, text="Import CSV Dataset...", command=import_csv_gui, bg="#2563EB", fg="#FFFFFF", padx=14, pady=8).pack(anchor="w", pady=6)
    tk.Button(export_frame, text="Export Reports (MD + TXT + CSV)", command=export_all_gui, bg="#0D9488", fg="#FFFFFF", padx=14, pady=8).pack(anchor="w", pady=6)

    show_section("dashboard")
    root.mainloop()
    return 0
