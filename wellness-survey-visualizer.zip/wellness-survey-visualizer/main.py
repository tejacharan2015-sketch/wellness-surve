"""Main entry point for Wellness Survey Visualizer (Project #40).

Supports:
  - Interactive terminal menu (default)
  - Optional Tkinter GUI (--gui)
  - Automated 15-step demonstration workflow (--demo)
  - Non-interactive JSON API bridge (--api <action>)
"""

from __future__ import annotations

import argparse
from dataclasses import asdict
import json
from pathlib import Path
import sys
from typing import Any, Dict

# Ensure project root is on sys.path regardless of working directory
PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from config import CHARTS_DIR, REPORTS_DIR, SAMPLE_CSV_PATH, ensure_directories
from core.search import FilterCriteria
from core.survey_manager import SurveyManager
from interface.gui import launch_gui
from interface.terminal_ui import TerminalUI


def _serialize_analytics(manager: SurveyManager) -> Dict[str, Any]:
    """Serialize AnalyticsReport and records for JSON API mode."""
    report = manager.get_analytics()
    chart_files = sorted(CHARTS_DIR.glob("*.png")) if CHARTS_DIR.exists() else []
    return {
        "report": asdict(report),
        "records": [r.to_dict() for r in manager.get_all_records(newest_first=True)],
        "charts": [p.name for p in chart_files],
        "startup_warnings": manager.startup_warnings,
    }


def _handle_api(action: str, payload_raw: str) -> int:
    """Execute a structured JSON API command against the real Python engine."""
    manager = SurveyManager()
    payload: Dict[str, Any] = json.loads(payload_raw) if payload_raw.strip() else {}

    if action == "state":
        print(json.dumps(_serialize_analytics(manager)))
        return 0

    if action == "add":
        rec, errs, warns = manager.add_response(payload)
        if errs or rec is None:
            print(json.dumps({"ok": False, "errors": errs}))
            return 0
        print(json.dumps({"ok": True, "record": rec.to_dict(), "warnings": warns, **_serialize_analytics(manager)}))
        return 0

    if action == "delete":
        deleted = manager.delete_record(str(payload.get("record_id", "")))
        print(json.dumps({"ok": deleted, **_serialize_analytics(manager)}))
        return 0

    if action == "search":
        q = str(payload.get("query", ""))
        matches = manager.search_records(q) if q.strip() else manager.get_all_records()
        print(json.dumps({"ok": True, "records": [r.to_dict() for r in matches]}))
        return 0

    if action == "filter":
        criteria = FilterCriteria(
            survey_date=payload.get("survey_date") or None,
            start_date=payload.get("start_date") or None,
            end_date=payload.get("end_date") or None,
            wellness_category=payload.get("wellness_category") or None,
            stress_category=payload.get("stress_category") or None,
            min_sleep=float(payload["min_sleep"]) if payload.get("min_sleep") not in (None, "") else None,
            max_sleep=float(payload["max_sleep"]) if payload.get("max_sleep") not in (None, "") else None,
            activity_category=payload.get("activity_category") or None,
            age_group=payload.get("age_group") or None,
        )
        matches = manager.filter_records(criteria)
        print(json.dumps({"ok": True, "records": [r.to_dict() for r in matches]}))
        return 0

    if action == "load-sample":
        summary = manager.load_sample_dataset(SAMPLE_CSV_PATH)
        print(json.dumps({"ok": True, "summary": asdict(summary), **_serialize_analytics(manager)}))
        return 0

    if action == "import-csv":
        csv_text = str(payload.get("csv_content", ""))
        tmp_import = manager.storage.csv_path.parent / "_web_import_staging.csv"
        tmp_import.write_text(csv_text, encoding="utf-8")
        try:
            summary = manager.import_csv(tmp_import)
        finally:
            if tmp_import.exists():
                tmp_import.unlink()
        print(json.dumps({"ok": True, "summary": asdict(summary), **_serialize_analytics(manager)}))
        return 0

    if action == "clear":
        removed = manager.clear_all_records()
        print(json.dumps({"ok": True, "removed": removed, **_serialize_analytics(manager)}))
        return 0

    if action == "generate-charts":
        result = manager.generate_charts()
        print(
            json.dumps(
                {
                    "ok": len(result.generated_files) > 0,
                    "renderer": result.renderer,
                    "warning": result.warning,
                    "files": [p.name for p in result.generated_files],
                    **_serialize_analytics(manager),
                }
            )
        )
        return 0

    if action == "export-reports":
        formats = payload.get("formats") or ["md", "txt", "csv"]
        exported = manager.export_executive_reports(formats=formats)
        summary_md = manager.get_executive_summary(markdown=True)
        summary_txt = manager.get_executive_summary(markdown=False)
        print(
            json.dumps(
                {
                    "ok": True,
                    "exported": {k: str(v) for k, v in exported.items()},
                    "summary_md": summary_md,
                    "summary_txt": summary_txt,
                }
            )
        )
        return 0

    print(json.dumps({"ok": False, "error": f"Unknown API action: {action}"}))
    return 1


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """Parse command-line execution modes."""
    parser = argparse.ArgumentParser(description="Wellness Survey Visualizer (Project #40)")
    parser.add_argument("--gui", action="store_true", help="Launch optional Tkinter GUI")
    parser.add_argument("--demo", action="store_true", help="Run automated 15-step demonstration workflow")
    parser.add_argument("--api", type=str, default="", help="Execute JSON API action and exit")
    parser.add_argument("--payload", type=str, default="{}", help="JSON payload for --api mode")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    """Application entrypoint."""
    ensure_directories()
    args = parse_args(argv)

    if args.api:
        return _handle_api(args.api, args.payload)

    if args.demo:
        from demo_runner import run_full_demonstration

        return run_full_demonstration()

    if args.gui:
        code = launch_gui()
        if code == 0:
            return 0
        # Fallback cleanly to terminal UI if Tkinter isn't installed
        return TerminalUI().run()

    return TerminalUI().run()


if __name__ == "__main__":
    raise SystemExit(main())
