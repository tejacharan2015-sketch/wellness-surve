"""Generates 40 realistic SYNTHETIC anonymous wellness survey records
into data/sample_data.csv and data/sample_data.json.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path
import sys
from typing import Dict, List

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from config import CSV_FIELDNAMES, SAMPLE_CSV_PATH, SAMPLE_JSON_PATH, ensure_directories
from core.models import SurveyRecord
from core.validation import validate_record_payload

# 40 curated synthetic demonstration records covering normal distributions,
# boundary values (0h, 24h, 0m, 600m, 1, 10), and multi-week chronological trends.
SYNTHETIC_ROWS: List[Dict[str, object]] = [
    {"record_id": "SYN-0001", "survey_date": "2026-10-15", "age_group": "18-24", "sleep_duration": 6.5, "physical_activity": 35, "stress_level": 6, "mood_rating": 6, "general_wellness": 6},
    {"record_id": "SYN-0002", "survey_date": "2026-10-15", "age_group": "25-34", "sleep_duration": 7.5, "physical_activity": 50, "stress_level": 4, "mood_rating": 8, "general_wellness": 8},
    {"record_id": "SYN-0003", "survey_date": "2026-10-16", "age_group": "35-44", "sleep_duration": 5.0, "physical_activity": 15, "stress_level": 8, "mood_rating": 4, "general_wellness": 4},
    {"record_id": "SYN-0004", "survey_date": "2026-10-16", "age_group": "45-54", "sleep_duration": 8.0, "physical_activity": 60, "stress_level": 3, "mood_rating": 8, "general_wellness": 9},
    {"record_id": "SYN-0005", "survey_date": "2026-10-17", "age_group": "55+", "sleep_duration": 7.0, "physical_activity": 40, "stress_level": 4, "mood_rating": 7, "general_wellness": 7},
    {"record_id": "SYN-0006", "survey_date": "2026-10-18", "age_group": "Prefer not to say", "sleep_duration": 4.0, "physical_activity": 10, "stress_level": 9, "mood_rating": 3, "general_wellness": 3},
    {"record_id": "SYN-0007", "survey_date": "2026-10-18", "age_group": "18-24", "sleep_duration": 8.5, "physical_activity": 75, "stress_level": 2, "mood_rating": 9, "general_wellness": 9},
    {"record_id": "SYN-0008", "survey_date": "2026-10-19", "age_group": "25-34", "sleep_duration": 6.0, "physical_activity": 25, "stress_level": 7, "mood_rating": 5, "general_wellness": 5},
    {"record_id": "SYN-0009", "survey_date": "2026-10-20", "age_group": "35-44", "sleep_duration": 7.2, "physical_activity": 45, "stress_level": 5, "mood_rating": 7, "general_wellness": 7},
    {"record_id": "SYN-0010", "survey_date": "2026-10-20", "age_group": "18-24", "sleep_duration": 0.0, "physical_activity": 0, "stress_level": 10, "mood_rating": 1, "general_wellness": 1},  # lower boundary
    {"record_id": "SYN-0011", "survey_date": "2026-10-21", "age_group": "25-34", "sleep_duration": 7.8, "physical_activity": 55, "stress_level": 3, "mood_rating": 8, "general_wellness": 8},
    {"record_id": "SYN-0012", "survey_date": "2026-10-22", "age_group": "45-54", "sleep_duration": 6.8, "physical_activity": 30, "stress_level": 6, "mood_rating": 6, "general_wellness": 6},
    {"record_id": "SYN-0013", "survey_date": "2026-10-23", "age_group": "55+", "sleep_duration": 8.2, "physical_activity": 65, "stress_level": 2, "mood_rating": 9, "general_wellness": 9},
    {"record_id": "SYN-0014", "survey_date": "2026-10-24", "age_group": "18-24", "sleep_duration": 5.5, "physical_activity": 20, "stress_level": 8, "mood_rating": 4, "general_wellness": 4},
    {"record_id": "SYN-0015", "survey_date": "2026-10-25", "age_group": "25-34", "sleep_duration": 9.5, "physical_activity": 90, "stress_level": 2, "mood_rating": 9, "general_wellness": 10},
    {"record_id": "SYN-0016", "survey_date": "2026-10-26", "age_group": "35-44", "sleep_duration": 6.2, "physical_activity": 28, "stress_level": 7, "mood_rating": 5, "general_wellness": 5},
    {"record_id": "SYN-0017", "survey_date": "2026-10-27", "age_group": "Prefer not to say", "sleep_duration": 7.5, "physical_activity": 45, "stress_level": 4, "mood_rating": 7, "general_wellness": 7},
    {"record_id": "SYN-0018", "survey_date": "2026-10-28", "age_group": "45-54", "sleep_duration": 10.5, "physical_activity": 120, "stress_level": 3, "mood_rating": 8, "general_wellness": 8},
    {"record_id": "SYN-0019", "survey_date": "2026-10-29", "age_group": "18-24", "sleep_duration": 6.0, "physical_activity": 15, "stress_level": 7, "mood_rating": 5, "general_wellness": 5},
    {"record_id": "SYN-0020", "survey_date": "2026-10-30", "age_group": "25-34", "sleep_duration": 24.0, "physical_activity": 600, "stress_level": 1, "mood_rating": 10, "general_wellness": 10},  # upper boundary
    {"record_id": "SYN-0021", "survey_date": "2026-11-01", "age_group": "35-44", "sleep_duration": 7.4, "physical_activity": 42, "stress_level": 4, "mood_rating": 7, "general_wellness": 8},
    {"record_id": "SYN-0022", "survey_date": "2026-11-02", "age_group": "55+", "sleep_duration": 7.9, "physical_activity": 50, "stress_level": 3, "mood_rating": 8, "general_wellness": 8},
    {"record_id": "SYN-0023", "survey_date": "2026-11-03", "age_group": "18-24", "sleep_duration": 5.2, "physical_activity": 18, "stress_level": 8, "mood_rating": 4, "general_wellness": 4},
    {"record_id": "SYN-0024", "survey_date": "2026-11-04", "age_group": "25-34", "sleep_duration": 7.6, "physical_activity": 60, "stress_level": 4, "mood_rating": 8, "general_wellness": 8},
    {"record_id": "SYN-0025", "survey_date": "2026-11-05", "age_group": "45-54", "sleep_duration": 6.9, "physical_activity": 35, "stress_level": 5, "mood_rating": 7, "general_wellness": 7},
    {"record_id": "SYN-0026", "survey_date": "2026-11-06", "age_group": "35-44", "sleep_duration": 8.1, "physical_activity": 70, "stress_level": 3, "mood_rating": 9, "general_wellness": 9},
    {"record_id": "SYN-0027", "survey_date": "2026-11-07", "age_group": "Prefer not to say", "sleep_duration": 6.4, "physical_activity": 22, "stress_level": 6, "mood_rating": 6, "general_wellness": 6},
    {"record_id": "SYN-0028", "survey_date": "2026-11-08", "age_group": "18-24", "sleep_duration": 7.0, "physical_activity": 45, "stress_level": 5, "mood_rating": 7, "general_wellness": 7},
    {"record_id": "SYN-0029", "survey_date": "2026-11-09", "age_group": "25-34", "sleep_duration": 8.3, "physical_activity": 80, "stress_level": 2, "mood_rating": 9, "general_wellness": 9},
    {"record_id": "SYN-0030", "survey_date": "2026-11-10", "age_group": "55+", "sleep_duration": 7.5, "physical_activity": 38, "stress_level": 3, "mood_rating": 8, "general_wellness": 8},
    {"record_id": "SYN-0031", "survey_date": "2026-11-11", "age_group": "35-44", "sleep_duration": 4.5, "physical_activity": 5, "stress_level": 9, "mood_rating": 2, "general_wellness": 3},
    {"record_id": "SYN-0032", "survey_date": "2026-11-12", "age_group": "45-54", "sleep_duration": 7.8, "physical_activity": 52, "stress_level": 4, "mood_rating": 8, "general_wellness": 8},
    {"record_id": "SYN-0033", "survey_date": "2026-11-13", "age_group": "18-24", "sleep_duration": 8.0, "physical_activity": 65, "stress_level": 3, "mood_rating": 8, "general_wellness": 9},
    {"record_id": "SYN-0034", "survey_date": "2026-11-14", "age_group": "25-34", "sleep_duration": 7.1, "physical_activity": 40, "stress_level": 5, "mood_rating": 7, "general_wellness": 7},
    {"record_id": "SYN-0035", "survey_date": "2026-11-15", "age_group": "35-44", "sleep_duration": 8.4, "physical_activity": 95, "stress_level": 2, "mood_rating": 9, "general_wellness": 9},
    {"record_id": "SYN-0036", "survey_date": "2026-11-16", "age_group": "Prefer not to say", "sleep_duration": 6.7, "physical_activity": 30, "stress_level": 5, "mood_rating": 6, "general_wellness": 7},
    {"record_id": "SYN-0037", "survey_date": "2026-11-17", "age_group": "55+", "sleep_duration": 7.6, "physical_activity": 48, "stress_level": 3, "mood_rating": 8, "general_wellness": 8},
    {"record_id": "SYN-0038", "survey_date": "2026-11-18", "age_group": "18-24", "sleep_duration": 8.8, "physical_activity": 110, "stress_level": 2, "mood_rating": 9, "general_wellness": 9},
    {"record_id": "SYN-0039", "survey_date": "2026-11-19", "age_group": "25-34", "sleep_duration": 7.3, "physical_activity": 44, "stress_level": 4, "mood_rating": 8, "general_wellness": 8},
    {"record_id": "SYN-0040", "survey_date": "2026-11-20", "age_group": "45-54", "sleep_duration": 8.2, "physical_activity": 72, "stress_level": 2, "mood_rating": 9, "general_wellness": 9},
]


def generate_sample_datasets() -> List[SurveyRecord]:
    """Validate and write the 40 synthetic records to CSV and JSON."""
    ensure_directories()
    validated: List[SurveyRecord] = []

    for row in SYNTHETIC_ROWS:
        payload = {**row, "data_origin": "synthetic_demo"}
        rec, errs = validate_record_payload(payload, allow_auto_id=False)
        if rec is None or errs:
            raise RuntimeError(f"Invalid synthetic row {row.get('record_id')}: {errs}")
        validated.append(rec)

    with SAMPLE_CSV_PATH.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDNAMES)
        writer.writeheader()
        for rec in validated:
            writer.writerow(rec.to_dict())

    json_payload = {
        "dataset_type": "SYNTHETIC_DEMONSTRATION_DATA",
        "description": (
            "40 synthetic, non-identifying wellness survey records generated strictly "
            "for offline testing and analytics demonstration."
        ),
        "record_count": len(validated),
        "records": [rec.to_dict() for rec in validated],
    }
    SAMPLE_JSON_PATH.write_text(json.dumps(json_payload, indent=2), encoding="utf-8")
    return validated


if __name__ == "__main__":
    records = generate_sample_datasets()
    print(f"Generated {len(records)} synthetic records in:")
    print(f"  - {SAMPLE_CSV_PATH}")
    print(f"  - {SAMPLE_JSON_PATH}")
