# WELLNESS SURVEY VISUALIZER

**Understand Wellness. Discover Trends. Make Better Decisions.**

- **Project Number:** #40
- **Domain:** Health & Wellbeing
- **Challenge:** LocalImpact Challenge
- **Version:** 1.0.0

> **Privacy Commitment:** Strictly anonymous and offline. No names, email addresses, phone numbers, or other personally identifying information (PII) are collected or stored.
> **Non-Diagnostic Disclaimer:** All analytics, category distributions, and threshold warnings summarize self-reported statistical patterns only and do not represent medical advice or clinical diagnosis.

---

## 1. Project Introduction

**Wellness Survey Visualizer** is an offline, privacy-preserving Python 3.10+ application built for collecting, validating, searching, analyzing, visualizing, and reporting on anonymous community or campus wellness survey data. It combines a 12-option interactive terminal application, an optional Tkinter desktop GUI, dual CSV/JSON persistence, a statistical analytics engine, automated chart generation, and multi-format executive report exports.

## 2. Problem Statement

Community coordinators, student wellness clubs, and local wellbeing initiatives frequently collect anonymous check-in surveys (sleep, physical activity, stress, mood, and general wellness) on spreadsheets or paper forms. Manual analysis is error-prone, inconsistent, slow to summarize across dates, and vulnerable to malformed entries or accidental privacy leaks.

## 3. Objectives

1. Collect anonymous wellness survey responses using non-identifying random Record IDs (`WSV-XXXXXX`).
2. Enforce defensive input validation across types, ranges, calendar dates, categories, and PII patterns.
3. Persist data reliably and offline in synchronized local **CSV** and **JSON** storage with corruption recovery.
4. Provide fast Record ID search and multi-criteria filtering.
5. Compute descriptive statistics, category/percentage distributions, and chronological wellness trends.
6. Flag statistical outliers and trend shifts via a non-diagnostic threshold warning system.
7. Generate 6 descriptive PNG visualizations (via Matplotlib, with a built-in pure-Python PNG fallback).
8. Export executive reports in **Markdown (`.md`)**, **Plain Text (`.txt`)**, and **CSV (`.csv`)**.
9. Support bulk CSV dataset imports with row-by-row validation, duplicate rejection, and audit logging.
10. Verify correctness with an automated `unittest` suite and an end-to-end 15-step demonstration script.

## 4. Proposed Solution

The system uses a layered modular architecture separating **User Interfaces** (`interface/terminal_ui.py`, `interface/gui.py`), **Application Services & Domain Logic** (`core/`), **Visualization** (`visualization/`), and **Local Persistence** (`data/`, `reports/`, `logs/`). Every submission is validated before reaching storage, persisted atomically to both CSV and JSON, and analyzed dynamically from stored records without hardcoded outputs.

## 5. Features

- **12-Option Interactive Terminal UI:** Welcome banner, validated entry prompts, tabular views, search, multi-filter, analytics dashboard, executive summary, chart generation, bulk CSV import, report export, data management, and help documentation.
- **Optional Tkinter Desktop GUI:** Navigation sidebar, dashboard summary, entry form, searchable record table, chart previewer, and import/export controls (degrades gracefully in headless environments without Tk).
- **Defensive Validation & PII Guard:** Validates bounds (`sleep_duration`: `0.0–24.0h`, `physical_activity`: `0–600 min`, Likert scales: `1–10`, `YYYY-MM-DD` dates `>= 2020` and not future) and rejects accidental emails/phone numbers.
- **Dual CSV + JSON Persistence:** Atomic writes, automatic file creation, corrupted JSON auto-backup + CSV recovery, and malformed CSV row isolation.
- **Analytics Engine & Threshold Warnings:** Averages, medians, min/max, category distributions & percentages, highest/lowest metrics & dates, chronological trend deltas, and non-diagnostic outlier warnings.
- **6 Visualization Charts:** Sleep Duration, Stress Level, Mood Rating, Physical Activity, Overall Wellness, and Wellness Trends Over Time saved as PNG files.
- **Bulk CSV Import:** Header verification, column normalization, duplicate Record ID skipping, and `logs/csv_import.log` audit trail.
- **Executive Report Exports:** Markdown, TXT, and CSV summary reports referencing generated charts.

## 6. Technology Stack

- **Language:** Python 3.10+ (tested on Python 3.11.2)
- **Standard Library:** `csv`, `json`, `datetime`, `statistics`, `dataclasses`, `pathlib`, `logging`, `secrets`, `unittest`, `zlib`, `struct`, `argparse`
- **Data Visualization:** `matplotlib` (with built-in pure-Python PNG rasterization fallback when `matplotlib` is not installed)
- **Optional Desktop GUI:** `tkinter` (standard library GUI toolkit, when `python3-tk` and a display server are present)

## 7. System Architecture

```text
+-------------------------------------------------------------------+
|                   Presentation Layer (interface/)                 |
|      TerminalUI (12-option CLI)  |  Tkinter GUI (--gui)           |
+----------------------------------+--------------------------------+
                                   |
                                   v
+-------------------------------------------------------------------+
|                Application Service (core/survey_manager.py)       |
+----+--------------+--------------+---------------+----------------+
     |              |              |               |
     v              v              v               v
+---------+   +-----------+   +----------+   +------------------+
| Models  |   | Validation|   | Analytics|   | Search & Filter  |
| & IDs   |   | & Warnings|   | Engine   |   | Engine           |
+---------+   +-----------+   +----+-----+   +------------------+
                                   |
          +------------------------+------------------------+
          v                                                 v
+-------------------------+                   +-------------------------+
| Storage (core/storage)  |                   | Output (visualization/  |
| - data/responses.csv    |                   |   & report_generator)   |
| - data/responses.json   |                   | - 6 PNG charts          |
| - Bulk CSV importer     |                   | - MD / TXT / CSV reports|
+-------------------------+                   +-------------------------+
```

## 8. Folder Structure

```text
wellness-survey-visualizer/
├── main.py
├── config.py
├── demo_runner.py
├── generate_sample_data.py
├── requirements.txt
├── README.md
├── core/
│   ├── __init__.py
│   ├── models.py
│   ├── validation.py
│   ├── storage.py
│   ├── search.py
│   ├── analytics.py
│   ├── report_generator.py
│   └── survey_manager.py
├── visualization/
│   ├── __init__.py
│   ├── charts.py
│   └── dashboard.py
├── interface/
│   ├── __init__.py
│   ├── terminal_ui.py
│   └── gui.py
├── data/
│   ├── responses.csv
│   ├── responses.json
│   ├── sample_data.csv
│   └── sample_data.json
├── reports/
│   ├── executive_wellness_report.md
│   ├── executive_wellness_report.txt
│   ├── executive_wellness_report_summary.csv
│   └── charts/
│       ├── 01_sleep_duration_distribution.png
│       ├── 02_stress_level_distribution.png
│       ├── 03_mood_distribution.png
│       ├── 04_physical_activity_distribution.png
│       ├── 05_overall_wellness_distribution.png
│       └── 06_wellness_trends_over_time.png
├── logs/
│   ├── application.log
│   └── csv_import.log
└── tests/
    ├── __init__.py
    ├── test_validation.py
    ├── test_analytics.py
    ├── test_storage.py
    ├── test_search.py
    └── test_reports_and_charts.py
```

## 9. Installation Instructions

```bash
cd wellness-survey-visualizer
python3 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

> Note: All core features (CLI, CSV/JSON storage, analytics, search/filter, executive reports, and PNG chart generation via fallback) operate using the Python standard library even without external packages installed. Installing `matplotlib` activates full Matplotlib rendering.

## 10. Execution Instructions

- **Launch Interactive Terminal Application:**
  ```bash
  python3 main.py
  ```
- **Launch Optional Tkinter GUI:**
  ```bash
  python3 main.py --gui
  ```
- **Run Automated 15-Step Live Demonstration:**
  ```bash
  python3 main.py --demo
  ```
- **Regenerate the 40 Synthetic Sample Records:**
  ```bash
  python3 generate_sample_data.py
  ```
- **Run Automated Test Suite:**
  ```bash
  python3 -m unittest discover -s tests -v
  ```

## 11. Application Screenshots & Terminal Output

Generated PNG charts are saved in `reports/charts/`:
- `01_sleep_duration_distribution.png`
- `02_stress_level_distribution.png`
- `03_mood_distribution.png`
- `04_physical_activity_distribution.png`
- `05_overall_wellness_distribution.png`
- `06_wellness_trends_over_time.png`

## 12. Sample Outputs

Sample dashboard metrics generated from the 40 synthetic records + 1 live demonstration record (`N = 41`):

```text
  Total Responses : 41           Survey Window : 2026-10-15 .. 2026-11-24
  General Wellness :  7.07/10  (med 8.0, range 1-10)
  Sleep Duration   :  7.46 h   (med 7.5h, range 0.0-24.0h)
  Stress Level     :  4.56/10  (med 4.0, range 1-10)
  Mood Rating      :  6.93/10  (med 8.0, range 1-10)
  Physical Activity: 60.71 m   (med 45.0m, range 0-600m)
  Trend Deltas (early vs recent): Wellness +0.67 pts | Stress -0.54 pts
```

## 13. Testing Results

Executed `python3 -m unittest discover -s tests -v` on Python 3.11.2:
- **Tests Run:** 19
- **Passed:** 19 (`OK`)
- **Failed:** 0
- **Coverage Areas:** Boundary sleep/activity/scale validation, date validation, PII rejection, empty dataset analytics, chronological trend deltas, CSV/JSON persistence roundtrip, corrupted JSON recovery from CSV backup, malformed CSV isolation, bulk CSV import validation & duplicate detection, Record ID search, multi-criteria filtering, MD/TXT/CSV report exports, and 6 valid PNG chart outputs.

## 14. Limitations

- Designed for single-user offline local storage; concurrent multi-user writes to the same file are not locked across processes.
- In headless container environments without `python3-tk` or an X11/Wayland display, `--gui` falls back cleanly to the Terminal UI.
- When `matplotlib` is not installed in a minimal Python runtime, `visualization/charts.py` uses its built-in pure-Python PNG fallback renderer instead of Matplotlib figures.

## 15. Future Enhancements

- Optional SQLite backend alongside CSV/JSON export for larger community datasets (10,000+ rows).
- Correlation scatter plots (Sleep vs. Wellness, Activity vs. Stress) and rolling 7-day moving averages.
- PDF executive report export with embedded chart thumbnails.

## 16. Conclusion

**Wellness Survey Visualizer (#40)** delivers a reliable, modular, strictly anonymous offline wellness analytics workflow with comprehensive input validation, persistent CSV/JSON storage, visual reporting, and verified automated testing.

---

## Live Demonstration Script (15-Step Checklist)

1. Run `python3 main.py --demo` (or launch `python3 main.py` interactively).
2. Observe the **Welcome Screen** showing project title, version `1.0.0`, status, and privacy notice.
3. Choose Option `1. Add New Survey Response`.
4. Enter an intentionally invalid value (e.g., `-3.5` for sleep duration).
5. Observe the validation error message and safe re-prompt.
6. Correct the value to `7.5` and complete all fields.
7. Confirm immediate persistence to `data/responses.csv` and `data/responses.json`.
8. Choose Option `3. Search Responses` and locate the saved Record ID.
9. Choose Option `5. View Analytics Dashboard` to inspect averages, distributions, and threshold warnings.
10. Choose Option `7. View Charts` to generate all 6 PNG charts in `reports/charts/`.
11. Choose Option `6. Generate Executive Summary`.
12. Choose Option `9. Export Reports` to export `.md`, `.txt`, and `.csv` files in `reports/`.
13. Choose Option `12. Exit Application`.
14. Restart with `python3 main.py`.
15. Choose Option `2. View All Responses` and confirm previously saved records remain intact.
