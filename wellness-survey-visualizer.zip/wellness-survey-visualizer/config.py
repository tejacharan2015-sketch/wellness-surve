"""Central configuration, constants, validation bounds, and logging setup
for the Wellness Survey Visualizer application.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, List, Tuple

APP_NAME: str = "WELLNESS SURVEY VISUALIZER"
APP_TAGLINE: str = "Understand Wellness. Discover Trends. Make Better Decisions."
APP_VERSION: str = "1.0.0"
PROJECT_NUMBER: str = "#40"
PROJECT_DOMAIN: str = "Health & Wellbeing"
CHALLENGE_NAME: str = "LocalImpact Challenge"

PRIVACY_NOTICE: str = (
    "Anonymous Offline Survey Tool: No names, emails, phone numbers, "
    "or personally identifying information (PII) are collected or stored."
)
MEDICAL_DISCLAIMER: str = (
    "Statistical Notice: Survey metrics and threshold warnings reflect "
    "self-reported aggregated patterns only and do not constitute medical "
    "advice or clinical diagnosis."
)

# Directory Paths
BASE_DIR: Path = Path(__file__).resolve().parent
DATA_DIR: Path = BASE_DIR / "data"
REPORTS_DIR: Path = BASE_DIR / "reports"
CHARTS_DIR: Path = REPORTS_DIR / "charts"
LOGS_DIR: Path = BASE_DIR / "logs"

RESPONSES_CSV_PATH: Path = DATA_DIR / "responses.csv"
RESPONSES_JSON_PATH: Path = DATA_DIR / "responses.json"
SAMPLE_CSV_PATH: Path = DATA_DIR / "sample_data.csv"
SAMPLE_JSON_PATH: Path = DATA_DIR / "sample_data.json"
APP_LOG_PATH: Path = LOGS_DIR / "application.log"
IMPORT_LOG_PATH: Path = LOGS_DIR / "csv_import.log"

# Anonymous Survey Schema Fields (strictly non-PII)
CSV_FIELDNAMES: List[str] = [
    "record_id",
    "survey_date",
    "age_group",
    "sleep_duration",
    "physical_activity",
    "stress_level",
    "mood_rating",
    "general_wellness",
    "data_origin",
]

VALID_AGE_GROUPS: Tuple[str, ...] = (
    "Prefer not to say",
    "18-24",
    "25-34",
    "35-44",
    "45-54",
    "55+",
)

VALID_DATA_ORIGINS: Tuple[str, ...] = (
    "user_entry",
    "csv_import",
    "synthetic_demo",
)

# Documented Validation Ranges
SLEEP_MIN_HOURS: float = 0.0
SLEEP_MAX_HOURS: float = 24.0
ACTIVITY_MIN_MINUTES: int = 0
ACTIVITY_MAX_MINUTES: int = 600
SCALE_MIN: int = 1
SCALE_MAX: int = 10
DATE_FORMAT: str = "%Y-%m-%d"
MIN_SURVEY_YEAR: int = 2020

# Category Thresholds
WELLNESS_CATEGORIES: Dict[str, Tuple[int, int]] = {
    "Low": (1, 4),
    "Moderate": (5, 7),
    "High": (8, 10),
}

STRESS_CATEGORIES: Dict[str, Tuple[int, int]] = {
    "Low": (1, 3),
    "Moderate": (4, 6),
    "High": (7, 10),
}

SLEEP_CATEGORIES: Dict[str, Tuple[float, float]] = {
    "Short (<6h)": (0.0, 5.99),
    "Moderate (6-6.9h)": (6.0, 6.99),
    "Optimal (7-9h)": (7.0, 9.0),
    "Extended (>9h)": (9.01, 24.0),
}

ACTIVITY_CATEGORIES: Dict[str, Tuple[int, int]] = {
    "Sedentary (<30m)": (0, 29),
    "Moderate (30-59m)": (30, 59),
    "Active (60m+)": (60, 600),
}

# Statistical Warning Thresholds (Non-diagnostic)
THRESHOLD_WARNINGS: Dict[str, float] = {
    "very_low_sleep_hours": 4.0,
    "very_high_sleep_hours": 14.0,
    "extreme_activity_minutes": 300.0,
    "elevated_stress_level": 8.0,
    "low_wellness_rating": 3.0,
    "low_mood_rating": 3.0,
    "trend_shift_delta": 1.5,
}


def ensure_directories() -> None:
    """Create required application directories if they do not already exist."""
    for directory in (DATA_DIR, REPORTS_DIR, CHARTS_DIR, LOGS_DIR):
        directory.mkdir(parents=True, exist_ok=True)


def configure_logging(log_file: Path = APP_LOG_PATH) -> logging.Logger:
    """Configure application-wide file logging without cluttering terminal stdout."""
    ensure_directories()
    logger = logging.getLogger("wellness_visualizer")
    if not logger.handlers:
        logger.setLevel(logging.INFO)
        handler = logging.FileHandler(log_file, encoding="utf-8")
        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    return logger
