"""Data model definitions for anonymous wellness survey records."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import secrets
from typing import Any, Dict

from config import (
    ACTIVITY_CATEGORIES,
    SLEEP_CATEGORIES,
    STRESS_CATEGORIES,
    WELLNESS_CATEGORIES,
)


def generate_record_id() -> str:
    """Generate a random, non-identifying anonymous survey record ID."""
    token = secrets.token_hex(3).upper()
    return f"WSV-{token}"


@dataclass(frozen=False)
class SurveyRecord:
    """Represents a single anonymous wellness survey response."""

    record_id: str
    survey_date: str
    age_group: str
    sleep_duration: float
    physical_activity: int
    stress_level: int
    mood_rating: int
    general_wellness: int
    data_origin: str = "user_entry"

    def to_dict(self) -> Dict[str, Any]:
        """Serialize record to a plain dictionary."""
        return asdict(self)

    @property
    def wellness_category(self) -> str:
        """Return categorical tier for general wellness rating."""
        for label, (low, high) in WELLNESS_CATEGORIES.items():
            if low <= self.general_wellness <= high:
                return label
        return "Unknown"

    @property
    def stress_category(self) -> str:
        """Return categorical tier for stress level."""
        for label, (low, high) in STRESS_CATEGORIES.items():
            if low <= self.stress_level <= high:
                return label
        return "Unknown"

    @property
    def sleep_category(self) -> str:
        """Return categorical tier for sleep duration."""
        for label, (low, high) in SLEEP_CATEGORIES.items():
            if low <= self.sleep_duration <= high:
                return label
        return "Unknown"

    @property
    def activity_category(self) -> str:
        """Return categorical tier for daily physical activity."""
        for label, (low, high) in ACTIVITY_CATEGORIES.items():
            if low <= self.physical_activity <= high:
                return label
        return "Unknown"
