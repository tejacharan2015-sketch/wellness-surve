"""Defensive input validation and non-diagnostic statistical anomaly detection."""

from __future__ import annotations

from datetime import date, datetime
import re
from typing import Any, Dict, List, Optional, Tuple

from config import (
    ACTIVITY_MAX_MINUTES,
    ACTIVITY_MIN_MINUTES,
    DATE_FORMAT,
    MIN_SURVEY_YEAR,
    SCALE_MAX,
    SCALE_MIN,
    SLEEP_MAX_HOURS,
    SLEEP_MIN_HOURS,
    THRESHOLD_WARNINGS,
    VALID_AGE_GROUPS,
    VALID_DATA_ORIGINS,
)
from core.models import SurveyRecord, generate_record_id

RECORD_ID_PATTERN = re.compile(r"^[A-Za-z0-9_-]{4,24}$")
EMAIL_PATTERN = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
PHONE_PATTERN = re.compile(r"\b(?:\+?\d[\d\s().-]{7,}\d)\b")


class ValidationError(ValueError):
    """Raised when survey input fails validation constraints."""


def check_no_pii_text(value: str, field_name: str) -> None:
    """Reject accidental email or phone-number strings to preserve anonymity."""
    if EMAIL_PATTERN.search(value) or PHONE_PATTERN.search(value):
        raise ValidationError(
            f"{field_name} appears to contain personally identifying contact info. "
            "Survey entries must remain strictly anonymous."
        )


def validate_record_id(raw_value: Any, allow_auto: bool = True) -> str:
    """Validate an anonymous record ID or auto-generate one if allowed."""
    if raw_value is None or str(raw_value).strip() == "":
        if allow_auto:
            return generate_record_id()
        raise ValidationError("Record ID cannot be empty.")

    cleaned = str(raw_value).strip().upper()
    check_no_pii_text(cleaned, "Record ID")
    if not RECORD_ID_PATTERN.match(cleaned):
        raise ValidationError(
            "Record ID must be 4-24 characters using only letters, numbers, '-' or '_'."
        )
    return cleaned


def validate_survey_date(raw_value: Any, allow_today_default: bool = False) -> str:
    """Validate YYYY-MM-DD calendar date within reasonable project bounds."""
    if raw_value is None or str(raw_value).strip() == "":
        if allow_today_default:
            return date.today().strftime(DATE_FORMAT)
        raise ValidationError("Survey date cannot be empty. Expected format: YYYY-MM-DD.")

    cleaned = str(raw_value).strip()
    try:
        parsed = datetime.strptime(cleaned, DATE_FORMAT).date()
    except ValueError as exc:
        raise ValidationError(
            f"Invalid survey date '{cleaned}'. Please use YYYY-MM-DD (e.g., 2026-11-24)."
        ) from exc

    today = date.today()
    if parsed.year < MIN_SURVEY_YEAR:
        raise ValidationError(
            f"Survey year {parsed.year} is out of range (minimum year: {MIN_SURVEY_YEAR})."
        )
    if parsed > today:
        raise ValidationError(
            f"Survey date '{cleaned}' cannot be in the future (today is {today.isoformat()})."
        )
    return parsed.strftime(DATE_FORMAT)


def validate_age_group(raw_value: Any) -> str:
    """Validate optional age group category."""
    if raw_value is None or str(raw_value).strip() == "":
        return "Prefer not to say"

    cleaned = str(raw_value).strip()
    check_no_pii_text(cleaned, "Age Group")
    lookup = {item.lower(): item for item in VALID_AGE_GROUPS}
    if cleaned.lower() in lookup:
        return lookup[cleaned.lower()]

    raise ValidationError(
        f"Invalid age group '{cleaned}'. Allowed values: {', '.join(VALID_AGE_GROUPS)}."
    )


def validate_sleep_duration(raw_value: Any) -> float:
    """Validate sleep duration in hours (0.0 to 24.0)."""
    if raw_value is None or isinstance(raw_value, bool) or str(raw_value).strip() == "":
        raise ValidationError(
            f"Sleep duration is required ({SLEEP_MIN_HOURS} to {SLEEP_MAX_HOURS} hours)."
        )
    try:
        hours = float(str(raw_value).strip())
    except (ValueError, TypeError) as exc:
        raise ValidationError(
            f"Invalid sleep duration '{raw_value}'. Enter a number in hours (e.g., 7.5)."
        ) from exc

    if hours != hours:  # NaN guard
        raise ValidationError("Sleep duration cannot be NaN.")
    if hours < SLEEP_MIN_HOURS or hours > SLEEP_MAX_HOURS:
        raise ValidationError(
            f"Sleep duration {hours} is out of permitted range "
            f"({SLEEP_MIN_HOURS} to {SLEEP_MAX_HOURS} hours)."
        )
    return round(hours, 2)


def validate_physical_activity(raw_value: Any) -> int:
    """Validate daily physical activity in whole minutes (0 to 600)."""
    if raw_value is None or isinstance(raw_value, bool) or str(raw_value).strip() == "":
        raise ValidationError(
            f"Physical activity is required ({ACTIVITY_MIN_MINUTES} to {ACTIVITY_MAX_MINUTES} minutes)."
        )
    text = str(raw_value).strip()
    try:
        numeric = float(text)
    except (ValueError, TypeError) as exc:
        raise ValidationError(
            f"Invalid physical activity '{raw_value}'. Enter a whole number of minutes (e.g., 45)."
        ) from exc

    if not numeric.is_integer():
        raise ValidationError(
            f"Physical activity '{raw_value}' must be a whole number of minutes."
        )
    minutes = int(numeric)
    if minutes < ACTIVITY_MIN_MINUTES or minutes > ACTIVITY_MAX_MINUTES:
        raise ValidationError(
            f"Physical activity {minutes} minutes is outside permitted range "
            f"({ACTIVITY_MIN_MINUTES} to {ACTIVITY_MAX_MINUTES} minutes)."
        )
    return minutes


def validate_scale_rating(raw_value: Any, field_label: str) -> int:
    """Validate an integer 1-10 Likert-scale rating."""
    if raw_value is None or isinstance(raw_value, bool) or str(raw_value).strip() == "":
        raise ValidationError(f"{field_label} is required ({SCALE_MIN} to {SCALE_MAX}).")
    text = str(raw_value).strip()
    try:
        numeric = float(text)
    except (ValueError, TypeError) as exc:
        raise ValidationError(
            f"Invalid {field_label.lower()} '{raw_value}'. Enter an integer from {SCALE_MIN} to {SCALE_MAX}."
        ) from exc

    if not numeric.is_integer():
        raise ValidationError(
            f"{field_label} '{raw_value}' must be an integer between {SCALE_MIN} and {SCALE_MAX}."
        )
    value = int(numeric)
    if value < SCALE_MIN or value > SCALE_MAX:
        raise ValidationError(
            f"{field_label} {value} is outside permitted range ({SCALE_MIN} to {SCALE_MAX})."
        )
    return value


def validate_data_origin(raw_value: Any) -> str:
    """Validate internal non-identifying origin tag."""
    if raw_value is None or str(raw_value).strip() == "":
        return "user_entry"
    cleaned = str(raw_value).strip().lower()
    if cleaned in VALID_DATA_ORIGINS:
        return cleaned
    return "user_entry"


def validate_record_payload(
    payload: Dict[str, Any],
    allow_auto_id: bool = True,
    allow_today_default: bool = False,
) -> Tuple[Optional[SurveyRecord], List[str]]:
    """Validate an entire survey payload dict and collect all field errors."""
    errors: List[str] = []

    if not isinstance(payload, dict):
        return None, ["Malformed record: expected a dictionary/object."]

    record_id = ""
    survey_date = ""
    age_group = "Prefer not to say"
    sleep_duration = 0.0
    physical_activity = 0
    stress_level = 5
    mood_rating = 5
    general_wellness = 5

    try:
        record_id = validate_record_id(payload.get("record_id"), allow_auto=allow_auto_id)
    except ValidationError as exc:
        errors.append(str(exc))

    try:
        survey_date = validate_survey_date(
            payload.get("survey_date"), allow_today_default=allow_today_default
        )
    except ValidationError as exc:
        errors.append(str(exc))

    try:
        age_group = validate_age_group(payload.get("age_group"))
    except ValidationError as exc:
        errors.append(str(exc))

    try:
        sleep_duration = validate_sleep_duration(payload.get("sleep_duration"))
    except ValidationError as exc:
        errors.append(str(exc))

    try:
        physical_activity = validate_physical_activity(payload.get("physical_activity"))
    except ValidationError as exc:
        errors.append(str(exc))

    try:
        stress_level = validate_scale_rating(payload.get("stress_level"), "Stress Level")
    except ValidationError as exc:
        errors.append(str(exc))

    try:
        mood_rating = validate_scale_rating(payload.get("mood_rating"), "Mood Rating")
    except ValidationError as exc:
        errors.append(str(exc))

    try:
        general_wellness = validate_scale_rating(
            payload.get("general_wellness"), "General Wellness Rating"
        )
    except ValidationError as exc:
        errors.append(str(exc))

    data_origin = validate_data_origin(payload.get("data_origin"))

    if errors:
        return None, errors

    return (
        SurveyRecord(
            record_id=record_id,
            survey_date=survey_date,
            age_group=age_group,
            sleep_duration=sleep_duration,
            physical_activity=physical_activity,
            stress_level=stress_level,
            mood_rating=mood_rating,
            general_wellness=general_wellness,
            data_origin=data_origin,
        ),
        [],
    )


def detect_record_warnings(record: SurveyRecord) -> List[str]:
    """Identify unusual or boundary statistical patterns for a single entry.

    Note: Warnings are strictly statistical flags and never medical advice.
    """
    warnings: List[str] = []
    if record.sleep_duration <= THRESHOLD_WARNINGS["very_low_sleep_hours"]:
        warnings.append(
            f"Statistical flag ({record.record_id}): Very short sleep reported ({record.sleep_duration}h <= {THRESHOLD_WARNINGS['very_low_sleep_hours']}h)."
        )
    elif record.sleep_duration >= THRESHOLD_WARNINGS["very_high_sleep_hours"]:
        warnings.append(
            f"Statistical flag ({record.record_id}): Unusually long sleep reported ({record.sleep_duration}h >= {THRESHOLD_WARNINGS['very_high_sleep_hours']}h)."
        )

    if record.physical_activity >= THRESHOLD_WARNINGS["extreme_activity_minutes"]:
        warnings.append(
            f"Statistical flag ({record.record_id}): High activity outlier ({record.physical_activity} min >= {int(THRESHOLD_WARNINGS['extreme_activity_minutes'])} min)."
        )

    if record.stress_level >= THRESHOLD_WARNINGS["elevated_stress_level"]:
        warnings.append(
            f"Statistical flag ({record.record_id}): Elevated self-reported stress ({record.stress_level}/10)."
        )

    if record.general_wellness <= THRESHOLD_WARNINGS["low_wellness_rating"]:
        warnings.append(
            f"Statistical flag ({record.record_id}): Low self-reported wellness score ({record.general_wellness}/10)."
        )

    if record.mood_rating <= THRESHOLD_WARNINGS["low_mood_rating"]:
        warnings.append(
            f"Statistical flag ({record.record_id}): Low self-reported mood rating ({record.mood_rating}/10)."
        )

    # Logical divergence check: high wellness despite extreme stress & minimal sleep
    if record.general_wellness >= 9 and record.stress_level >= 9 and record.sleep_duration <= 3:
        warnings.append(
            f"Anomaly flag ({record.record_id}): Unusual response combination (wellness {record.general_wellness}/10 with stress {record.stress_level}/10 and {record.sleep_duration}h sleep)."
        )

    return warnings
