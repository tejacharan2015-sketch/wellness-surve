"""Reliable local CSV and JSON persistence with defensive error recovery
and bulk CSV dataset import capabilities.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass, field
from datetime import datetime
import json
import logging
from pathlib import Path
import shutil
from typing import Dict, List, Optional, Tuple

from config import (
    APP_VERSION,
    CSV_FIELDNAMES,
    IMPORT_LOG_PATH,
    RESPONSES_CSV_PATH,
    RESPONSES_JSON_PATH,
    ensure_directories,
)
from core.models import SurveyRecord
from core.validation import validate_record_payload

logger = logging.getLogger("wellness_visualizer.storage")


@dataclass
class StorageLoadResult:
    """Result metadata from loading persisted survey records."""

    records: List[SurveyRecord] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    skipped_rows: int = 0
    recovered_from_backup: bool = False


@dataclass
class ImportSummary:
    """Detailed outcome of a bulk CSV import operation."""

    source_file: str
    total_rows: int = 0
    imported_count: int = 0
    duplicate_count: int = 0
    invalid_count: int = 0
    missing_columns: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    imported_ids: List[str] = field(default_factory=list)
    log_path: str = ""


class SurveyStorage:
    """Handles dual CSV and JSON local persistence for anonymous survey records."""

    def __init__(
        self,
        csv_path: Path = RESPONSES_CSV_PATH,
        json_path: Path = RESPONSES_JSON_PATH,
        import_log_path: Path = IMPORT_LOG_PATH,
    ) -> None:
        self.csv_path = Path(csv_path)
        self.json_path = Path(json_path)
        self.import_log_path = Path(import_log_path)
        ensure_directories()
        self.csv_path.parent.mkdir(parents=True, exist_ok=True)
        self.json_path.parent.mkdir(parents=True, exist_ok=True)
        self.import_log_path.parent.mkdir(parents=True, exist_ok=True)

    def ensure_storage_files(self) -> None:
        """Create empty CSV and JSON files if they do not exist yet."""
        if not self.csv_path.exists():
            self._write_csv_atomic([])
        if not self.json_path.exists():
            self._write_json_atomic([])

    def _write_csv_atomic(self, records: List[SurveyRecord]) -> None:
        """Write records to CSV atomically using a temporary staging file."""
        tmp_path = self.csv_path.with_suffix(".csv.tmp")
        with tmp_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=CSV_FIELDNAMES)
            writer.writeheader()
            for record in records:
                writer.writerow(record.to_dict())
        tmp_path.replace(self.csv_path)

    def _write_json_atomic(self, records: List[SurveyRecord]) -> None:
        """Write records to JSON atomically with metadata envelope."""
        tmp_path = self.json_path.with_suffix(".json.tmp")
        payload = {
            "schema_version": APP_VERSION,
            "anonymous_only": True,
            "record_count": len(records),
            "updated_at": datetime.now().isoformat(timespec="seconds"),
            "records": [record.to_dict() for record in records],
        }
        with tmp_path.open("w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2)
        tmp_path.replace(self.json_path)

    def save_all(self, records: List[SurveyRecord]) -> None:
        """Persist all records immediately to both CSV and JSON storage."""
        self._write_csv_atomic(records)
        self._write_json_atomic(records)
        logger.info("Persisted %d survey record(s) to CSV and JSON.", len(records))

    def _backup_corrupt_file(self, path: Path) -> Optional[Path]:
        """Preserve corrupted storage file before rewriting clean storage."""
        if not path.exists():
            return None
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = path.with_name(f"{path.stem}_corrupt_{timestamp}{path.suffix}")
        try:
            shutil.copy2(path, backup_path)
            return backup_path
        except OSError as exc:
            logger.error("Failed to back up corrupted file %s: %s", path, exc)
            return None

    def load_records(self) -> StorageLoadResult:
        """Load persisted records, recovering gracefully from corruption or missing files."""
        self.ensure_storage_files()
        result = StorageLoadResult()

        json_records, json_warnings, json_corrupt, json_skipped = self._load_json_safe()
        csv_records, csv_warnings, csv_skipped = self._load_csv_safe()

        result.warnings.extend(json_warnings)
        result.warnings.extend(csv_warnings)

        if not json_corrupt and json_records:
            result.records = json_records
            result.skipped_rows = json_skipped
            if len(json_records) != len(csv_records):
                self._write_csv_atomic(json_records)
            return result

        if csv_records:
            result.records = csv_records
            result.skipped_rows = csv_skipped
            if json_corrupt:
                result.recovered_from_backup = True
                result.warnings.append(
                    "Recovered records from CSV after detecting corrupted JSON storage."
                )
                self._write_json_atomic(csv_records)
            return result

        if json_corrupt:
            self._write_json_atomic([])
        result.skipped_rows = json_skipped + csv_skipped
        return result

    def _load_json_safe(self) -> Tuple[List[SurveyRecord], List[str], bool, int]:
        """Load and validate records from JSON storage without raising on corruption."""
        warnings: List[str] = []
        records: List[SurveyRecord] = []
        skipped = 0

        if not self.json_path.exists():
            return records, warnings, False, skipped

        try:
            raw_text = self.json_path.read_text(encoding="utf-8").strip()
            if not raw_text:
                return records, warnings, False, skipped
            parsed = json.loads(raw_text)
        except (OSError, json.JSONDecodeError) as exc:
            backup = self._backup_corrupt_file(self.json_path)
            msg = f"Corrupted JSON storage detected ({exc})."
            if backup:
                msg += f" Backup saved to {backup.name}."
            warnings.append(msg)
            logger.error(msg)
            return [], warnings, True, 0

        raw_list = parsed.get("records", []) if isinstance(parsed, dict) else parsed
        if not isinstance(raw_list, list):
            backup = self._backup_corrupt_file(self.json_path)
            msg = "JSON storage structure invalid (expected list of records)."
            if backup:
                msg += f" Backup saved to {backup.name}."
            warnings.append(msg)
            logger.error(msg)
            return [], warnings, True, 0

        seen_ids = set()
        for idx, item in enumerate(raw_list, start=1):
            record, errs = validate_record_payload(item, allow_auto_id=False)
            if record is None:
                skipped += 1
                warnings.append(f"JSON item #{idx} skipped: {'; '.join(errs)}")
                continue
            if record.record_id in seen_ids:
                skipped += 1
                warnings.append(
                    f"JSON item #{idx} skipped: duplicate record_id '{record.record_id}'."
                )
                continue
            seen_ids.add(record.record_id)
            records.append(record)

        return records, warnings, False, skipped

    def _load_csv_safe(self) -> Tuple[List[SurveyRecord], List[str], int]:
        """Load and validate records from CSV storage row by row."""
        warnings: List[str] = []
        records: List[SurveyRecord] = []
        skipped = 0

        if not self.csv_path.exists():
            return records, warnings, skipped

        try:
            with self.csv_path.open("r", newline="", encoding="utf-8") as handle:
                reader = csv.DictReader(handle)
                if reader.fieldnames is None:
                    return records, warnings, skipped
                seen_ids = set()
                for row_num, row in enumerate(reader, start=2):
                    if None in row:
                        skipped += 1
                        warnings.append(
                            f"CSV line {row_num} malformed (extra columns detected); skipped."
                        )
                        continue
                    record, errs = validate_record_payload(row, allow_auto_id=False)
                    if record is None:
                        skipped += 1
                        warnings.append(
                            f"CSV line {row_num} skipped: {'; '.join(errs)}"
                        )
                        continue
                    if record.record_id in seen_ids:
                        skipped += 1
                        warnings.append(
                            f"CSV line {row_num} skipped: duplicate record_id '{record.record_id}'."
                        )
                        continue
                    seen_ids.add(record.record_id)
                    records.append(record)
        except (OSError, csv.Error, UnicodeDecodeError) as exc:
            msg = f"Failed reading CSV storage ({exc})."
            warnings.append(msg)
            logger.error(msg)

        return records, warnings, skipped

    def import_csv_dataset(
        self,
        source_csv_path: Path,
        existing_records: List[SurveyRecord],
        default_origin: str = "csv_import",
    ) -> Tuple[List[SurveyRecord], ImportSummary]:
        """Validate and bulk-import records from an external CSV dataset."""
        source = Path(source_csv_path)
        summary = ImportSummary(source_file=str(source))
        required_cols = {
            "survey_date",
            "sleep_duration",
            "physical_activity",
            "stress_level",
            "mood_rating",
            "general_wellness",
        }

        if not source.exists() or not source.is_file():
            summary.errors.append(f"CSV file not found: {source}")
            self._write_import_log(summary)
            return [], summary

        try:
            with source.open("r", newline="", encoding="utf-8-sig") as handle:
                reader = csv.DictReader(handle)
                if not reader.fieldnames:
                    summary.errors.append("CSV file is empty or missing a header row.")
                    self._write_import_log(summary)
                    return [], summary

                normalized_headers = {col.strip().lower() for col in reader.fieldnames if col}
                missing = sorted(required_cols - normalized_headers)
                if missing:
                    summary.missing_columns = missing
                    summary.errors.append(
                        f"Missing required column(s): {', '.join(missing)}"
                    )
                    self._write_import_log(summary)
                    return [], summary

                existing_ids = {rec.record_id for rec in existing_records}
                imported: List[SurveyRecord] = []

                for row_num, raw_row in enumerate(reader, start=2):
                    summary.total_rows += 1
                    if None in raw_row:
                        summary.invalid_count += 1
                        summary.errors.append(
                            f"Row {row_num}: Malformed CSV column count."
                        )
                        continue

                    cleaned_row: Dict[str, str] = {
                        str(k).strip().lower(): (v.strip() if isinstance(v, str) else "")
                        for k, v in raw_row.items()
                        if k is not None
                    }
                    if not cleaned_row.get("data_origin"):
                        cleaned_row["data_origin"] = default_origin

                    record, errs = validate_record_payload(
                        cleaned_row, allow_auto_id=True, allow_today_default=False
                    )
                    if record is None:
                        summary.invalid_count += 1
                        summary.errors.append(
                            f"Row {row_num}: {' | '.join(errs)}"
                        )
                        continue

                    if record.record_id in existing_ids:
                        summary.duplicate_count += 1
                        summary.errors.append(
                            f"Row {row_num}: Duplicate record_id '{record.record_id}' skipped."
                        )
                        continue

                    existing_ids.add(record.record_id)
                    imported.append(record)
                    summary.imported_count += 1
                    summary.imported_ids.append(record.record_id)

        except (OSError, csv.Error, UnicodeDecodeError) as exc:
            summary.errors.append(f"Unable to parse CSV file: {exc}")

        self._write_import_log(summary)
        return imported, summary

    def _write_import_log(self, summary: ImportSummary) -> None:
        """Persist a detailed audit log for every CSV bulk import."""
        lines = [
            f"=== CSV IMPORT AUDIT | {datetime.now().isoformat(timespec='seconds')} ===",
            f"Source: {summary.source_file}",
            f"Total Rows Processed: {summary.total_rows}",
            f"Imported: {summary.imported_count}",
            f"Duplicates Skipped: {summary.duplicate_count}",
            f"Invalid Rows Skipped: {summary.invalid_count}",
        ]
        if summary.missing_columns:
            lines.append(f"Missing Columns: {', '.join(summary.missing_columns)}")
        if summary.errors:
            lines.append("Row Issues:")
            lines.extend(f"  - {err}" for err in summary.errors)
        lines.append("")

        try:
            with self.import_log_path.open("a", encoding="utf-8") as handle:
                handle.write("\n".join(lines))
            summary.log_path = str(self.import_log_path)
        except OSError as exc:
            logger.error("Could not write CSV import log: %s", exc)
