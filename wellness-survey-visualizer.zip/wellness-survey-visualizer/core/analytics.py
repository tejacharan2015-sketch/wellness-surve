"""Statistical analytics engine and threshold warning analyzer."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from statistics import median
from typing import Dict, List, Optional, Tuple

from config import (
    ACTIVITY_CATEGORIES,
    MEDICAL_DISCLAIMER,
    SLEEP_CATEGORIES,
    STRESS_CATEGORIES,
    THRESHOLD_WARNINGS,
    WELLNESS_CATEGORIES,
)
from core.models import SurveyRecord
from core.validation import detect_record_warnings


@dataclass
class MetricSummary:
    """Descriptive statistics for a single numerical wellness dimension."""

    average: float
    median_value: float
    minimum: float
    maximum: float


@dataclass
class TrendPoint:
    """Aggregated daily averages for chronological trend analysis."""

    survey_date: str
    count: int
    avg_sleep: float
    avg_activity: float
    avg_stress: float
    avg_mood: float
    avg_wellness: float


@dataclass
class CategoryBreakdown:
    """Count and percentage breakdown across categories."""

    counts: Dict[str, int]
    percentages: Dict[str, float]


@dataclass
class AnalyticsReport:
    """Complete computed analytics state across stored survey records."""

    total_responses: int
    is_empty: bool
    date_range: Tuple[str, str]
    sleep_stats: Optional[MetricSummary] = None
    activity_stats: Optional[MetricSummary] = None
    stress_stats: Optional[MetricSummary] = None
    mood_stats: Optional[MetricSummary] = None
    wellness_stats: Optional[MetricSummary] = None
    wellness_distribution: Optional[CategoryBreakdown] = None
    stress_distribution: Optional[CategoryBreakdown] = None
    sleep_distribution: Optional[CategoryBreakdown] = None
    activity_distribution: Optional[CategoryBreakdown] = None
    age_distribution: Optional[CategoryBreakdown] = None
    highest_avg_metric: Optional[Tuple[str, float]] = None
    lowest_avg_metric: Optional[Tuple[str, float]] = None
    highest_wellness_day: Optional[Tuple[str, float]] = None
    lowest_wellness_day: Optional[Tuple[str, float]] = None
    trends: List[TrendPoint] = field(default_factory=list)
    wellness_trend_delta: float = 0.0
    stress_trend_delta: float = 0.0
    threshold_warnings: List[str] = field(default_factory=list)
    observations: List[str] = field(default_factory=list)
    disclaimer: str = MEDICAL_DISCLAIMER


def _summarize_numbers(values: List[float]) -> MetricSummary:
    """Compute mean, median, min, and max rounded cleanly."""
    return MetricSummary(
        average=round(sum(values) / len(values), 2),
        median_value=round(float(median(values)), 2),
        minimum=round(min(values), 2),
        maximum=round(max(values), 2),
    )


def _build_distribution(labels: List[str], ordered_keys: List[str]) -> CategoryBreakdown:
    """Calculate category counts and percentage shares."""
    total = len(labels)
    counts: Dict[str, int] = {key: 0 for key in ordered_keys}
    for label in labels:
        counts[label] = counts.get(label, 0) + 1

    percentages: Dict[str, float] = {
        key: round((count / total) * 100.0, 1) if total > 0 else 0.0
        for key, count in counts.items()
    }
    return CategoryBreakdown(counts=counts, percentages=percentages)


def compute_analytics(
    records: List[SurveyRecord],
    storage_warnings: Optional[List[str]] = None,
) -> AnalyticsReport:
    """Calculate comprehensive wellness analytics across valid survey records."""
    if not records:
        warnings = list(storage_warnings or [])
        warnings.append(
            "Dataset is currently empty. Add survey responses or import sample data to compute trends."
        )
        return AnalyticsReport(
            total_responses=0,
            is_empty=True,
            date_range=("N/A", "N/A"),
            threshold_warnings=warnings,
            observations=["No records available for statistical evaluation."],
        )

    sleep_vals = [float(r.sleep_duration) for r in records]
    activity_vals = [float(r.physical_activity) for r in records]
    stress_vals = [float(r.stress_level) for r in records]
    mood_vals = [float(r.mood_rating) for r in records]
    wellness_vals = [float(r.general_wellness) for r in records]

    sleep_stats = _summarize_numbers(sleep_vals)
    activity_stats = _summarize_numbers(activity_vals)
    stress_stats = _summarize_numbers(stress_vals)
    mood_stats = _summarize_numbers(mood_vals)
    wellness_stats = _summarize_numbers(wellness_vals)

    dates_sorted = sorted(r.survey_date for r in records)
    date_range = (dates_sorted[0], dates_sorted[-1])

    wellness_dist = _build_distribution(
        [r.wellness_category for r in records],
        list(WELLNESS_CATEGORIES.keys()),
    )
    stress_dist = _build_distribution(
        [r.stress_category for r in records],
        list(STRESS_CATEGORIES.keys()),
    )
    sleep_dist = _build_distribution(
        [r.sleep_category for r in records],
        list(SLEEP_CATEGORIES.keys()),
    )
    activity_dist = _build_distribution(
        [r.activity_category for r in records],
        list(ACTIVITY_CATEGORIES.keys()),
    )

    age_keys = sorted({r.age_group for r in records})
    age_dist = _build_distribution([r.age_group for r in records], age_keys)

    # Compare 1-10 Likert-scale metrics for highest/lowest average ratings
    scale_averages = {
        "General Wellness": wellness_stats.average,
        "Mood Rating": mood_stats.average,
        "Stress Level": stress_stats.average,
    }
    highest_avg_metric = max(scale_averages.items(), key=lambda item: item[1])
    lowest_avg_metric = min(scale_averages.items(), key=lambda item: item[1])

    # Daily chronological trends
    grouped: Dict[str, List[SurveyRecord]] = defaultdict(list)
    for rec in records:
        grouped[rec.survey_date].append(rec)

    trends: List[TrendPoint] = []
    for day in sorted(grouped.keys()):
        day_recs = grouped[day]
        n = len(day_recs)
        trends.append(
            TrendPoint(
                survey_date=day,
                count=n,
                avg_sleep=round(sum(r.sleep_duration for r in day_recs) / n, 2),
                avg_activity=round(sum(r.physical_activity for r in day_recs) / n, 2),
                avg_stress=round(sum(r.stress_level for r in day_recs) / n, 2),
                avg_mood=round(sum(r.mood_rating for r in day_recs) / n, 2),
                avg_wellness=round(sum(r.general_wellness for r in day_recs) / n, 2),
            )
        )

    highest_wellness_day: Optional[Tuple[str, float]] = None
    lowest_wellness_day: Optional[Tuple[str, float]] = None
    if trends:
        best_day = max(trends, key=lambda t: t.avg_wellness)
        worst_day = min(trends, key=lambda t: t.avg_wellness)
        highest_wellness_day = (best_day.survey_date, best_day.avg_wellness)
        lowest_wellness_day = (worst_day.survey_date, worst_day.avg_wellness)

    wellness_delta = 0.0
    stress_delta = 0.0
    if len(trends) >= 2:
        midpoint = len(trends) // 2
        first_half = trends[:midpoint]
        second_half = trends[midpoint:]
        early_w = sum(t.avg_wellness for t in first_half) / len(first_half)
        late_w = sum(t.avg_wellness for t in second_half) / len(second_half)
        wellness_delta = round(late_w - early_w, 2)

        early_s = sum(t.avg_stress for t in first_half) / len(first_half)
        late_s = sum(t.avg_stress for t in second_half) / len(second_half)
        stress_delta = round(late_s - early_s, 2)

    # Threshold Warning System (non-diagnostic)
    warnings: List[str] = list(storage_warnings or [])
    for rec in records:
        warnings.extend(detect_record_warnings(rec))

    if abs(wellness_delta) >= THRESHOLD_WARNINGS["trend_shift_delta"]:
        direction = "upward" if wellness_delta > 0 else "downward"
        warnings.append(
            f"Aggregate trend shift: Average wellness changed by {wellness_delta:+.2f} pts ({direction}) between earlier and recent survey dates."
        )
    if abs(stress_delta) >= THRESHOLD_WARNINGS["trend_shift_delta"]:
        direction = "increase" if stress_delta > 0 else "decrease"
        warnings.append(
            f"Aggregate trend shift: Average stress showed a {stress_delta:+.2f} pt {direction} across the survey window."
        )

    observations = _generate_observations(
        total=len(records),
        sleep_stats=sleep_stats,
        activity_stats=activity_stats,
        stress_stats=stress_stats,
        mood_stats=mood_stats,
        wellness_stats=wellness_stats,
        wellness_dist=wellness_dist,
        stress_dist=stress_dist,
        wellness_delta=wellness_delta,
        stress_delta=stress_delta,
    )

    return AnalyticsReport(
        total_responses=len(records),
        is_empty=False,
        date_range=date_range,
        sleep_stats=sleep_stats,
        activity_stats=activity_stats,
        stress_stats=stress_stats,
        mood_stats=mood_stats,
        wellness_stats=wellness_stats,
        wellness_distribution=wellness_dist,
        stress_distribution=stress_dist,
        sleep_distribution=sleep_dist,
        activity_distribution=activity_dist,
        age_distribution=age_dist,
        highest_avg_metric=highest_avg_metric,
        lowest_avg_metric=lowest_avg_metric,
        highest_wellness_day=highest_wellness_day,
        lowest_wellness_day=lowest_wellness_day,
        trends=trends,
        wellness_trend_delta=wellness_delta,
        stress_trend_delta=stress_delta,
        threshold_warnings=warnings,
        observations=observations,
    )


def _generate_observations(
    total: int,
    sleep_stats: MetricSummary,
    activity_stats: MetricSummary,
    stress_stats: MetricSummary,
    mood_stats: MetricSummary,
    wellness_stats: MetricSummary,
    wellness_dist: CategoryBreakdown,
    stress_dist: CategoryBreakdown,
    wellness_delta: float,
    stress_delta: float,
) -> List[str]:
    """Synthesize clear, data-grounded analytical observations."""
    notes: List[str] = []

    high_w_pct = wellness_dist.percentages.get("High", 0.0)
    low_w_pct = wellness_dist.percentages.get("Low", 0.0)
    notes.append(
        f"Across {total} anonymous responses, overall wellness averages {wellness_stats.average}/10 "
        f"({high_w_pct}% High tier, {low_w_pct}% Low tier)."
    )

    if sleep_stats.average < 7.0:
        notes.append(
            f"Mean sleep duration is {sleep_stats.average} hours, below the 7.0-hour optimal tier baseline."
        )
    else:
        notes.append(
            f"Mean sleep duration is {sleep_stats.average} hours (median {sleep_stats.median_value}h), falling within the 7-9 hour optimal band."
        )

    high_stress_pct = stress_dist.percentages.get("High", 0.0)
    notes.append(
        f"Self-reported stress averages {stress_stats.average}/10 with {high_stress_pct}% of respondents in the High stress tier (7-10)."
    )

    notes.append(
        f"Physical activity averages {activity_stats.average} minutes/day (range {int(activity_stats.minimum)}-{int(activity_stats.maximum)} min), "
        f"alongside an average mood score of {mood_stats.average}/10."
    )

    if wellness_delta > 0.2:
        notes.append(
            f"Chronological comparison shows an improving wellness trajectory ({wellness_delta:+.2f} pts) alongside a {stress_delta:+.2f} pt change in stress."
        )
    elif wellness_delta < -0.2:
        notes.append(
            f"Chronological comparison shows a declining wellness trajectory ({wellness_delta:+.2f} pts) alongside a {stress_delta:+.2f} pt change in stress."
        )
    else:
        notes.append(
            "Overall wellness ratings remained relatively stable across the recorded survey dates."
        )

    return notes
