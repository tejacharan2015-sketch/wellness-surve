"""Executive summary report generator supporting Markdown, TXT, and CSV outputs."""

from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from config import (
    APP_NAME,
    APP_VERSION,
    CHALLENGE_NAME,
    MEDICAL_DISCLAIMER,
    PRIVACY_NOTICE,
    PROJECT_DOMAIN,
    PROJECT_NUMBER,
    REPORTS_DIR,
    ensure_directories,
)
from core.analytics import AnalyticsReport


def build_executive_summary_text(
    report: AnalyticsReport,
    chart_paths: Optional[List[Path]] = None,
    markdown: bool = False,
) -> str:
    """Render an academic/executive wellness report in Markdown or plain text."""
    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    h1 = "# " if markdown else ""
    h2 = "## " if markdown else ""
    bullet = "- " if markdown else "  * "

    lines: List[str] = []
    lines.append(f"{h1}{APP_NAME} — Executive Wellness Summary")
    lines.append("")
    lines.append(f"{bullet}**Project**: {PROJECT_NUMBER} | {PROJECT_DOMAIN} | {CHALLENGE_NAME}" if markdown else f"  Project: {PROJECT_NUMBER} | {PROJECT_DOMAIN} | {CHALLENGE_NAME}")
    lines.append(f"{bullet}**Version**: {APP_VERSION}" if markdown else f"  Version: {APP_VERSION}")
    lines.append(f"{bullet}**Report Generated**: {generated_at}" if markdown else f"  Report Generated: {generated_at}")
    lines.append(f"{bullet}**Total Anonymous Responses**: {report.total_responses}" if markdown else f"  Total Anonymous Responses: {report.total_responses}")
    lines.append(f"{bullet}**Survey Date Span**: {report.date_range[0]} to {report.date_range[1]}" if markdown else f"  Survey Date Span: {report.date_range[0]} to {report.date_range[1]}")
    lines.append("")
    lines.append(f"> {PRIVACY_NOTICE}" if markdown else f"PRIVACY: {PRIVACY_NOTICE}")
    lines.append(f"> {MEDICAL_DISCLAIMER}" if markdown else f"DISCLAIMER: {MEDICAL_DISCLAIMER}")
    lines.append("")

    if report.is_empty:
        lines.append(f"{h2}Status")
        lines.append("No survey records are currently stored. Add or import responses to populate statistics.")
        return "\n".join(lines)

    lines.append(f"{h2}1. Key Summary Statistics")
    if markdown:
        lines.append("| Metric | Average | Median | Minimum | Maximum |")
        lines.append("|---|---:|---:|---:|---:|")
        lines.append(f"| Sleep Duration (hrs) | {report.sleep_stats.average} | {report.sleep_stats.median_value} | {report.sleep_stats.minimum} | {report.sleep_stats.maximum} |")
        lines.append(f"| Physical Activity (min/day) | {report.activity_stats.average} | {report.activity_stats.median_value} | {int(report.activity_stats.minimum)} | {int(report.activity_stats.maximum)} |")
        lines.append(f"| Stress Level (1-10) | {report.stress_stats.average} | {report.stress_stats.median_value} | {int(report.stress_stats.minimum)} | {int(report.stress_stats.maximum)} |")
        lines.append(f"| Mood Rating (1-10) | {report.mood_stats.average} | {report.mood_stats.median_value} | {int(report.mood_stats.minimum)} | {int(report.mood_stats.maximum)} |")
        lines.append(f"| General Wellness (1-10) | {report.wellness_stats.average} | {report.wellness_stats.median_value} | {int(report.wellness_stats.minimum)} | {int(report.wellness_stats.maximum)} |")
    else:
        lines.append(f"  Sleep Duration (hrs)     : Avg {report.sleep_stats.average} | Med {report.sleep_stats.median_value} | Range {report.sleep_stats.minimum}-{report.sleep_stats.maximum}")
        lines.append(f"  Physical Activity (min)  : Avg {report.activity_stats.average} | Med {report.activity_stats.median_value} | Range {int(report.activity_stats.minimum)}-{int(report.activity_stats.maximum)}")
        lines.append(f"  Stress Level (1-10)      : Avg {report.stress_stats.average} | Med {report.stress_stats.median_value} | Range {int(report.stress_stats.minimum)}-{int(report.stress_stats.maximum)}")
        lines.append(f"  Mood Rating (1-10)       : Avg {report.mood_stats.average} | Med {report.mood_stats.median_value} | Range {int(report.mood_stats.minimum)}-{int(report.mood_stats.maximum)}")
        lines.append(f"  General Wellness (1-10)  : Avg {report.wellness_stats.average} | Med {report.wellness_stats.median_value} | Range {int(report.wellness_stats.minimum)}-{int(report.wellness_stats.maximum)}")
    lines.append("")

    if report.highest_avg_metric and report.lowest_avg_metric:
        lines.append(
            f"{bullet}Highest 1-10 scale average: {report.highest_avg_metric[0]} ({report.highest_avg_metric[1]}/10)"
        )
        lines.append(
            f"{bullet}Lowest 1-10 scale average: {report.lowest_avg_metric[0]} ({report.lowest_avg_metric[1]}/10)"
        )
    if report.highest_wellness_day and report.lowest_wellness_day:
        lines.append(
            f"{bullet}Peak wellness date: {report.highest_wellness_day[0]} ({report.highest_wellness_day[1]}/10)"
        )
        lines.append(
            f"{bullet}Lowest wellness date: {report.lowest_wellness_day[0]} ({report.lowest_wellness_day[1]}/10)"
        )
    lines.append("")

    lines.append(f"{h2}2. Category Distributions")
    dist_sections = [
        ("Overall Wellness Tiers", report.wellness_distribution),
        ("Stress Level Tiers", report.stress_distribution),
        ("Sleep Duration Tiers", report.sleep_distribution),
        ("Physical Activity Tiers", report.activity_distribution),
        ("Age Group Breakdown", report.age_distribution),
    ]
    for title, dist in dist_sections:
        if dist:
            lines.append(f"{title}:")
            for label, count in dist.counts.items():
                pct = dist.percentages.get(label, 0.0)
                lines.append(f"{bullet}{label}: {count} ({pct}%)")
    lines.append("")

    lines.append(f"{h2}3. Chronological Trends Across Survey Dates")
    lines.append(
        f"{bullet}Net Wellness Trend Delta (early vs. recent half): {report.wellness_trend_delta:+.2f} pts"
    )
    lines.append(
        f"{bullet}Net Stress Trend Delta (early vs. recent half): {report.stress_trend_delta:+.2f} pts"
    )
    if markdown:
        lines.append("")
        lines.append("| Date | Responses | Avg Sleep (h) | Avg Activity (m) | Avg Stress | Avg Mood | Avg Wellness |")
        lines.append("|---|---:|---:|---:|---:|---:|---:|")
        for pt in report.trends:
            lines.append(
                f"| {pt.survey_date} | {pt.count} | {pt.avg_sleep} | {pt.avg_activity} | {pt.avg_stress} | {pt.avg_mood} | {pt.avg_wellness} |"
            )
    else:
        for pt in report.trends:
            lines.append(
                f"  {pt.survey_date} (n={pt.count}): Sleep {pt.avg_sleep}h | Act {pt.avg_activity}m | Stress {pt.avg_stress} | Mood {pt.avg_mood} | Wellness {pt.avg_wellness}"
            )
    lines.append("")

    lines.append(f"{h2}4. Analytical Observations")
    for obs in report.observations:
        lines.append(f"{bullet}{obs}")
    lines.append("")

    lines.append(f"{h2}5. Threshold Warning Indicators (Non-Diagnostic)")
    if report.threshold_warnings:
        for warn in report.threshold_warnings[:20]:
            lines.append(f"{bullet}{warn}")
        if len(report.threshold_warnings) > 20:
            lines.append(
                f"{bullet}... and {len(report.threshold_warnings) - 20} additional statistical warning(s)."
            )
    else:
        lines.append(f"{bullet}No anomalous statistical threshold warnings triggered.")
    lines.append("")

    lines.append(f"{h2}6. Generated Visualization References")
    if chart_paths:
        for cp in chart_paths:
            lines.append(f"{bullet}{cp.name} ({cp})")
    else:
        lines.append(f"{bullet}Run chart generation to export PNG figures to reports/charts/.")

    return "\n".join(lines) + "\n"


def export_reports(
    report: AnalyticsReport,
    output_dir: Path = REPORTS_DIR,
    chart_paths: Optional[List[Path]] = None,
    formats: Optional[List[str]] = None,
    prefix: str = "executive_wellness_report",
) -> Dict[str, Path]:
    """Export executive summary reports in Markdown, TXT, and CSV formats."""
    ensure_directories()
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    selected = [fmt.lower() for fmt in (formats or ["md", "txt", "csv"])]
    exported: Dict[str, Path] = {}

    if "md" in selected:
        md_path = output_dir / f"{prefix}.md"
        md_path.write_text(
            build_executive_summary_text(report, chart_paths=chart_paths, markdown=True),
            encoding="utf-8",
        )
        exported["md"] = md_path

    if "txt" in selected:
        txt_path = output_dir / f"{prefix}.txt"
        txt_path.write_text(
            build_executive_summary_text(report, chart_paths=chart_paths, markdown=False),
            encoding="utf-8",
        )
        exported["txt"] = txt_path

    if "csv" in selected:
        csv_path = output_dir / f"{prefix}_summary.csv"
        with csv_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(["Section", "Metric", "Value", "Details"])
            writer.writerow(["Metadata", "Project", APP_NAME, f"{PROJECT_NUMBER} - {CHALLENGE_NAME}"])
            writer.writerow(["Metadata", "Generated At", datetime.now().isoformat(timespec="seconds"), ""])
            writer.writerow(["Metadata", "Total Responses", report.total_responses, f"{report.date_range[0]} to {report.date_range[1]}"])

            if not report.is_empty:
                stat_rows = [
                    ("Sleep Duration (hrs)", report.sleep_stats),
                    ("Physical Activity (min)", report.activity_stats),
                    ("Stress Level (1-10)", report.stress_stats),
                    ("Mood Rating (1-10)", report.mood_stats),
                    ("General Wellness (1-10)", report.wellness_stats),
                ]
                for label, st in stat_rows:
                    writer.writerow([
                        "Statistics",
                        label,
                        st.average,
                        f"median={st.median_value}; min={st.minimum}; max={st.maximum}",
                    ])

                for dist_name, dist in [
                    ("Wellness Tier", report.wellness_distribution),
                    ("Stress Tier", report.stress_distribution),
                    ("Sleep Tier", report.sleep_distribution),
                    ("Activity Tier", report.activity_distribution),
                ]:
                    if dist:
                        for cat, cnt in dist.counts.items():
                            writer.writerow([
                                "Distribution",
                                f"{dist_name}: {cat}",
                                cnt,
                                f"{dist.percentages.get(cat, 0.0)}%",
                            ])

                for pt in report.trends:
                    writer.writerow([
                        "Daily Trend",
                        pt.survey_date,
                        pt.avg_wellness,
                        f"n={pt.count}; sleep={pt.avg_sleep}; activity={pt.avg_activity}; stress={pt.avg_stress}; mood={pt.avg_mood}",
                    ])

                for warn in report.threshold_warnings:
                    writer.writerow(["Statistical Warning", "Threshold Flag", warn, MEDICAL_DISCLAIMER])

        exported["csv"] = csv_path

    return exported
