"""High-level SurveyManager coordinating storage, validation, analytics,
search, charts, and executive reporting.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from config import (
    CHARTS_DIR,
    REPORTS_DIR,
    RESPONSES_CSV_PATH,
    RESPONSES_JSON_PATH,
    SAMPLE_CSV_PATH,
    configure_logging,
)
from core.analytics import AnalyticsReport, compute_analytics
from core.models import SurveyRecord
from core.report_generator import build_executive_summary_text, export_reports
from core.search import FilterCriteria, filter_records, search_by_record_id
from core.storage import ImportSummary, StorageLoadResult, SurveyStorage
from core.validation import detect_record_warnings, validate_record_payload
from visualization.charts import ChartGenerationResult, generate_all_charts

logger = logging.getLogger("wellness_visualizer.manager")


class SurveyManager:
    """Application service layer managing anonymous wellness survey records."""

    def __init__(
        self,
        csv_path: Path = RESPONSES_CSV_PATH,
        json_path: Path = RESPONSES_JSON_PATH,
        charts_dir: Path = CHARTS_DIR,
        reports_dir: Path = REPORTS_DIR,
    ) -> None:
        configure_logging()
        self.storage = SurveyStorage(csv_path=csv_path, json_path=json_path)
        self.charts_dir = Path(charts_dir)
        self.reports_dir = Path(reports_dir)
        self.load_result: StorageLoadResult = self.storage.load_records()
        self.records: List[SurveyRecord] = self.load_result.records
        self.startup_warnings: List[str] = list(self.load_result.warnings)

    def reload(self) -> None:
        """Reload records from local CSV/JSON storage."""
        self.load_result = self.storage.load_records()
        self.records = self.load_result.records
        self.startup_warnings = list(self.load_result.warnings)

    def add_response(
        self,
        payload: Dict[str, Any],
        allow_auto_id: bool = True,
        allow_today_default: bool = True,
    ) -> Tuple[Optional[SurveyRecord], List[str], List[str]]:
        """Validate, check duplicates, save immediately, and return (record, errors, warnings)."""
        record, errors = validate_record_payload(
            payload,
            allow_auto_id=allow_auto_id,
            allow_today_default=allow_today_default,
        )
        if record is None:
            return None, errors, []

        if any(existing.record_id == record.record_id for existing in self.records):
            return (
                None,
                [f"Duplicate record_id '{record.record_id}' already exists in storage."],
                [],
            )

        self.records.append(record)
        self.storage.save_all(self.records)
        warnings = detect_record_warnings(record)
        logger.info("Added anonymous survey record %s (%s).", record.record_id, record.survey_date)
        return record, [], warnings

    def delete_record(self, record_id: str) -> bool:
        """Delete a record by ID and persist immediately."""
        target = record_id.strip().upper()
        remaining = [rec for rec in self.records if rec.record_id.upper() != target]
        if len(remaining) == len(self.records):
            return False
        self.records = remaining
        self.storage.save_all(self.records)
        logger.info("Deleted survey record %s.", target)
        return True

    def clear_all_records(self) -> int:
        """Remove all stored survey records after confirmation."""
        count = len(self.records)
        self.records = []
        self.storage.save_all(self.records)
        logger.warning("Cleared %d survey record(s) from local storage.", count)
        return count

    def get_all_records(self, newest_first: bool = True) -> List[SurveyRecord]:
        """Return stored records sorted by survey date and record ID."""
        return sorted(
            self.records,
            key=lambda rec: (rec.survey_date, rec.record_id),
            reverse=newest_first,
        )

    def search_records(self, record_id_query: str, exact: bool = False) -> List[SurveyRecord]:
        """Search records by anonymous Record ID."""
        return search_by_record_id(self.records, record_id_query, exact=exact)

    def filter_records(self, criteria: FilterCriteria) -> List[SurveyRecord]:
        """Filter records against multi-field criteria."""
        return filter_records(self.records, criteria)

    def get_analytics(self) -> AnalyticsReport:
        """Compute analytics on the current dataset."""
        return compute_analytics(self.records, storage_warnings=self.startup_warnings)

    def import_csv(self, csv_path: Path, default_origin: str = "csv_import") -> ImportSummary:
        """Bulk-import validated rows from a CSV dataset and save immediately."""
        imported, summary = self.storage.import_csv_dataset(
            source_csv_path=csv_path,
            existing_records=self.records,
            default_origin=default_origin,
        )
        if imported:
            self.records.extend(imported)
            self.storage.save_all(self.records)
        return summary

    def load_sample_dataset(self, sample_path: Path = SAMPLE_CSV_PATH) -> ImportSummary:
        """Load the 40 synthetic demonstration records into local storage."""
        return self.import_csv(sample_path, default_origin="synthetic_demo")

    def generate_charts(self) -> ChartGenerationResult:
        """Generate all 6 PNG visualizations into reports/charts/."""
        analytics = self.get_analytics()
        return generate_all_charts(
            self.records,
            output_dir=self.charts_dir,
            report=analytics,
        )

    def get_executive_summary(self, markdown: bool = False) -> str:
        """Build formatted executive summary string."""
        analytics = self.get_analytics()
        chart_paths = sorted(self.charts_dir.glob("*.png")) if self.charts_dir.exists() else []
        return build_executive_summary_text(
            analytics,
            chart_paths=chart_paths or None,
            markdown=markdown,
        )

    def export_executive_reports(
        self,
        formats: Optional[List[str]] = None,
        prefix: str = "executive_wellness_report",
    ) -> Dict[str, Path]:
        """Export executive summary reports in Markdown, TXT, and CSV."""
        analytics = self.get_analytics()
        chart_paths = sorted(self.charts_dir.glob("*.png")) if self.charts_dir.exists() else []
        return export_reports(
            analytics,
            output_dir=self.reports_dir,
            chart_paths=chart_paths or None,
            formats=formats,
            prefix=prefix,
        )
