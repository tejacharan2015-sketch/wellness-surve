"""Search and multi-criteria filtering capabilities for anonymous survey records."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

from core.models import SurveyRecord


@dataclass
class FilterCriteria:
    """Optional filter parameters for querying survey responses."""

    survey_date: Optional[str] = None
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    wellness_category: Optional[str] = None
    stress_category: Optional[str] = None
    min_sleep: Optional[float] = None
    max_sleep: Optional[float] = None
    activity_category: Optional[str] = None
    age_group: Optional[str] = None


def search_by_record_id(
    records: List[SurveyRecord],
    query: str,
    exact: bool = False,
) -> List[SurveyRecord]:
    """Search survey records by anonymous Record ID (exact or substring match)."""
    cleaned = (query or "").strip().upper()
    if not cleaned:
        return []

    if exact:
        return [rec for rec in records if rec.record_id.upper() == cleaned]
    return [rec for rec in records if cleaned in rec.record_id.upper()]


def filter_records(
    records: List[SurveyRecord],
    criteria: FilterCriteria,
) -> List[SurveyRecord]:
    """Filter survey records against one or more optional criteria."""
    results: List[SurveyRecord] = []

    for rec in records:
        if criteria.survey_date and rec.survey_date != criteria.survey_date:
            continue
        if criteria.start_date and rec.survey_date < criteria.start_date:
            continue
        if criteria.end_date and rec.survey_date > criteria.end_date:
            continue
        if (
            criteria.wellness_category
            and rec.wellness_category.lower() != criteria.wellness_category.strip().lower()
        ):
            continue
        if (
            criteria.stress_category
            and rec.stress_category.lower() != criteria.stress_category.strip().lower()
        ):
            continue
        if criteria.min_sleep is not None and rec.sleep_duration < criteria.min_sleep:
            continue
        if criteria.max_sleep is not None and rec.sleep_duration > criteria.max_sleep:
            continue
        if criteria.activity_category:
            target = criteria.activity_category.strip().lower()
            cat_lower = rec.activity_category.lower()
            if target not in cat_lower and not cat_lower.startswith(target):
                continue
        if (
            criteria.age_group
            and rec.age_group.lower() != criteria.age_group.strip().lower()
        ):
            continue

        results.append(rec)

    return sorted(results, key=lambda r: (r.survey_date, r.record_id), reverse=True)
