"""Integration tests for executive report exports and PNG chart generation."""

from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core.analytics import compute_analytics
from core.models import SurveyRecord
from core.report_generator import export_reports
from visualization.charts import generate_all_charts


class TestReportsAndCharts(unittest.TestCase):
    def setUp(self) -> None:
        self.records = [
            SurveyRecord("CH-001", "2026-11-01", "18-24", 6.5, 30, 6, 6, 6),
            SurveyRecord("CH-002", "2026-11-02", "25-34", 8.0, 60, 3, 8, 9),
            SurveyRecord("CH-003", "2026-11-03", "35-44", 5.0, 15, 8, 4, 4),
        ]

    def test_generate_all_six_charts_produces_valid_pngs(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            res = generate_all_charts(self.records, output_dir=Path(tmpdir))
            self.assertEqual(len(res.generated_files), 6)
            for path in res.generated_files:
                self.assertTrue(path.exists())
                header = path.read_bytes()[:8]
                self.assertEqual(header, b"\x89PNG\r\n\x1a\n")

    def test_export_reports_md_txt_csv(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            report = compute_analytics(self.records)
            exported = export_reports(report, output_dir=Path(tmpdir))
            self.assertEqual(set(exported.keys()), {"md", "txt", "csv"})
            for path in exported.values():
                self.assertTrue(path.exists())
                self.assertGreater(path.stat().st_size, 100)


if __name__ == "__main__":
    unittest.main()
