"""Unit tests for search by Record ID and multi-criteria filtering."""

from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core.models import SurveyRecord
from core.search import FilterCriteria, filter_records, search_by_record_id


class TestSearchAndFilter(unittest.TestCase):
    def setUp(self) -> None:
        self.records = [
            SurveyRecord("WSV-1001", "2026-11-01", "18-24", 5.5, 15, 8, 4, 4),
            SurveyRecord("WSV-1002", "2026-11-02", "25-34", 7.5, 45, 4, 8, 8),
            SurveyRecord("SYN-2001", "2026-11-03", "35-44", 8.5, 75, 2, 9, 9),
        ]

    def test_search_by_record_id_partial_and_exact(self) -> None:
        partial = search_by_record_id(self.records, "wsv-")
        self.assertEqual(len(partial), 2)
        exact = search_by_record_id(self.records, "WSV-1002", exact=True)
        self.assertEqual(len(exact), 1)
        self.assertEqual(exact[0].record_id, "WSV-1002")

    def test_filter_by_multiple_criteria(self) -> None:
        high_well = filter_records(self.records, FilterCriteria(wellness_category="High"))
        self.assertEqual(len(high_well), 2)

        high_stress = filter_records(self.records, FilterCriteria(stress_category="High"))
        self.assertEqual(len(high_stress), 1)
        self.assertEqual(high_stress[0].record_id, "WSV-1001")

        sleep_range = filter_records(self.records, FilterCriteria(min_sleep=7.0, max_sleep=8.0))
        self.assertEqual(len(sleep_range), 1)
        self.assertEqual(sleep_range[0].record_id, "WSV-1002")

        active_only = filter_records(self.records, FilterCriteria(activity_category="Active"))
        self.assertEqual(len(active_only), 1)
        self.assertEqual(active_only[0].record_id, "SYN-2001")

        by_date = filter_records(self.records, FilterCriteria(survey_date="2026-11-01"))
        self.assertEqual(len(by_date), 1)


if __name__ == "__main__":
    unittest.main()
