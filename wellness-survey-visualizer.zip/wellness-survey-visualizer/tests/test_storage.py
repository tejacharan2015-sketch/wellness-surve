"""Unit tests for CSV/JSON persistence, corrupted file recovery, duplicate detection, and bulk CSV import."""

from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core.models import SurveyRecord
from core.storage import SurveyStorage


class TestStorage(unittest.TestCase):
    def test_csv_and_json_roundtrip_and_missing_init(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            base = Path(tmpdir)
            csv_path = base / "responses.csv"
            json_path = base / "responses.json"
            log_path = base / "import.log"

            storage = SurveyStorage(csv_path=csv_path, json_path=json_path, import_log_path=log_path)
            initial = storage.load_records()
            self.assertEqual(initial.records, [])
            self.assertTrue(csv_path.exists())
            self.assertTrue(json_path.exists())

            sample = [
                SurveyRecord("STO-0001", "2026-11-01", "25-34", 7.5, 45, 4, 8, 8),
                SurveyRecord("STO-0002", "2026-11-02", "35-44", 6.0, 20, 7, 5, 5),
            ]
            storage.save_all(sample)

            reloaded = SurveyStorage(csv_path=csv_path, json_path=json_path, import_log_path=log_path).load_records()
            self.assertEqual(len(reloaded.records), 2)
            self.assertEqual(reloaded.records[0].record_id, "STO-0001")

    def test_corrupted_json_recovers_from_csv(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            base = Path(tmpdir)
            csv_path = base / "responses.csv"
            json_path = base / "responses.json"
            log_path = base / "import.log"

            storage = SurveyStorage(csv_path=csv_path, json_path=json_path, import_log_path=log_path)
            storage.save_all([SurveyRecord("REC-1001", "2026-11-05", "18-24", 8.0, 50, 3, 8, 8)])

            # Corrupt JSON deliberately
            json_path.write_text("{corrupt json!!!", encoding="utf-8")

            res = storage.load_records()
            self.assertTrue(res.recovered_from_backup)
            self.assertEqual(len(res.records), 1)
            self.assertEqual(res.records[0].record_id, "REC-1001")
            backups = list(base.glob("*corrupt*.json"))
            self.assertEqual(len(backups), 1)

    def test_bulk_csv_import_validation_and_duplicates(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            base = Path(tmpdir)
            storage = SurveyStorage(
                csv_path=base / "responses.csv",
                json_path=base / "responses.json",
                import_log_path=base / "import.log",
            )
            existing = [SurveyRecord("DUP-0001", "2026-11-01", "25-34", 7.0, 30, 5, 7, 7)]

            import_file = base / "bulk.csv"
            import_file.write_text(
                "\n".join([
                    "record_id,survey_date,age_group,sleep_duration,physical_activity,stress_level,mood_rating,general_wellness",
                    "IMP-0001,2026-11-02,18-24,7.5,45,4,8,8",
                    "DUP-0001,2026-11-02,25-34,7.0,30,5,7,7",  # duplicate
                    "BAD-0001,2026-11-02,18-24,30.0,45,4,8,8",  # invalid sleep > 24
                    "BAD-0002,not-a-date,18-24,7.0,45,4,8,8",  # invalid date
                ]),
                encoding="utf-8",
            )

            imported, summary = storage.import_csv_dataset(import_file, existing)
            self.assertEqual(summary.total_rows, 4)
            self.assertEqual(summary.imported_count, 1)
            self.assertEqual(summary.duplicate_count, 1)
            self.assertEqual(summary.invalid_count, 2)
            self.assertEqual(len(imported), 1)
            self.assertEqual(imported[0].record_id, "IMP-0001")
            self.assertTrue((base / "import.log").exists())

    def test_malformed_csv_storage_lines_skipped_safely(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            base = Path(tmpdir)
            csv_path = base / "responses.csv"
            json_path = base / "responses.json"
            json_path.write_text("", encoding="utf-8")
            csv_path.write_text(
                "\n".join([
                    "record_id,survey_date,age_group,sleep_duration,physical_activity,stress_level,mood_rating,general_wellness,data_origin",
                    "OK-0001,2026-11-01,25-34,7.5,40,4,8,8,user_entry",
                    "BAD-ROW,2026-11-01,25-34,-5.0,40,4,8,8,user_entry",
                ]),
                encoding="utf-8",
            )
            storage = SurveyStorage(csv_path=csv_path, json_path=json_path, import_log_path=base / "import.log")
            res = storage.load_records()
            self.assertEqual(len(res.records), 1)
            self.assertEqual(res.skipped_rows, 1)


if __name__ == "__main__":
    unittest.main()
