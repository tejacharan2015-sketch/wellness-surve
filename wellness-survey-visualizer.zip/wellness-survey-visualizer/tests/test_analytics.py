"""Unit tests for the analytics engine including empty datasets and trend deltas."""

from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core.analytics import compute_analytics
from core.models import SurveyRecord


class TestAnalytics(unittest.TestCase):
    def test_empty_dataset_handled_gracefully(self) -> None:
        report = compute_analytics([])
        self.assertTrue(report.is_empty)
        self.assertEqual(report.total_responses, 0)
        self.assertIsNone(report.wellness_stats)
        self.assertTrue(len(report.threshold_warnings) >= 1)

    def test_analytics_calculations_and_trends(self) -> None:
        records = [
            SurveyRecord("REC-01", "2026-10-01", "18-24", 6.0, 20, 8, 4, 4),
            SurveyRecord("REC-02", "2026-10-01", "25-34", 7.0, 40, 6, 6, 6),
            SurveyRecord("REC-03", "2026-10-10", "35-44", 8.0, 60, 2, 9, 9),
            SurveyRecord("REC-04", "2026-10-10", "45-54", 9.0, 80, 2, 9, 9),
        ]
        report = compute_analytics(records)
        self.assertFalse(report.is_empty)
        self.assertEqual(report.total_responses, 4)
        self.assertEqual(report.sleep_stats.average, 7.5)
        self.assertEqual(report.activity_stats.average, 50.0)
        self.assertEqual(report.stress_stats.average, 4.5)
        self.assertEqual(report.mood_stats.average, 7.0)
        self.assertEqual(report.wellness_stats.average, 7.0)
        self.assertEqual(report.date_range, ("2026-10-01", "2026-10-10"))
        self.assertEqual(report.wellness_distribution.counts["Low"], 1)
        self.assertEqual(report.wellness_distribution.counts["Moderate"], 1)
        self.assertEqual(report.wellness_distribution.counts["High"], 2)
        self.assertEqual(report.wellness_trend_delta, 4.0)
        self.assertEqual(report.stress_trend_delta, -5.0)
        self.assertEqual(report.highest_wellness_day, ("2026-10-10", 9.0))
        self.assertEqual(report.lowest_wellness_day, ("2026-10-01", 5.0))


if __name__ == "__main__":
    unittest.main()
