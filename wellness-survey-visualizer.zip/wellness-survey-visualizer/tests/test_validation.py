"""Unit tests for defensive input validation, boundary conditions, and threshold warnings."""

from datetime import date, timedelta
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core.validation import (
    ValidationError,
    detect_record_warnings,
    validate_age_group,
    validate_physical_activity,
    validate_record_id,
    validate_record_payload,
    validate_scale_rating,
    validate_sleep_duration,
    validate_survey_date,
)


class TestValidation(unittest.TestCase):
    def test_valid_boundary_sleep_values(self) -> None:
        self.assertEqual(validate_sleep_duration("0"), 0.0)
        self.assertEqual(validate_sleep_duration("24"), 24.0)
        self.assertEqual(validate_sleep_duration("7.556"), 7.56)

    def test_invalid_sleep_values_raise(self) -> None:
        for bad in ("", "   ", "-1", "24.1", "abc", "nan", None, True):
            with self.assertRaises(ValidationError):
                validate_sleep_duration(bad)

    def test_valid_and_invalid_physical_activity(self) -> None:
        self.assertEqual(validate_physical_activity("0"), 0)
        self.assertEqual(validate_physical_activity("600"), 600)
        for bad in ("", "-5", "601", "30.5", "forty", None):
            with self.assertRaises(ValidationError):
                validate_physical_activity(bad)

    def test_valid_and_invalid_scale_ratings(self) -> None:
        self.assertEqual(validate_scale_rating("1", "Stress Level"), 1)
        self.assertEqual(validate_scale_rating("10", "Stress Level"), 10)
        for bad in ("0", "11", "5.5", "", "high", None):
            with self.assertRaises(ValidationError):
                validate_scale_rating(bad, "Stress Level")

    def test_survey_date_validation(self) -> None:
        today = date.today().isoformat()
        self.assertEqual(validate_survey_date(today), today)
        tomorrow = (date.today() + timedelta(days=1)).isoformat()
        for bad in ("", "2026/11/24", "2026-02-30", "1999-01-01", tomorrow):
            with self.assertRaises(ValidationError):
                validate_survey_date(bad)

    def test_age_group_optional_and_validated(self) -> None:
        self.assertEqual(validate_age_group(""), "Prefer not to say")
        self.assertEqual(validate_age_group("25-34"), "25-34")
        with self.assertRaises(ValidationError):
            validate_age_group("invalid-bracket")

    def test_pii_rejected_in_record_id(self) -> None:
        with self.assertRaises(ValidationError):
            validate_record_id("user@example.com", allow_auto=False)
        with self.assertRaises(ValidationError):
            validate_record_id("555-123-4567", allow_auto=False)

    def test_full_payload_validation_and_warnings(self) -> None:
        record, errs = validate_record_payload(
            {
                "record_id": "TST-0001",
                "survey_date": "2026-10-15",
                "age_group": "18-24",
                "sleep_duration": 3.5,
                "physical_activity": 320,
                "stress_level": 9,
                "mood_rating": 2,
                "general_wellness": 3,
            }
        )
        self.assertEqual(errs, [])
        self.assertIsNotNone(record)
        assert record is not None
        warnings = detect_record_warnings(record)
        self.assertGreaterEqual(len(warnings), 4)

    def test_malformed_payload_rejected(self) -> None:
        record, errs = validate_record_payload("not-a-dict")  # type: ignore[arg-type]
        self.assertIsNone(record)
        self.assertTrue(len(errs) > 0)


if __name__ == "__main__":
    unittest.main()
