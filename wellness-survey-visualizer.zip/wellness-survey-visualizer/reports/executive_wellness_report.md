# WELLNESS SURVEY VISUALIZER — Executive Wellness Summary

- **Project**: #40 | Health & Wellbeing | LocalImpact Challenge
- **Version**: 1.0.0
- **Report Generated**: 2026-11-24 12:10:30
- **Total Anonymous Responses**: 41
- **Survey Date Span**: 2026-10-15 to 2026-11-24

> Anonymous Offline Survey Tool: No names, emails, phone numbers, or personally identifying information (PII) are collected or stored.
> Statistical Notice: Survey metrics and threshold warnings reflect self-reported aggregated patterns only and do not constitute medical advice or clinical diagnosis.

## 1. Key Summary Statistics
| Metric | Average | Median | Minimum | Maximum |
|---|---:|---:|---:|---:|
| Sleep Duration (hrs) | 7.46 | 7.5 | 0.0 | 24.0 |
| Physical Activity (min/day) | 60.71 | 45.0 | 0 | 600 |
| Stress Level (1-10) | 4.56 | 4.0 | 1 | 10 |
| Mood Rating (1-10) | 6.93 | 8.0 | 1 | 10 |
| General Wellness (1-10) | 7.07 | 8.0 | 1 | 10 |

- Highest 1-10 scale average: General Wellness (7.07/10)
- Lowest 1-10 scale average: Stress Level (4.56/10)
- Peak wellness date: 2026-10-25 (10.0/10)
- Lowest wellness date: 2026-11-11 (3.0/10)

## 2. Category Distributions
Overall Wellness Tiers:
- Low: 6 (14.6%)
- Moderate: 13 (31.7%)
- High: 22 (53.7%)
Stress Level Tiers:
- Low: 16 (39.0%)
- Moderate: 16 (39.0%)
- High: 9 (22.0%)
Sleep Duration Tiers:
- Short (<6h): 6 (14.6%)
- Moderate (6-6.9h): 8 (19.5%)
- Optimal (7-9h): 24 (58.5%)
- Extended (>9h): 3 (7.3%)
Physical Activity Tiers:
- Sedentary (<30m): 10 (24.4%)
- Moderate (30-59m): 18 (43.9%)
- Active (60m+): 13 (31.7%)
Age Group Breakdown:
- 18-24: 9 (22.0%)
- 25-34: 10 (24.4%)
- 35-44: 7 (17.1%)
- 45-54: 6 (14.6%)
- 55+: 5 (12.2%)
- Prefer not to say: 4 (9.8%)

## 3. Chronological Trends Across Survey Dates
- Net Wellness Trend Delta (early vs. recent half): +0.67 pts
- Net Stress Trend Delta (early vs. recent half): -0.54 pts

| Date | Responses | Avg Sleep (h) | Avg Activity (m) | Avg Stress | Avg Mood | Avg Wellness |
|---|---:|---:|---:|---:|---:|---:|
| 2026-10-15 | 2 | 7.0 | 42.5 | 5.0 | 7.0 | 7.0 |
| 2026-10-16 | 2 | 6.5 | 37.5 | 5.5 | 6.0 | 6.5 |
| 2026-10-17 | 1 | 7.0 | 40.0 | 4.0 | 7.0 | 7.0 |
| 2026-10-18 | 2 | 6.25 | 42.5 | 5.5 | 6.0 | 6.0 |
| 2026-10-19 | 1 | 6.0 | 25.0 | 7.0 | 5.0 | 5.0 |
| 2026-10-20 | 2 | 3.6 | 22.5 | 7.5 | 4.0 | 4.0 |
| 2026-10-21 | 1 | 7.8 | 55.0 | 3.0 | 8.0 | 8.0 |
| 2026-10-22 | 1 | 6.8 | 30.0 | 6.0 | 6.0 | 6.0 |
| 2026-10-23 | 1 | 8.2 | 65.0 | 2.0 | 9.0 | 9.0 |
| 2026-10-24 | 1 | 5.5 | 20.0 | 8.0 | 4.0 | 4.0 |
| 2026-10-25 | 1 | 9.5 | 90.0 | 2.0 | 9.0 | 10.0 |
| 2026-10-26 | 1 | 6.2 | 28.0 | 7.0 | 5.0 | 5.0 |
| 2026-10-27 | 1 | 7.5 | 45.0 | 4.0 | 7.0 | 7.0 |
| 2026-10-28 | 1 | 10.5 | 120.0 | 3.0 | 8.0 | 8.0 |
| 2026-10-29 | 1 | 6.0 | 15.0 | 7.0 | 5.0 | 5.0 |
| 2026-10-30 | 1 | 24.0 | 600.0 | 1.0 | 10.0 | 10.0 |
| 2026-11-01 | 1 | 7.4 | 42.0 | 4.0 | 7.0 | 8.0 |
| 2026-11-02 | 1 | 7.9 | 50.0 | 3.0 | 8.0 | 8.0 |
| 2026-11-03 | 1 | 5.2 | 18.0 | 8.0 | 4.0 | 4.0 |
| 2026-11-04 | 1 | 7.6 | 60.0 | 4.0 | 8.0 | 8.0 |
| 2026-11-05 | 1 | 6.9 | 35.0 | 5.0 | 7.0 | 7.0 |
| 2026-11-06 | 1 | 8.1 | 70.0 | 3.0 | 9.0 | 9.0 |
| 2026-11-07 | 1 | 6.4 | 22.0 | 6.0 | 6.0 | 6.0 |
| 2026-11-08 | 1 | 7.0 | 45.0 | 5.0 | 7.0 | 7.0 |
| 2026-11-09 | 1 | 8.3 | 80.0 | 2.0 | 9.0 | 9.0 |
| 2026-11-10 | 1 | 7.5 | 38.0 | 3.0 | 8.0 | 8.0 |
| 2026-11-11 | 1 | 4.5 | 5.0 | 9.0 | 2.0 | 3.0 |
| 2026-11-12 | 1 | 7.8 | 52.0 | 4.0 | 8.0 | 8.0 |
| 2026-11-13 | 1 | 8.0 | 65.0 | 3.0 | 8.0 | 9.0 |
| 2026-11-14 | 1 | 7.1 | 40.0 | 5.0 | 7.0 | 7.0 |
| 2026-11-15 | 1 | 8.4 | 95.0 | 2.0 | 9.0 | 9.0 |
| 2026-11-16 | 1 | 6.7 | 30.0 | 5.0 | 6.0 | 7.0 |
| 2026-11-17 | 1 | 7.6 | 48.0 | 3.0 | 8.0 | 8.0 |
| 2026-11-18 | 1 | 8.8 | 110.0 | 2.0 | 9.0 | 9.0 |
| 2026-11-19 | 1 | 7.3 | 44.0 | 4.0 | 8.0 | 8.0 |
| 2026-11-20 | 1 | 8.2 | 72.0 | 2.0 | 9.0 | 9.0 |
| 2026-11-24 | 1 | 7.5 | 45.0 | 4.0 | 8.0 | 8.0 |

## 4. Analytical Observations
- Across 41 anonymous responses, overall wellness averages 7.07/10 (53.7% High tier, 14.6% Low tier).
- Mean sleep duration is 7.46 hours (median 7.5h), falling within the 7-9 hour optimal band.
- Self-reported stress averages 4.56/10 with 22.0% of respondents in the High stress tier (7-10).
- Physical activity averages 60.71 minutes/day (range 0-600 min), alongside an average mood score of 6.93/10.
- Chronological comparison shows an improving wellness trajectory (+0.67 pts) alongside a -0.54 pt change in stress.

## 5. Threshold Warning Indicators (Non-Diagnostic)
- Statistical flag (SYN-0003): Elevated self-reported stress (8/10).
- Statistical flag (SYN-0006): Very short sleep reported (4.0h <= 4.0h).
- Statistical flag (SYN-0006): Elevated self-reported stress (9/10).
- Statistical flag (SYN-0006): Low self-reported wellness score (3/10).
- Statistical flag (SYN-0006): Low self-reported mood rating (3/10).
- Statistical flag (SYN-0010): Very short sleep reported (0.0h <= 4.0h).
- Statistical flag (SYN-0010): Elevated self-reported stress (10/10).
- Statistical flag (SYN-0010): Low self-reported wellness score (1/10).
- Statistical flag (SYN-0010): Low self-reported mood rating (1/10).
- Statistical flag (SYN-0014): Elevated self-reported stress (8/10).
- Statistical flag (SYN-0020): Unusually long sleep reported (24.0h >= 14.0h).
- Statistical flag (SYN-0020): High activity outlier (600 min >= 300 min).
- Statistical flag (SYN-0023): Elevated self-reported stress (8/10).
- Statistical flag (SYN-0031): Elevated self-reported stress (9/10).
- Statistical flag (SYN-0031): Low self-reported wellness score (3/10).
- Statistical flag (SYN-0031): Low self-reported mood rating (2/10).

## 6. Generated Visualization References
- 01_sleep_duration_distribution.png (/app/applet/wellness-survey-visualizer/reports/charts/01_sleep_duration_distribution.png)
- 02_stress_level_distribution.png (/app/applet/wellness-survey-visualizer/reports/charts/02_stress_level_distribution.png)
- 03_mood_distribution.png (/app/applet/wellness-survey-visualizer/reports/charts/03_mood_distribution.png)
- 04_physical_activity_distribution.png (/app/applet/wellness-survey-visualizer/reports/charts/04_physical_activity_distribution.png)
- 05_overall_wellness_distribution.png (/app/applet/wellness-survey-visualizer/reports/charts/05_overall_wellness_distribution.png)
- 06_wellness_trends_over_time.png (/app/applet/wellness-survey-visualizer/reports/charts/06_wellness_trends_over_time.png)
