"""Visualization package for Wellness Survey Visualizer."""
