"""Terminal analytics dashboard renderer with ASCII/Unicode bar indicators."""

from __future__ import annotations

from typing import Dict, List

from config import APP_NAME, MEDICAL_DISCLAIMER
from core.analytics import AnalyticsReport


def _bar(percentage: float, width: int = 24) -> str:
    """Render a proportional horizontal progress bar."""
    filled = int(round((max(0.0, min(100.0, percentage)) / 100.0) * width))
    return "#" * filled + "-" * (width - filled)


def _render_distribution_block(title: str, counts: Dict[str, int], percentages: Dict[str, float]) -> List[str]:
    """Format a category distribution table with visual bars."""
    lines: List[str] = [f"  {title}"]
    lines.append("  " + "-" * 66)
    for label, count in counts.items():
        pct = percentages.get(label, 0.0)
        bar = _bar(pct, width=22)
        lines.append(f"  {label:<20} | {bar} | {count:>4} ({pct:>5.1f}%)")
    lines.append("")
    return lines


def render_dashboard_text(report: AnalyticsReport) -> str:
    """Build a structured terminal dashboard string from computed analytics."""
    border = "=" * 72
    lines: List[str] = [
        border,
        f"  {APP_NAME} — ANALYTICS DASHBOARD",
        border,
    ]

    if report.is_empty:
        lines.extend([
            "  No survey responses found in local storage.",
            "  Use 'Add New Survey Response' or 'Import CSV Dataset' to load data.",
            "",
            f"  Notice: {MEDICAL_DISCLAIMER}",
            border,
        ])
        return "\n".join(lines)

    lines.append(
        f"  Total Responses : {report.total_responses:<10}   Survey Window : {report.date_range[0]} .. {report.date_range[1]}"
    )
    lines.append("-" * 72)
    lines.append("  KEY METRIC AVERAGES (Actual Stored Records)")
    lines.append("-" * 72)
    lines.append(
        f"  General Wellness : {report.wellness_stats.average:>5}/10  (med {report.wellness_stats.median_value}, range {int(report.wellness_stats.minimum)}-{int(report.wellness_stats.maximum)})"
    )
    lines.append(
        f"  Sleep Duration   : {report.sleep_stats.average:>5} h   (med {report.sleep_stats.median_value}h, range {report.sleep_stats.minimum}-{report.sleep_stats.maximum}h)"
    )
    lines.append(
        f"  Stress Level     : {report.stress_stats.average:>5}/10  (med {report.stress_stats.median_value}, range {int(report.stress_stats.minimum)}-{int(report.stress_stats.maximum)})"
    )
    lines.append(
        f"  Mood Rating      : {report.mood_stats.average:>5}/10  (med {report.mood_stats.median_value}, range {int(report.mood_stats.minimum)}-{int(report.mood_stats.maximum)})"
    )
    lines.append(
        f"  Physical Activity: {report.activity_stats.average:>5} m   (med {report.activity_stats.median_value}m, range {int(report.activity_stats.minimum)}-{int(report.activity_stats.maximum)}m)"
    )
    lines.append("")

    if report.wellness_distribution:
        lines.extend(
            _render_distribution_block(
                "WELLNESS CATEGORY DISTRIBUTION",
                report.wellness_distribution.counts,
                report.wellness_distribution.percentages,
            )
        )
    if report.stress_distribution:
        lines.extend(
            _render_distribution_block(
                "STRESS CATEGORY DISTRIBUTION",
                report.stress_distribution.counts,
                report.stress_distribution.percentages,
            )
        )
    if report.sleep_distribution:
        lines.extend(
            _render_distribution_block(
                "SLEEP DURATION DISTRIBUTION",
                report.sleep_distribution.counts,
                report.sleep_distribution.percentages,
            )
        )
    if report.activity_distribution:
        lines.extend(
            _render_distribution_block(
                "ACTIVITY LEVEL DISTRIBUTION",
                report.activity_distribution.counts,
                report.activity_distribution.percentages,
            )
        )

    lines.append("  CHRONOLOGICAL TRENDS (Recent Dates)")
    lines.append("  " + "-" * 66)
    lines.append("  Date         |  n | Sleep(h) | Act(m) | Stress | Mood | Wellness")
    lines.append("  " + "-" * 66)
    for pt in report.trends[-10:]:
        lines.append(
            f"  {pt.survey_date}   | {pt.count:>2} | {pt.avg_sleep:>8.2f} | {pt.avg_activity:>6.1f} | {pt.avg_stress:>6.2f} | {pt.avg_mood:>4.2f} | {pt.avg_wellness:>8.2f}"
        )
    lines.append("")
    lines.append(
        f"  Trend Deltas (early vs recent): Wellness {report.wellness_trend_delta:+.2f} pts | Stress {report.stress_trend_delta:+.2f} pts"
    )

    if report.highest_wellness_day and report.lowest_wellness_day:
        lines.append(
            f"  Highest Wellness Day: {report.highest_wellness_day[0]} ({report.highest_wellness_day[1]}/10) | "
            f"Lowest: {report.lowest_wellness_day[0]} ({report.lowest_wellness_day[1]}/10)"
        )
    lines.append("")

    lines.append("  THRESHOLD WARNINGS (Non-Diagnostic Statistical Flags)")
    lines.append("  " + "-" * 66)
    if report.threshold_warnings:
        for warn in report.threshold_warnings[:8]:
            lines.append(f"  [!] {warn}")
        if len(report.threshold_warnings) > 8:
            lines.append(f"  ... and {len(report.threshold_warnings) - 8} more warning(s) in report export.")
    else:
        lines.append("  No anomalous statistical threshold warnings detected.")
    lines.append("")
    lines.append(f"  {MEDICAL_DISCLAIMER}")
    lines.append(border)

    return "\n".join(lines)
