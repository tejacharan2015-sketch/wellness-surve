"""Chart generation using Matplotlib with a pure-Python PNG fallback
for environments without external plotting packages installed.
"""

from __future__ import annotations

from dataclasses import dataclass
import logging
from pathlib import Path
import struct
from typing import Dict, List, Optional, Sequence, Tuple
import zlib

from config import CHARTS_DIR, ensure_directories
from core.analytics import AnalyticsReport, compute_analytics
from core.models import SurveyRecord

logger = logging.getLogger("wellness_visualizer.charts")

try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    HAS_MATPLOTLIB = True
except ImportError:
    plt = None  # type: ignore[assignment]
    HAS_MATPLOTLIB = False


@dataclass
class ChartGenerationResult:
    """Outcome summary from generating all 6 survey visualizations."""

    renderer: str
    generated_files: List[Path]
    warning: Optional[str] = None


# ---------------------------------------------------------------------------
# Pure-Python PNG Fallback Renderer (used only if Matplotlib is unavailable)
# ---------------------------------------------------------------------------

_FONT_5X7: Dict[str, List[str]] = {
    "A": ["01110", "10001", "10001", "11111", "10001", "10001", "10001"],
    "B": ["11110", "10001", "10001", "11110", "10001", "10001", "11110"],
    "C": ["01110", "10001", "10000", "10000", "10000", "10001", "01110"],
    "D": ["11100", "10010", "10001", "10001", "10001", "10010", "11100"],
    "E": ["11111", "10000", "10000", "11110", "10000", "10000", "11111"],
    "F": ["11111", "10000", "10000", "11110", "10000", "10000", "10000"],
    "G": ["01110", "10001", "10000", "10111", "10001", "10001", "01110"],
    "H": ["10001", "10001", "10001", "11111", "10001", "10001", "10001"],
    "I": ["01110", "00100", "00100", "00100", "00100", "00100", "01110"],
    "J": ["00111", "00010", "00010", "00010", "10010", "10010", "01100"],
    "K": ["10001", "10010", "10100", "11000", "10100", "10010", "10001"],
    "L": ["10000", "10000", "10000", "10000", "10000", "10000", "11111"],
    "M": ["10001", "11011", "10101", "10101", "10001", "10001", "10001"],
    "N": ["10001", "11001", "10101", "10011", "10001", "10001", "10001"],
    "O": ["01110", "10001", "10001", "10001", "10001", "10001", "01110"],
    "P": ["11110", "10001", "10001", "11110", "10000", "10000", "10000"],
    "Q": ["01110", "10001", "10001", "10001", "10101", "10010", "01101"],
    "R": ["11110", "10001", "10001", "11110", "10100", "10010", "10001"],
    "S": ["01111", "10000", "10000", "01110", "00001", "00001", "11110"],
    "T": ["11111", "00100", "00100", "00100", "00100", "00100", "00100"],
    "U": ["10001", "10001", "10001", "10001", "10001", "10001", "01110"],
    "V": ["10001", "10001", "10001", "10001", "10001", "01010", "00100"],
    "W": ["10001", "10001", "10001", "10101", "10101", "11011", "10001"],
    "X": ["10001", "10001", "01010", "00100", "01010", "10001", "10001"],
    "Y": ["10001", "10001", "01010", "00100", "00100", "00100", "00100"],
    "Z": ["11111", "00001", "00010", "00100", "01000", "10000", "11111"],
    "0": ["01110", "10011", "10101", "10101", "11001", "10001", "01110"],
    "1": ["00100", "01100", "00100", "00100", "00100", "00100", "01110"],
    "2": ["01110", "10001", "00001", "00110", "01000", "10000", "11111"],
    "3": ["11110", "00001", "00001", "01110", "00001", "00001", "11110"],
    "4": ["00010", "00110", "01010", "10010", "11111", "00010", "00010"],
    "5": ["11111", "10000", "11110", "00001", "00001", "10001", "01110"],
    "6": ["01110", "10000", "10000", "11110", "10001", "10001", "01110"],
    "7": ["11111", "00001", "00010", "00100", "01000", "01000", "01000"],
    "8": ["01110", "10001", "10001", "01110", "10001", "10001", "01110"],
    "9": ["01110", "10001", "10001", "01111", "00001", "00001", "01110"],
    "-": ["00000", "00000", "00000", "11111", "00000", "00000", "00000"],
    "+": ["00000", "00100", "00100", "11111", "00100", "00100", "00000"],
    ".": ["00000", "00000", "00000", "00000", "00000", "01100", "01100"],
    ",": ["00000", "00000", "00000", "00000", "00100", "00100", "01000"],
    ":": ["00000", "01100", "01100", "00000", "01100", "01100", "00000"],
    "/": ["00001", "00010", "00010", "00100", "01000", "01000", "10000"],
    "(": ["00010", "00100", "01000", "01000", "01000", "00100", "00010"],
    ")": ["01000", "00100", "00010", "00010", "00010", "00100", "01000"],
    "%": ["11001", "11010", "00010", "00100", "01000", "01011", "10011"],
    "<": ["00010", "00100", "01000", "10000", "01000", "00100", "00010"],
    ">": ["01000", "00100", "00010", "00001", "00010", "00100", "01000"],
    "=": ["00000", "00000", "11111", "00000", "11111", "00000", "00000"],
    " ": ["00000", "00000", "00000", "00000", "00000", "00000", "00000"],
}


class _SimpleCanvas:
    """Minimal RGB raster canvas that writes valid PNG files using stdlib zlib."""

    def __init__(self, width: int = 960, height: int = 560, bg: Tuple[int, int, int] = (248, 250, 252)) -> None:
        self.width = width
        self.height = height
        row = bytearray([bg[0], bg[1], bg[2]] * width)
        self.pixels = [bytearray(row) for _ in range(height)]

    def set_pixel(self, x: int, y: int, color: Tuple[int, int, int]) -> None:
        if 0 <= x < self.width and 0 <= y < self.height:
            idx = x * 3
            self.pixels[y][idx] = color[0]
            self.pixels[y][idx + 1] = color[1]
            self.pixels[y][idx + 2] = color[2]

    def fill_rect(self, x0: int, y0: int, x1: int, y1: int, color: Tuple[int, int, int]) -> None:
        xa, xb = max(0, min(x0, x1)), min(self.width, max(x0, x1))
        ya, yb = max(0, min(y0, y1)), min(self.height, max(y0, y1))
        for y in range(ya, yb):
            row = self.pixels[y]
            for x in range(xa, xb):
                idx = x * 3
                row[idx] = color[0]
                row[idx + 1] = color[1]
                row[idx + 2] = color[2]

    def draw_line(self, x0: int, y0: int, x1: int, y1: int, color: Tuple[int, int, int], thickness: int = 1) -> None:
        dx = abs(x1 - x0)
        dy = -abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx + dy
        x, y = x0, y0
        half = thickness // 2
        while True:
            if thickness <= 1:
                self.set_pixel(x, y, color)
            else:
                self.fill_rect(x - half, y - half, x + half + 1, y + half + 1, color)
            if x == x1 and y == y1:
                break
            e2 = 2 * err
            if e2 >= dy:
                err += dy
                x += sx
            if e2 <= dx:
                err += dx
                y += sy

    def draw_circle(self, cx: int, cy: int, r: int, color: Tuple[int, int, int]) -> None:
        for dy in range(-r, r + 1):
            for dx in range(-r, r + 1):
                if dx * dx + dy * dy <= r * r:
                    self.set_pixel(cx + dx, cy + dy, color)

    def draw_text(self, x: int, y: int, text: str, color: Tuple[int, int, int], scale: int = 2) -> None:
        cursor = x
        for ch in text.upper():
            glyph = _FONT_5X7.get(ch, _FONT_5X7[" "])
            for row_idx, bits in enumerate(glyph):
                for col_idx, bit in enumerate(bits):
                    if bit == "1":
                        self.fill_rect(
                            cursor + col_idx * scale,
                            y + row_idx * scale,
                            cursor + (col_idx + 1) * scale,
                            y + (row_idx + 1) * scale,
                            color,
                        )
            cursor += 6 * scale

    def save_png(self, path: Path) -> None:
        raw_rows = bytearray()
        for row in self.pixels:
            raw_rows.append(0)  # filter type 0
            raw_rows.extend(row)

        compressed = zlib.compress(bytes(raw_rows), level=6)

        def chunk(tag: bytes, data: bytes) -> bytes:
            crc = zlib.crc32(tag + data) & 0xFFFFFFFF
            return struct.pack("!I", len(data)) + tag + data + struct.pack("!I", crc)

        ihdr = struct.pack("!IIBBBBB", self.width, self.height, 8, 2, 0, 0, 0)
        png_bytes = (
            b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", ihdr)
            + chunk(b"IDAT", compressed)
            + chunk(b"IEND", b"")
        )
        path.write_bytes(png_bytes)


def _render_fallback_bar_chart(
    output_path: Path,
    title: str,
    subtitle: str,
    labels: Sequence[str],
    values: Sequence[int],
    bar_color: Tuple[int, int, int],
    x_label: str,
    y_label: str = "Responses",
) -> None:
    canvas = _SimpleCanvas(960, 560, (255, 255, 255))
    slate = (15, 23, 42)
    muted = (100, 116, 139)
    grid = (226, 232, 240)

    canvas.draw_text(60, 28, title, slate, scale=3)
    canvas.draw_text(60, 62, subtitle, muted, scale=2)

    left, top, right, bottom = 125, 110, 910, 445
    canvas.draw_line(left, top, left, bottom, slate, 2)
    canvas.draw_line(left, bottom, right, bottom, slate, 2)

    max_val = max(values) if values and max(values) > 0 else 1
    steps = 4
    for s in range(1, steps + 1):
        val = (max_val * s) / steps
        y = int(bottom - (bottom - top) * (s / steps))
        canvas.draw_line(left + 1, y, right, y, grid, 1)
        canvas.draw_text(74, y - 6, f"{val:>3.0f}", muted, scale=2)

    n = max(1, len(labels))
    slot_w = (right - left) / n
    bar_w = max(16, int(slot_w * 0.56))
    for i, (lbl, val) in enumerate(zip(labels, values)):
        cx = int(left + slot_w * (i + 0.5))
        bar_h = int(((val / max_val) * (bottom - top - 16))) if max_val > 0 else 0
        x0 = cx - bar_w // 2
        x1 = cx + bar_w // 2
        y0 = bottom - bar_h
        if bar_h > 0:
            canvas.fill_rect(x0, y0, x1, bottom, bar_color)
        val_str = str(val)
        canvas.draw_text(cx - len(val_str) * 6, max(top, y0 - 20), val_str, slate, scale=2)
        short_lbl = lbl[:14]
        canvas.draw_text(cx - len(short_lbl) * 5, bottom + 14, short_lbl, slate, scale=2)

    canvas.draw_text(14, 255, "COUNT", muted, scale=2)
    canvas.draw_text(410, 495, x_label, muted, scale=2)
    canvas.draw_text(60, 528, "WELLNESS SURVEY VISUALIZER - NON-DIAGNOSTIC STATISTICAL SUMMARY", muted, scale=1)
    canvas.save_png(output_path)


def _render_fallback_trend_chart(output_path: Path, report: AnalyticsReport) -> None:
    canvas = _SimpleCanvas(960, 560, (255, 255, 255))
    slate = (15, 23, 42)
    muted = (100, 116, 139)
    grid = (226, 232, 240)
    teal = (13, 148, 136)
    coral = (220, 38, 38)
    blue = (37, 99, 235)

    canvas.draw_text(60, 28, "WELLNESS TRENDS OVER TIME", slate, scale=3)
    canvas.draw_text(60, 62, "DAILY AVERAGES (1-10 SCALE) ACROSS SURVEY DATES", muted, scale=2)

    left, top, right, bottom = 95, 110, 910, 435
    canvas.draw_line(left, top, left, bottom, slate, 2)
    canvas.draw_line(left, bottom, right, bottom, slate, 2)

    for score in (2, 4, 6, 8, 10):
        y = int(bottom - (score / 10.0) * (bottom - top))
        canvas.draw_line(left + 1, y, right, y, grid, 1)
        canvas.draw_text(46, y - 6, str(score), muted, scale=2)

    points = report.trends
    if len(points) == 1:
        pts_iter = [points[0], points[0]]
    else:
        pts_iter = points

    if pts_iter:
        count = max(1, len(pts_iter) - 1)
        coords_w, coords_s, coords_m = [], [], []
        for idx, pt in enumerate(pts_iter):
            x = int(left + 30 + (right - left - 60) * (idx / count))
            yw = int(bottom - (pt.avg_wellness / 10.0) * (bottom - top))
            ys = int(bottom - (pt.avg_stress / 10.0) * (bottom - top))
            ym = int(bottom - (pt.avg_mood / 10.0) * (bottom - top))
            coords_w.append((x, yw))
            coords_s.append((x, ys))
            coords_m.append((x, ym))

        for series, color in ((coords_w, teal), (coords_m, blue), (coords_s, coral)):
            for i in range(len(series) - 1):
                canvas.draw_line(series[i][0], series[i][1], series[i + 1][0], series[i + 1][1], color, 3)
            for x, y in series:
                canvas.draw_circle(x, y, 5, color)

        step = max(1, len(points) // 5)
        for idx in range(0, len(points), step):
            x = int(left + 30 + (right - left - 60) * (idx / max(1, len(points) - 1))) if len(points) > 1 else left + 30
            canvas.draw_text(x - 36, bottom + 14, points[idx].survey_date[5:], slate, scale=2)

    # Legend
    canvas.fill_rect(100, 478, 124, 492, teal)
    canvas.draw_text(134, 478, "WELLNESS", slate, scale=2)
    canvas.fill_rect(310, 478, 334, 492, blue)
    canvas.draw_text(344, 478, "MOOD", slate, scale=2)
    canvas.fill_rect(480, 478, 504, 492, coral)
    canvas.draw_text(514, 478, "STRESS", slate, scale=2)
    canvas.draw_text(60, 524, "STATISTICAL TREND SUMMARY - NOT FOR MEDICAL DIAGNOSIS", muted, scale=1)
    canvas.save_png(output_path)


# ---------------------------------------------------------------------------
# Public Chart Generator API (Matplotlib primary, pure-Python fallback)
# ---------------------------------------------------------------------------

def generate_all_charts(
    records: List[SurveyRecord],
    output_dir: Path = CHARTS_DIR,
    report: Optional[AnalyticsReport] = None,
) -> ChartGenerationResult:
    """Generate all 6 required survey charts as PNG files."""
    ensure_directories()
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    analytics = report or compute_analytics(records)

    filenames = [
        "01_sleep_duration_distribution.png",
        "02_stress_level_distribution.png",
        "03_mood_distribution.png",
        "04_physical_activity_distribution.png",
        "05_overall_wellness_distribution.png",
        "06_wellness_trends_over_time.png",
    ]
    paths = [out_dir / name for name in filenames]

    if analytics.is_empty:
        return ChartGenerationResult(
            renderer="none",
            generated_files=[],
            warning="Cannot generate charts from an empty dataset.",
        )

    if HAS_MATPLOTLIB and plt is not None:
        _generate_with_matplotlib(records, analytics, paths)
        return ChartGenerationResult(renderer="matplotlib", generated_files=paths)

    warning_msg = (
        "Matplotlib is not installed in this Python runtime; generated charts using "
        "built-in pure-Python PNG fallback renderer. Install requirements.txt for full Matplotlib styling."
    )
    logger.warning(warning_msg)
    _generate_with_fallback(records, analytics, paths)
    return ChartGenerationResult(
        renderer="pure-python-fallback",
        generated_files=paths,
        warning=warning_msg,
    )


def _generate_with_matplotlib(
    records: List[SurveyRecord],
    analytics: AnalyticsReport,
    paths: List[Path],
) -> None:
    """Render all 6 publication-quality Matplotlib figures."""
    assert plt is not None
    plt.rcParams.update({
        "font.size": 10,
        "axes.titlesize": 13,
        "axes.titleweight": "bold",
        "axes.edgecolor": "#CBD5E1",
        "axes.linewidth": 0.9,
    })

    # 1. Sleep Duration Distribution
    sleep_dist = analytics.sleep_distribution
    fig, ax = plt.subplots(figsize=(8.5, 4.8), dpi=150)
    labels = list(sleep_dist.counts.keys())
    counts = list(sleep_dist.counts.values())
    bars = ax.bar(labels, counts, color=["#F59E0B", "#3B82F6", "#0D9488", "#6366F1"], width=0.55)
    ax.set_title("Sleep Duration Distribution (Anonymous Survey Responses)")
    ax.set_xlabel("Sleep Duration Tier")
    ax.set_ylabel("Number of Respondents")
    ax.grid(axis="y", linestyle="--", alpha=0.4)
    ax.set_axisbelow(True)
    for bar, count in zip(bars, counts):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.2, str(count), ha="center", va="bottom", fontweight="bold")
    fig.tight_layout()
    fig.savefig(paths[0])
    plt.close(fig)

    # 2. Stress Level Distribution (1-10)
    fig, ax = plt.subplots(figsize=(8.5, 4.8), dpi=150)
    stress_bins = list(range(1, 11))
    stress_counts = [sum(1 for r in records if r.stress_level == i) for i in stress_bins]
    colors = ["#10B981" if i <= 3 else "#F59E0B" if i <= 6 else "#EF4444" for i in stress_bins]
    bars = ax.bar([str(i) for i in stress_bins], stress_counts, color=colors, width=0.6)
    ax.set_title("Stress Level Distribution (Scale 1-10)")
    ax.set_xlabel("Self-Reported Stress Level (1 = Low, 10 = High)")
    ax.set_ylabel("Number of Respondents")
    ax.grid(axis="y", linestyle="--", alpha=0.4)
    ax.set_axisbelow(True)
    for bar, count in zip(bars, stress_counts):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.15, str(count), ha="center", va="bottom")
    fig.tight_layout()
    fig.savefig(paths[1])
    plt.close(fig)

    # 3. Mood Distribution (1-10)
    fig, ax = plt.subplots(figsize=(8.5, 4.8), dpi=150)
    mood_bins = list(range(1, 11))
    mood_counts = [sum(1 for r in records if r.mood_rating == i) for i in mood_bins]
    bars = ax.bar([str(i) for i in mood_bins], mood_counts, color="#2563EB", width=0.6)
    ax.set_title("Mood Rating Distribution (Scale 1-10)")
    ax.set_xlabel("Self-Reported Mood Rating (1 = Low, 10 = High)")
    ax.set_ylabel("Number of Respondents")
    ax.grid(axis="y", linestyle="--", alpha=0.4)
    ax.set_axisbelow(True)
    for bar, count in zip(bars, mood_counts):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.15, str(count), ha="center", va="bottom")
    fig.tight_layout()
    fig.savefig(paths[2])
    plt.close(fig)

    # 4. Physical Activity Distribution
    act_dist = analytics.activity_distribution
    fig, ax = plt.subplots(figsize=(8.5, 4.8), dpi=150)
    labels = list(act_dist.counts.keys())
    counts = list(act_dist.counts.values())
    bars = ax.bar(labels, counts, color=["#94A3B8", "#0EA5E9", "#059669"], width=0.5)
    ax.set_title("Physical Activity Level Distribution")
    ax.set_xlabel("Daily Physical Activity Tier")
    ax.set_ylabel("Number of Respondents")
    ax.grid(axis="y", linestyle="--", alpha=0.4)
    ax.set_axisbelow(True)
    for bar, count in zip(bars, counts):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.2, str(count), ha="center", va="bottom", fontweight="bold")
    fig.tight_layout()
    fig.savefig(paths[3])
    plt.close(fig)

    # 5. Overall Wellness Distribution
    well_dist = analytics.wellness_distribution
    fig, ax = plt.subplots(figsize=(8.5, 4.8), dpi=150)
    labels = list(well_dist.counts.keys())
    counts = list(well_dist.counts.values())
    bars = ax.bar(labels, counts, color=["#EF4444", "#F59E0B", "#0D9488"], width=0.48)
    ax.set_title("Overall Wellness Tier Distribution")
    ax.set_xlabel("Wellness Category (Low 1-4, Moderate 5-7, High 8-10)")
    ax.set_ylabel("Number of Respondents")
    ax.grid(axis="y", linestyle="--", alpha=0.4)
    ax.set_axisbelow(True)
    for bar, count in zip(bars, counts):
        pct = well_dist.percentages.get(labels[bars.index(bar)], 0.0) if hasattr(bars, "index") else 0.0
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.2, f"{count} ({pct}%)", ha="center", va="bottom", fontweight="bold")
    fig.tight_layout()
    fig.savefig(paths[4])
    plt.close(fig)

    # 6. Wellness Trends Over Time
    fig, ax = plt.subplots(figsize=(9.2, 5.0), dpi=150)
    dates = [pt.survey_date for pt in analytics.trends]
    ax.plot(dates, [pt.avg_wellness for pt in analytics.trends], marker="o", linewidth=2.2, color="#0D9488", label="Avg Wellness (1-10)")
    ax.plot(dates, [pt.avg_mood for pt in analytics.trends], marker="s", linewidth=2.0, color="#2563EB", label="Avg Mood (1-10)")
    ax.plot(dates, [pt.avg_stress for pt in analytics.trends], marker="^", linewidth=2.0, linestyle="--", color="#DC2626", label="Avg Stress (1-10)")
    ax.set_ylim(0, 10.5)
    ax.set_title("Wellness, Mood & Stress Trends Over Time")
    ax.set_xlabel("Survey Date")
    ax.set_ylabel("Average Rating (1-10 Scale)")
    ax.tick_params(axis="x", rotation=35)
    ax.grid(True, linestyle="--", alpha=0.4)
    ax.legend(loc="best")
    fig.tight_layout()
    fig.savefig(paths[5])
    plt.close(fig)


def _generate_with_fallback(
    records: List[SurveyRecord],
    analytics: AnalyticsReport,
    paths: List[Path],
) -> None:
    """Render clean, readable PNG charts via pure-Python rasterization."""
    _render_fallback_bar_chart(
        paths[0],
        "SLEEP DURATION DISTRIBUTION",
        f"N = {analytics.total_responses} RESPONSES | AVG {analytics.sleep_stats.average}H",
        ["<6H", "6-6.9H", "7-9H", ">9H"],
        list(analytics.sleep_distribution.counts.values()),
        (13, 148, 136),
        "SLEEP DURATION TIER",
    )
    stress_counts = [sum(1 for r in records if r.stress_level == i) for i in range(1, 11)]
    _render_fallback_bar_chart(
        paths[1],
        "STRESS LEVEL DISTRIBUTION (1-10)",
        f"N = {analytics.total_responses} RESPONSES | AVG {analytics.stress_stats.average}/10",
        [str(i) for i in range(1, 11)],
        stress_counts,
        (220, 38, 38),
        "STRESS RATING",
    )
    mood_counts = [sum(1 for r in records if r.mood_rating == i) for i in range(1, 11)]
    _render_fallback_bar_chart(
        paths[2],
        "MOOD RATING DISTRIBUTION (1-10)",
        f"N = {analytics.total_responses} RESPONSES | AVG {analytics.mood_stats.average}/10",
        [str(i) for i in range(1, 11)],
        mood_counts,
        (37, 99, 235),
        "MOOD RATING",
    )
    _render_fallback_bar_chart(
        paths[3],
        "PHYSICAL ACTIVITY DISTRIBUTION",
        f"N = {analytics.total_responses} RESPONSES | AVG {analytics.activity_stats.average} MIN",
        ["<30M", "30-59M", "60M+"],
        list(analytics.activity_distribution.counts.values()),
        (5, 150, 105),
        "DAILY ACTIVITY TIER",
    )
    _render_fallback_bar_chart(
        paths[4],
        "OVERALL WELLNESS DISTRIBUTION",
        f"N = {analytics.total_responses} RESPONSES | AVG {analytics.wellness_stats.average}/10",
        list(analytics.wellness_distribution.counts.keys()),
        list(analytics.wellness_distribution.counts.values()),
        (15, 118, 110),
        "WELLNESS TIER",
    )
    _render_fallback_trend_chart(paths[5], analytics)
