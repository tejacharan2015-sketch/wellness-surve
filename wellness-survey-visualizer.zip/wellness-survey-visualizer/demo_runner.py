"""Automated 15-step live demonstration workflow verifying end-to-end
functionality, validation, analytics, charts, reports, and restart persistence.
"""

from __future__ import annotations

from datetime import date
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from core.survey_manager import SurveyManager
from core.validation import ValidationError, validate_sleep_duration
from generate_sample_data import generate_sample_datasets
from interface.terminal_ui import TerminalUI
from visualization.dashboard import render_dashboard_text


def run_full_demonstration() -> int:
    """Execute the 15-step academic demonstration sequence."""
    print("\n=== STEP 1 & 2: LAUNCH APPLICATION & SHOW WELCOME SCREEN ===")
    generate_sample_datasets()
    manager = SurveyManager()
    if len(manager.records) == 0:
        summary = manager.load_sample_dataset()
        print(f"Loaded {summary.imported_count} synthetic baseline records for demonstration.")

    ui = TerminalUI(manager=manager)
    ui.print_welcome_screen()

    print("\n=== STEP 3, 4 & 5: ADD SURVEY RESPONSE WITH INTENTIONAL INVALID INPUT ===")
    invalid_sleep_input = "-3.5"
    print(f"Simulating user entering invalid sleep duration: '{invalid_sleep_input}'")
    try:
        validate_sleep_duration(invalid_sleep_input)
    except ValidationError as exc:
        print(f"Validation caught invalid input safely: {exc}")

    print("\n=== STEP 6 & 7: CORRECT INPUT & SAVE ANONYMOUS RESPONSE ===")
    demo_id = "DEMO-9001"
    # Ensure clean re-runnability if DEMO-9001 already existed
    manager.delete_record(demo_id)
    corrected_payload = {
        "record_id": demo_id,
        "survey_date": date.today().isoformat(),
        "age_group": "25-34",
        "sleep_duration": 7.5,
        "physical_activity": 45,
        "stress_level": 4,
        "mood_rating": 8,
        "general_wellness": 8,
        "data_origin": "user_entry",
    }
    saved, errors, warnings = manager.add_response(corrected_payload)
    assert saved is not None and not errors, f"Demo save failed: {errors}"
    print(f"Saved anonymous record: {saved.record_id} ({saved.survey_date}) | Wellness {saved.general_wellness}/10")

    print("\n=== STEP 8: SEARCH FOR SAVED RECORD ===")
    found = manager.search_records(demo_id, exact=True)
    assert len(found) == 1, "Expected saved demo record in search results."
    print(f"Search returned {len(found)} match: {found[0].to_dict()}")

    print("\n=== STEP 9: OPEN ANALYTICS DASHBOARD ===")
    analytics = manager.get_analytics()
    print(render_dashboard_text(analytics))

    print("\n=== STEP 10: GENERATE & VERIFY CHARTS ===")
    chart_result = manager.generate_charts()
    print(f"Chart renderer: {chart_result.renderer} | Files: {len(chart_result.generated_files)}")
    for path in chart_result.generated_files:
        print(f"  - {path.name} ({path.stat().st_size} bytes)")

    print("\n=== STEP 11 & 12: GENERATE EXECUTIVE SUMMARY & EXPORT REPORTS ===")
    exported = manager.export_executive_reports(formats=["md", "txt", "csv"])
    for fmt, path in exported.items():
        print(f"  Exported {fmt.upper()}: {path} ({path.stat().st_size} bytes)")

    print("\n=== STEP 13, 14 & 15: SIMULATE RESTART & VERIFY PERSISTENCE ===")
    del manager
    restarted_manager = SurveyManager()
    persisted = restarted_manager.search_records(demo_id, exact=True)
    assert len(persisted) == 1, "Record did not persist across restart!"
    print(
        f"Restart verification passed: {len(restarted_manager.records)} total records loaded; "
        f"'{persisted[0].record_id}' verified intact."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(run_full_demonstration())
